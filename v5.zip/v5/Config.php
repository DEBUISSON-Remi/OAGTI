<?php


class Config
{


// Paramètres pour l'accès à la base de données
    const BDD_HOST      = 'localhost';
    const BDD_NAME      = 'oagti_v2';
    const BDD_USER      = 'root';
    const BDD_PASSWORD  = '';

// Paramètres pour l'application
    const APPLI_NAME    = 'oagti';
    const APPLI_VERSION = 'v5';
    const NOM_AGENCE = 'Globagence';
    const TEL_AGENCE = '09 76 48 95 10';
    const ADDR_AGENCE = 'La Roche Sur-Yon / 85000';
    const ADDR_AGENCE_STREET = 'Rue Delille';
    const CP_AGENCE = '85000';


}