-- phpMyAdmin SQL Dump
-- version 5.0.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 08, 2020 at 03:08 PM
-- Server version: 10.3.20-MariaDB-0ubuntu0.19.04.1
-- PHP Version: 7.2.24-0ubuntu0.19.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oagti_v1`
--

-- --------------------------------------------------------

--
-- Table structure for table `CONSULTANT`
--

CREATE TABLE `CONSULTANT` (
  `idConsultant` int(11) NOT NULL,
  `typeUser_id` int(11) NOT NULL,
  `commissionRate` decimal(50,2) DEFAULT NULL,
  `firstnameConsultant` varchar(100) DEFAULT NULL,
  `lastnameConsultant` varchar(100) DEFAULT NULL,
  `phoneConsultant` varchar(20) DEFAULT NULL,
  `addressStreetConsultant` varchar(100) DEFAULT NULL,
  `addressCityConsultant` varchar(100) DEFAULT NULL,
  `postalCodeConsultant` varchar(20) DEFAULT NULL,
  `mailConsultant` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `CONSULTANT`
--

INSERT INTO `CONSULTANT` (`idConsultant`, `typeUser_id`, `commissionRate`, `firstnameConsultant`, `lastnameConsultant`, `phoneConsultant`, `addressStreetConsultant`, `addressCityConsultant`, `postalCodeConsultant`, `mailConsultant`, `password`) VALUES
(1, 1, '3.00', 'Jhon', 'Wick', '06 44 81 69 93', 'P.O. Box 135, 5206 Quisque St.', 'Saint-Eugeaine-de-Guigues', '85300', 'Jhon.Wick@globagence.com', 'DVP56TCG3ZV'),
(2, 2, '8.00', 'Dexter', 'Lucius', '06 98 55 05 16', 'P.O. Box 436, 1579 Erat Road', 'Sint-Stevens-Woluwe', '85000', 'dexter.Lucius@globagence.com', 'KOF97MAB4MD'),
(3, 2, '8.00', 'Grant', 'Tasha', '06 97 04 95 04', 'P.O. Box 237, 4929 Euismod St.', 'Langford', '6872', 'arcu.Aliquam.ultrices@molestie.net', 'ZOR43LHP7WH'),
(4, 2, '6.00', 'Allen', 'Garrett', '06 85 19 04 36', '9330 Maecenas St.', 'Legal', '0270', 'Pellentesque.ultricies@volutpatnunc.org', 'QNH76MMT9YI'),
(5, 2, '4.00', 'Melvin', 'Minerva', '06 36 75 02 38', 'Ap #756-2789 A Road', 'Natales', '726989', 'tincidunt.orci.quis@tellussemmollis.net', 'AIA88QRX7TS'),
(6, 2, '8.00', 'Sade', 'Shafira', '06 00 06 54 57', '7877 Natoque Rd.', 'Charsadda', '72-040', 'dapibus.quam.quis@amagna.org', 'KWC90QIR5OB'),
(7, 2, '2.00', 'Wang', 'Isabella', '06 38 82 06 15', 'Ap #310-4872 Libero Rd.', 'Minderhout', '23-459', 'aliquet.metus.urna@eu.co.uk', 'ZWK26MRO1EK'),
(8, 2, '3.00', 'Devin', 'Garth', '06 56 81 89 90', 'P.O. Box 160, 2247 Mauris Ave', 'Flensburg', '51112', 'mollis.lectus.pede@orciDonecnibh.ca', 'TSL28IEW1LO'),
(9, 2, '2.00', 'Rebekah', 'Flynn', '06 46 87 34 33', '140-2673 Diam. Rd.', 'Satara', '92267', 'nisi.Mauris@luctusipsumleo.edu', 'MGY55YCN2YS'),
(10, 2, '8.00', 'Ferdinand', 'Orli', '06 26 09 41 14', 'Ap #105-6863 Auctor St.', 'Tolentino', 'H4X 6Z0', 'Cras.vehicula@lectusa.ca', 'MXQ94FZF5QF'),
(11, 2, '6.00', 'Quintessa', 'Tamara', '06 93 49 44 43', 'Ap #648-1948 Fusce Avenue', 'Montauban', '22932-16137', 'tortor.Integer.aliquam@acorciUt.com', 'JRA39IIO2KS'),
(12, 2, '2.00', 'Ori', 'Kitra', '06 04 72 57 33', 'Ap #319-3060 Velit Ave', 'Mespelare', 'Z1751', 'vitae.posuere@vitaealiquameros.org', 'MCS50BSL4QK'),
(13, 2, '6.00', 'Hedley', 'Austin', '06 02 71 79 50', '815-9524 Praesent Ave', 'Gontrode', '861029', 'mi.fringilla@enim.edu', 'KMF96CHC5FE'),
(14, 2, '8.00', 'Amal', 'Jaquelyn', '06 47 71 59 23', 'Ap #679-3021 Curabitur St.', 'Samsun', '29-609', 'ac.urna@Quisquelibero.net', 'JYS87SOW1SJ'),
(15, 2, '7.00', 'Ginger', 'Benjamin', '06 86 36 20 22', 'P.O. Box 295, 4248 Fusce Avenue', 'Wageningen', '83685', 'vitae@Quisquepurussapien.org', 'JHB52KAL2LP'),
(16, 2, '8.00', 'Seth', 'Chester', '06 09 10 41 07', 'P.O. Box 646, 5209 Eget, St.', 'Knokke-Heist', '1516', 'Donec@maurisMorbinon.org', 'CIK63ZBG8WD'),
(17, 2, '3.00', 'vav340', 'Scott', '06 89 53 85 52', 'P.O. Box 702, 5673 Elit Street', 'Mezzana', '39477', 'vava340.Nam.ligula@non.net', 'CWS48KET4RM'),
(18, 2, '2.00', 'Ross', 'Leroy', '06 30 33 36 76', 'Ap #205-3496 Tincidunt Rd.', 'Vielsalm', '64990', 'euismod@vitaemaurissit.ca', 'JOX05LYE2YC'),
(19, 2, '3.00', 'Brianna', 'Martena', '06 24 09 47 20', 'P.O. Box 234, 5087 Ornare. Av.', 'Ketchikan', '74192-968', 'sit.amet@ametdapibusid.ca', 'RSN85OXX3ZT'),
(20, 2, '8.00', 'Michelle', 'Tad', '06 81 03 57 58', '5991 Nunc St.', 'Swan Hills', 'EI62 5TD', 'molestie.tellus.Aenean@hendrerit.ca', 'IGA53CWY8ZM'),
(21, 2, '6.00', 'Nissim', 'Patrick', '06 38 64 69 53', 'P.O. Box 292, 3456 Parturient Av.', 'West Ham', '04483', 'pede@velconvallis.org', 'YGQ59VZI9BH'),
(22, 2, '8.00', 'Colette', 'Fredericka', '06 39 73 95 31', '3153 Ac Rd.', 'Upplands Väsby', '24052-69979', 'ante.iaculis.nec@gravida.ca', 'SSF72PIS4KG'),
(23, 2, '3.00', 'Vanna', 'Laura', '06 20 85 80 58', 'Ap #707-4444 Sodales Street', 'Torre Cajetani', '00944', 'non.nisi@enimcondimentum.co.uk', 'XRO55ANY8ZM'),
(24, 2, '7.00', 'Tatyana', 'Shad', '06 33 13 99 22', 'P.O. Box 101, 5518 Donec St.', 'Minna', 'Z1394', 'ut.dolor@sagittissemper.edu', 'FKG35HHF1ZM'),
(25, 2, '2.00', 'Nomlanga', 'Knox', '06 67 77 39 66', '512-258 Nullam Rd.', 'Chishtian Mandi', '47084', 'Vestibulum@nuncac.edu', 'BQC96FJG7VW'),
(26, 2, '8.00', 'Timothy', 'Orla', '06 63 38 47 55', '946-4822 Lectus St.', 'Palopo', '341945', 'vitae@Sedcongueelit.com', 'UJF23JQD6XS'),
(27, 2, '2.00', 'Ciara', 'Lamar', '06 42 22 40 40', '6390 Erat Rd.', 'Melbourne', '835557', 'arcu@quis.co.uk', 'UVL88EDO6OW'),
(28, 2, '5.00', 'Justin', 'Harlan', '06 11 03 70 35', 'P.O. Box 100, 8208 Et, Ave', 'Santarcangelo di Romagna', '9509', 'nec.euismod.in@nuncnullavulputate.org', 'DYW34DRF1FT'),
(29, 2, '5.00', 'Armando', 'Aimee', '06 70 37 97 20', 'P.O. Box 316, 7424 In Av.', 'Macquenoise', '884266', 'Etiam.bibendum@tellusNunclectus.co.uk', 'KTN52BHB4ZF'),
(30, 2, '7.00', 'Kim', 'Kibo', '06 55 98 68 09', 'P.O. Box 375, 3398 Nec St.', 'Sint-Joost-ten-Node', '4290', 'Duis.a.mi@mattisvelitjusto.net', 'YYV28TPJ6OO'),
(31, 2, '7.00', 'Devin', 'Stella', '06 67 39 79 79', '478-4091 Eu Rd.', 'Cincinnati', '6132', 'scelerisque@estac.ca', 'CKN13MQW4QU'),
(32, 2, '6.00', 'Dorian', 'Norman', '06 97 84 93 88', 'P.O. Box 129, 9395 Libero Rd.', 'Skövde', 'Z0743', 'orci.in@Morbinequetellus.net', 'FSN37DAJ4BZ'),
(33, 2, '5.00', 'Roth', 'Benedict', '06 47 99 79 45', '651-9696 Auctor Av.', 'Lac Ste. Anne', '86050-81284', 'arcu.Vestibulum.ante@sitamet.edu', 'SII76GHN1FT'),
(34, 2, '7.00', 'Roth', 'Leandra', '06 42 30 36 76', '1717 Risus. Street', 'Certaldo', 'Z7926', 'nibh.Aliquam.ornare@sit.ca', 'GPX92QWX7VF'),
(35, 2, '2.00', 'Meghan', 'Alma', '06 91 35 49 37', 'Ap #769-7296 Id, Rd.', 'İzmit', '820790', 'ultricies.dignissim.lacus@Sedeunibh.org', 'OTX76DZX7ME'),
(36, 2, '5.00', 'Cyrus', 'Silas', '06 06 49 32 75', 'Ap #197-8021 Amet Ave', 'North Bay', 'Z9464', 'et@ettristique.net', 'PLC81AZK5MC'),
(37, 2, '8.00', 'Susan', 'Ariel', '06 00 54 47 36', 'P.O. Box 141, 3885 Porta St.', 'Castello di Godego', 'Z9379', 'libero.dui.nec@Integerid.net', 'DRW70HCT0ZU'),
(38, 2, '3.00', 'Wallace', 'Rae', '06 30 44 40 70', 'Ap #568-199 Dolor St.', 'Beawar', '37683', 'in.consequat@risusaultricies.net', 'DFR67VUH5FR'),
(39, 2, '4.00', 'Tanek', 'Diana', '06 48 57 30 24', '132-5830 A Rd.', 'Berhampore', '78799-170', 'Fusce@Nunc.edu', 'DZS55SOQ9RK'),
(40, 2, '6.00', 'Sawyer', 'Evan', '06 46 74 22 32', 'Ap #836-7773 Magna Road', 'Asbestos', '37106', 'velit.Sed.malesuada@hendreritneque.net', 'HXG09TEL6KP'),
(41, 2, '3.00', 'Jermaine', 'Cadman', '06 99 81 10 68', 'Ap #342-2207 Donec Road', 'Rulles', '47531', 'amet.faucibus@arcuNunc.ca', 'LVK24CGS9WW'),
(42, 2, '8.00', 'Sydnee', 'Armando', '06 67 25 48 27', '5378 Ac Av.', 'Savannah', '1317 UE', 'interdum@justo.co.uk', 'FTI93DGW6ZI'),
(43, 2, '7.00', 'Xanthus', 'September', '06 78 29 86 36', 'P.O. Box 106, 3293 Consectetuer Av.', 'Bovigny', '66860', 'et.magnis.dis@molestieorcitincidunt.ca', 'PNC64RMP4MU'),
(44, 2, '8.00', 'Alan', 'Maite', '06 01 39 19 58', 'P.O. Box 953, 317 Non Ave', 'Olsztyn', '98188', 'arcu.Vestibulum.ante@facilisiSedneque.com', 'UJN65OZD9QI'),
(45, 2, '2.00', 'Whitney', 'Mercedes', '06 67 83 12 78', '311-5749 A Street', 'Hillsboro', '9559', 'in.felis.Nulla@malesuada.org', 'NYT87BEY2EO'),
(46, 2, '3.00', 'Cole', 'Kellie', '06 26 03 44 97', '741-7532 Tempor, Av.', 'Fontanigorda', '21662', 'Donec.tempus.lorem@estcongue.com', 'FKB28YWN5JU'),
(47, 2, '6.00', 'Azalia', 'Devin', '06 92 72 83 94', 'Ap #461-6188 Ligula St.', 'Kitimat', '81399', 'tincidunt.neque.vitae@estacmattis.ca', 'OHH62XKE6SX'),
(48, 2, '3.00', 'Donna', 'Aristotle', '06 04 85 52 77', 'Ap #501-4732 Ullamcorper Street', 'Langenhagen', '01985', 'dapibus.id@nibhdolornonummy.ca', 'STY47RSC8LT'),
(49, 2, '6.00', 'Christian', 'Alden', '06 65 65 11 24', 'P.O. Box 744, 7386 Id, St.', 'San Cesario di Lecce', '69809', 'luctus.sit.amet@quispedeSuspendisse.ca', 'VBD88QKV9OG'),
(50, 2, '8.00', 'Gary', 'Drew', '06 12 53 67 61', '812-5402 Quis St.', 'Ficarolo', '2738', 'tincidunt.pede.ac@dictumeu.co.uk', 'GIF85AJB5QW'),
(51, 2, '7.00', 'Tatiana', 'Tana', '06 80 13 54 75', 'P.O. Box 823, 3548 Mus. Road', 'Gargazzone/Gargazon', '28206', 'rutrum.magna@nibh.edu', 'UGV50MNK9YJ'),
(52, 2, '3.00', 'Rowan', 'Aurelia', '06 47 02 73 49', 'P.O. Box 599, 9881 Posuere Street', 'Deschambault', '96493', 'Duis.at@estac.org', 'EOS68RRZ6XR'),
(53, 2, '7.00', 'Quamar', 'Ria', '06 58 40 12 64', '9144 Ante St.', 'Nocciano', '06933', 'lectus.pede.ultrices@ametrisusDonec.edu', 'VHZ24OHS1DQ'),
(54, 2, '5.00', 'Devine', 'Ariana', '06 04 12 83 10', 'Ap #611-3521 Lobortis. Street', 'Harlech', '5749', 'ornare.facilisis.eget@sollicitudin.com', 'AGZ36GHQ0LM'),
(55, 2, '5.00', 'Aidan', 'Carol', '06 04 01 09 66', '3444 Penatibus Street', 'Shenkursk', '6274', 'ullamcorper.Duis.at@eget.org', 'OXG62ZQC8GP'),
(56, 2, '6.00', 'Abraham', 'MacKensie', '06 15 97 00 07', 'Ap #298-6811 Luctus. Av.', 'Camrose', 'V2J 4Y4', 'semper@erat.ca', 'XLV54UMB2RT'),
(57, 2, '8.00', 'Thaddeus', 'Molly', '06 65 79 56 00', '8972 Tellus St.', 'Genval', '265823', 'enim.sit@velitduisemper.edu', 'UNW71MWZ4CE'),
(58, 2, '6.00', 'Maile', 'Hadley', '06 11 41 76 86', '517-5366 Sed St.', 'Haverfordwest', '4647', 'orci.adipiscing@semegetmassa.org', 'OCT73QJM1RQ'),
(59, 2, '2.00', 'Xenos', 'Seth', '06 76 69 14 06', 'Ap #545-2556 Elit. Rd.', 'Branchon', '2826 FC', 'nec.quam.Curabitur@nonummyFusce.net', 'UHU64ZOU9QQ'),
(60, 2, '7.00', 'Beatrice', 'Daphne', '06 06 03 45 14', '673-5413 Est, Road', 'Machynlleth', '79841', 'Donec.elementum.lorem@ametconsectetuer.edu', 'TAT77CFI4RT'),
(61, 2, '2.00', 'Dustin', 'Keith', '06 48 46 11 61', '1794 Ac Road', 'North Vancouver', '507652', 'non@ornare.com', 'SPL55HDF4FT'),
(62, 2, '8.00', 'Mari', 'Lucian', '06 46 90 89 95', '1626 Proin Rd.', 'Friedrichshafen', '234133', 'nulla.magna.malesuada@lacus.net', 'SXI54BEX6PH'),
(63, 2, '3.00', 'Brenden', 'Lars', '06 12 27 87 36', 'P.O. Box 523, 5261 Ut Avenue', 'Fumal', '82638', 'turpis.vitae@vehiculaPellentesquetincidunt.ca', 'HUA88RXI2QN'),
(64, 2, '3.00', 'Armand', 'Daryl', '06 77 75 91 76', 'Ap #386-3565 Nec, St.', 'Crowsnest Pass', '7034', 'Proin@quisaccumsan.ca', 'QIA87ULA0ZV'),
(65, 2, '5.00', 'Yasir', 'Thaddeus', '06 20 79 18 15', 'Ap #399-4066 Sodales. St.', 'Polcenigo', '173065', 'luctus.Curabitur@vitae.edu', 'VBS78RVA5IL'),
(66, 2, '5.00', 'Bradley', 'Zorita', '06 54 13 93 18', '7613 Sem Av.', 'Ziano di Fiemme', '2173', 'commodo.tincidunt@convallis.co.uk', 'YCU37PBI1ZN'),
(67, 2, '5.00', 'Adrienne', 'Stuart', '06 75 45 19 12', 'P.O. Box 645, 3303 Curabitur Rd.', 'Ancud', 'W7 0UT', 'tincidunt.Donec@actellus.com', 'BJA59KIJ0HS'),
(68, 2, '5.00', 'Lane', 'Kimberly', '06 08 26 61 13', '880 Vivamus Rd.', 'Friedrichshafen', '4965', 'rhoncus@atiaculisquis.ca', 'KFE45LIN0YO'),
(69, 2, '6.00', 'Fredericka', 'Kaseem', '06 70 86 01 76', 'P.O. Box 402, 835 Nibh. Road', 'Missoula', '812270', 'egestas@et.co.uk', 'OZD74GXI3LT'),
(70, 2, '6.00', 'Thomas', 'Tatiana', '06 81 70 42 67', '586 Non Rd.', 'Carson City', '31618', 'et.netus@vitae.co.uk', 'BMW15XZY1JE'),
(71, 2, '7.00', 'McKenzie', 'Carson', '06 48 92 01 14', 'Ap #521-9317 At, Avenue', 'Walhain-Saint-Paul', '57670-20534', 'dapibus.gravida.Aliquam@tellus.co.uk', 'OVS28AZF3GQ'),
(72, 2, '4.00', 'Luke', 'Logan', '06 76 91 96 19', 'P.O. Box 580, 2928 Dolor Road', 'Torchiarolo', '652743', 'magna.tellus@Nuncsed.org', 'GCP09CWK2BO'),
(73, 2, '7.00', 'Alea', 'Cara', '06 24 33 74 21', 'P.O. Box 319, 4794 Cursus. Street', 'Limena', '7990', 'risus.Duis@quisdiamPellentesque.edu', 'SIM63QON5NK'),
(74, 2, '2.00', 'Elton', 'Aileen', '06 49 43 02 10', 'P.O. Box 159, 4348 Facilisi. Ave', 'Paisley', '01164', 'tortor.nibh@Nullam.net', 'PDZ55ANG6PC'),
(75, 2, '4.00', 'Keelie', 'Ray', '06 11 99 97 14', '5096 Vel Ave', 'Meerhout', '718765', 'non.ante@Nuncsed.com', 'XOZ20XKF2IN'),
(76, 2, '7.00', 'Paloma', 'Raymond', '06 65 25 90 88', '5026 Suspendisse Ave', 'Kemzeke', '27089', 'neque@aliquetlobortisnisi.edu', 'YWV49VTS6ZM'),
(77, 2, '2.00', 'Wange', 'Flavia', '06 66 19 88 03', '214-2151 Proin Rd.', 'Wandre', '09919', 'sagittis.semper.Nam@lacusCras.org', 'WZG87YRN1MM'),
(78, 2, '6.00', 'Sarah', 'Avram', '06 11 34 25 66', '9048 Cursus Av.', 'Snaaskerke', '69633', 'et.tristique.pellentesque@orci.ca', 'MMM60TMP5LJ'),
(79, 2, '8.00', 'Ashely', 'Sade', '06 60 83 31 65', '380-1726 Fusce Street', 'Abbateggio', '791644', 'facilisis.facilisis.magna@liberoProin.org', 'ARH17VCP9NZ'),
(80, 2, '6.00', 'Keane', 'Kirestin', '06 22 31 35 06', '442-4749 Vel Rd.', 'Thorold', '24139', 'pede.Cum.sociis@gravida.net', 'LLR30AVM0TY'),
(81, 2, '3.00', 'Hakeem', 'Zoe', '06 00 46 93 92', 'Ap #765-7208 Nunc Ave', 'Bard', '235342', 'turpis.Aliquam.adipiscing@urna.org', 'TTA66PAG7OQ'),
(82, 2, '3.00', 'Valentine', 'TaShya', '06 83 40 66 16', '7537 A St.', 'Ramsey', '9169', 'pede.nec@arcuSed.edu', 'UNJ93WWC5HC'),
(83, 2, '5.00', 'Chadwick', 'Len', '06 43 43 06 06', 'P.O. Box 421, 5845 Quam. Rd.', 'Moxhe', '51811', 'eget.laoreet.posuere@primisinfaucibus.ca', 'WAZ46IUW1TO'),
(84, 2, '8.00', 'Regan', 'Martha', '06 33 95 88 85', 'P.O. Box 650, 225 Et Av.', 'Great Yarmouth', '907711', 'dictum@atnisiCum.com', 'BSO25WFB3SG'),
(85, 2, '2.00', 'Colt', 'Belle', '06 41 14 37 02', '7035 Quam. Road', 'Langenburg', '1256', 'sagittis.felis@hendreritnequeIn.com', 'BBC60BIW9AU'),
(86, 2, '3.00', 'Erasmus', 'Jesse', '06 06 06 74 89', 'P.O. Box 904, 1249 Ultricies Road', 'Villarrica', '973432', 'non@semegestas.net', 'VHE38CRN0GV'),
(87, 2, '8.00', 'Galena', 'Lionel', '06 28 97 74 97', '684-6700 Lacus. Av.', 'Belém', '02508', 'Donec.fringilla@sagittis.net', 'CSD87GWY4GG'),
(88, 2, '7.00', 'Ursula', 'Rajah', '06 01 93 23 30', 'Ap #811-9502 Feugiat. Avenue', 'Mundare', '846086', 'eget.magna.Suspendisse@Donecegestas.com', 'SHI88KDT7HU'),
(89, 2, '3.00', 'Debra', 'Chloe', '06 15 66 27 08', '821-7914 Fusce Avenue', 'Legal', '713680', 'Proin.non.massa@Namligulaelit.ca', 'ISL26CJP4YY'),
(90, 2, '8.00', 'Carson', 'Jessamine', '06 58 17 87 94', 'Ap #171-8088 Nec Avenue', 'Rostock', 'S0Y 6N9', 'Sed.malesuada@enim.edu', 'FGE57KCD5YH'),
(91, 2, '7.00', 'Upton', 'Kibo', '06 81 40 38 74', 'P.O. Box 339, 7365 Suspendisse Street', 'Anzi', '62446-12709', 'sit@Utsagittis.co.uk', 'MTG12VRD6AO'),
(92, 2, '3.00', 'Winter', 'Iona', '06 12 95 23 17', '973-3295 Magna. Avenue', 'Ancarano', 'S5R 2M1', 'metus@orci.com', 'NSD20TDS2YU'),
(93, 2, '3.00', 'Jamal', 'Yuri', '06 78 32 96 79', 'Ap #968-4121 Sit St.', 'Tourcoing', '8538', 'nonummy.Fusce@ridiculus.org', 'WJP02HXF4XL'),
(94, 2, '6.00', 'Price', 'Elijah', '06 93 57 01 57', 'P.O. Box 747, 5898 Amet Rd.', 'Chitral', '676818', 'sem.consequat@pellentesquemassa.org', 'PJF41FEG7LO'),
(95, 2, '4.00', 'Andrew', 'Stone', '06 49 73 78 68', 'Ap #913-9893 Odio, St.', 'Waasmunster', '2609', 'mauris.sapien.cursus@vulputate.com', 'YLT63FKT2RW'),
(96, 2, '3.00', 'Cameron', 'Shad', '06 71 21 66 39', 'Ap #605-7094 Vehicula Av.', 'Montpellier', '04769', 'vestibulum.Mauris@MorbivehiculaPellentesque.net', 'ZWF77BGJ3AD'),
(97, 2, '6.00', 'Tanya', 'Noelle', '06 38 40 12 50', 'Ap #973-7288 Natoque Road', 'Mount Pearl', '816348', 'dignissim@arcuCurabitur.co.uk', 'FTD65RAB6RP'),
(98, 2, '2.00', 'Sean', 'Kylee', '06 70 61 95 96', 'P.O. Box 811, 6532 Lacus. Rd.', 'Szczecin', '5861', 'a.magna.Lorem@actellusSuspendisse.edu', 'DAT63MEZ3QT'),
(99, 2, '4.00', 'Xavier', 'Lael', '06 78 57 76 03', 'P.O. Box 980, 7884 Augue, Rd.', 'Renca', '29993', 'cursus.purus.Nullam@cursusnon.net', 'LUG22MFB4KY'),
(100, 2, '2.00', 'Lilah', 'Vladimir', '06 73 90 74 49', 'Ap #757-5229 Dapibus Avenue', 'Sant\'Angelo a Fasanella', 'JY7 9MD', 'id@Nunccommodoauctor.co.uk', 'XZL39FAL0RW');

-- --------------------------------------------------------

--
-- Table structure for table `ENERGY`
--

CREATE TABLE `ENERGY` (
  `idEnergy` int(11) NOT NULL,
  `libelleEnergy` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ENERGY`
--

INSERT INTO `ENERGY` (`idEnergy`, `libelleEnergy`) VALUES
(1, 'Pas d\'énergie'),
(2, 'Electrique'),
(3, 'Fioul '),
(4, 'Poêle à bois'),
(5, 'Poêle à copeaux de bois'),
(6, 'Cheminée'),
(7, 'Pompe à chaleur');

-- --------------------------------------------------------

--
-- Table structure for table `EXPENSES`
--

CREATE TABLE `EXPENSES` (
  `idExpenses` int(11) NOT NULL,
  `fonciere` int(11) DEFAULT NULL,
  `livingExpenses` int(11) DEFAULT NULL,
  `expenses` int(11) DEFAULT NULL,
  `sanitation_id` int(11) NOT NULL,
  `heatingMethod_id` int(11) NOT NULL,
  `energy_id` int(11) NOT NULL,
  `hotWater_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `EXPENSES`
--

INSERT INTO `EXPENSES` (`idExpenses`, `fonciere`, `livingExpenses`, `expenses`, `sanitation_id`, `heatingMethod_id`, `energy_id`, `hotWater_id`) VALUES
(1, 0, 0, 0, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `HEATING_METHOD`
--

CREATE TABLE `HEATING_METHOD` (
  `idHeatingMethod` int(11) NOT NULL,
  `libelleHeatingMethod` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `HEATING_METHOD`
--

INSERT INTO `HEATING_METHOD` (`idHeatingMethod`, `libelleHeatingMethod`) VALUES
(1, 'Pas de mode de chauffage'),
(2, 'Central'),
(3, 'Individuel'),
(4, 'Collectif');

-- --------------------------------------------------------

--
-- Table structure for table `HOT_WATER`
--

CREATE TABLE `HOT_WATER` (
  `idHotWater` int(11) NOT NULL,
  `libelleHotWater` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `HOT_WATER`
--

INSERT INTO `HOT_WATER` (`idHotWater`, `libelleHotWater`) VALUES
(1, 'Pas d\'eau chaude'),
(2, 'Pompe à chaleur'),
(3, 'Electrique'),
(4, 'Fuel'),
(5, 'Poêle à bois'),
(6, 'Poêle à copeaux de bois'),
(7, 'Cheminée');

-- --------------------------------------------------------

--
-- Table structure for table `MANDATE`
--

CREATE TABLE `MANDATE` (
  `idMandate` int(11) NOT NULL,
  `typeMandate_id` int(11) NOT NULL,
  `mandateName` varchar(100) DEFAULT NULL,
  `agencyName` varchar(100) DEFAULT NULL,
  `agencyPhone` varchar(20) DEFAULT NULL,
  `addressStreetAgency` varchar(100) DEFAULT NULL,
  `addressCityAgency` varchar(100) DEFAULT NULL,
  `postalCodeAgency` varchar(20) DEFAULT NULL,
  `propertyPrice` float DEFAULT NULL,
  `statusMandate_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `MANDATE`
--

INSERT INTO `MANDATE` (`idMandate`, `typeMandate_id`, `mandateName`, `agencyName`, `agencyPhone`, `addressStreetAgency`, `addressCityAgency`, `postalCodeAgency`, `propertyPrice`, `statusMandate_id`) VALUES
(1, 1, 'Dolan Robinson', 'Est Ac Facilisis Ltd', '02 12 34 01 36', 'P.O. Box 851, 7052 Massa St.', 'Chekhov', '51562', 168013, 1),
(2, 1, 'Ivor Moon', 'Etiam Bibendum Fermentum LLP', '02 56 47 15 84', '509-3402 Sit St.', 'Vorst', '664228', 296466, 1),
(3, 2, 'Forrest Christian', 'Et Associates', '02 26 69 40 76', 'Ap #273-6924 Pharetra Rd.', 'Pero', '29805', 261893, 1),
(4, 2, 'August Oliver', 'Curabitur Limited', '02 70 27 18 89', '9312 Ornare Av.', 'Jhansi', 'A5W 4N5', 160601, 1),
(5, 1, 'Alec Herrera', 'Curae; Donec LLP', '02 57 53 62 60', '276-2261 Dictum Av.', 'Bollnäs', '054021', 283664, 1),
(6, 2, 'Brock Fernandez', 'Duis Ac Arcu Industries', '02 44 12 13 61', '6279 Integer Road', 'Sefro', '99268', 153099, 1),
(7, 2, 'Abbot Conley', 'Eros Nec LLC', '02 46 74 51 02', 'P.O. Box 486, 2281 Donec Street', 'Lac-Serent', '231286', 231047, 1),
(8, 2, 'Raymond Cain', 'Sed Libero Proin Institute', '02 84 44 24 80', 'P.O. Box 829, 7481 Lorem, Ave', 'Friedberg', '02852', 225885, 1),
(9, 2, 'Xanthus Rojas', 'Magna Company', '02 52 25 96 96', '481-3902 Ultrices Street', 'Coronel', '58631-80951', 68238, 1),
(10, 2, 'Scott Riley', 'Tellus Non Magna Foundation', '02 46 02 37 19', '699-1874 Risus St.', 'Rhayader', '9003', 161647, 1),
(11, 1, 'Jonah Haynes', 'Nonummy Fusce Industries', '02 29 30 45 05', 'Ap #778-6031 Sem, Avenue', 'MŽlin', '95603-31129', 52732, 1),
(12, 1, 'Emmanuel Norton', 'Metus Associates', '02 55 81 67 72', 'Ap #147-6748 Velit Rd.', 'Pedro Aguirre Cerda', '943669', 70800, 1),
(13, 1, 'Quinn Mcfarland', 'In Corporation', '02 05 17 68 79', '165-8884 Scelerisque Avenue', 'Cognelee', '390439', 69007, 1),
(14, 1, 'Lyle Roy', 'Ligula Nullam Ltd', '02 26 79 68 26', '3023 Magna. Avenue', 'Clovenfords', 'H5X 9L5', 146457, 1),
(15, 2, 'Jesse Reed', 'Aliquet Lobortis Nisi LLC', '02 01 99 17 35', 'P.O. Box 928, 6621 Et Avenue', 'Kashira', '64443', 258439, 1),
(16, 1, 'Joel Fischer', 'Urna Institute', '02 50 56 05 46', '2312 Ac Rd.', 'Quesada', '09260', 76874, 1),
(17, 1, 'Zeph Meyers', 'Risus Donec Limited', '02 05 64 79 26', '6521 Leo. Rd.', 'Rocourt', '54658', 115354, 1),
(18, 2, 'Brenden Boyer', 'Vestibulum Inc.', '02 22 23 35 23', 'P.O. Box 351, 9063 Non, Av.', 'Oudenburg', '84867-80365', 85466, 1),
(19, 1, 'Cairo Lopez', 'Dui Inc.', '02 15 04 14 30', '170-8025 Urna. Road', 'Stupino', '267078', 134798, 1),
(20, 2, 'Bert Hale', 'Eu Odio Ltd', '02 35 14 65 82', 'Ap #576-545 Nascetur Av.', 'Bursa', '546294', 82059, 1),
(21, 2, 'Oscar Finley', 'Aliquet Metus PC', '02 54 13 27 75', '1113 Convallis Av.', 'Omaha', '96770', 192524, 1),
(22, 1, 'Conan Hogan', 'Integer Id LLP', '02 53 56 25 67', '711-4884 Sapien, Rd.', 'Telford', '6308', 86123, 1),
(23, 2, 'Isaiah Chen', 'Mauris Corporation', '02 47 64 14 66', 'P.O. Box 413, 1597 Tellus. Street', 'Neustadt am Rübenberge', '667510', 286374, 1),
(24, 1, 'Simon Crawford', 'Sem Limited', '02 64 33 62 32', 'Ap #460-9852 Consectetuer Street', 'Miraflores', 'P6V 5H4', 78966, 1),
(25, 2, 'Isaac Sanders', 'Ornare Industries', '02 86 19 08 81', 'Ap #820-6978 Tellus Rd.', 'Dro', '72418', 263664, 1),
(26, 2, 'Hakeem Huffman', 'Nec Limited', '02 26 29 05 98', '5682 Ligula Road', 'Dudzele', '6127', 67003, 1),
(27, 2, 'Dean Kemp', 'Nunc Ut Erat Incorporated', '02 09 65 06 04', 'P.O. Box 765, 1266 Eu Av.', 'Oakham', '95-783', 85607, 1),
(28, 2, 'Linus Walker', 'Ullamcorper Duis PC', '02 14 44 08 80', 'Ap #826-8918 Tellus, Road', 'Serang', '27-290', 238432, 1),
(29, 2, 'Daniel Welch', 'Luctus Curabitur Institute', '02 39 70 39 51', 'Ap #329-6233 Ad Road', 'Monte San Savino', '7180', 95581, 1),
(30, 2, 'Coby Gould', 'Blandit Limited', '02 84 26 48 08', 'Ap #842-7797 Sed Street', 'Saint-Marcel', '32-252', 175921, 1),
(31, 2, 'Berk Cooper', 'Sapien Incorporated', '02 76 71 94 50', 'P.O. Box 643, 6026 Mauris Avenue', 'Zipaquirá', '35724-73581', 228646, 1),
(32, 2, 'Aristotle Rosa', 'Suspendisse Consulting', '02 44 36 75 63', 'P.O. Box 270, 2021 Lobortis St.', 'West Jordan', '61411', 154950, 1),
(33, 2, 'Jesse Hull', 'Ligula LLC', '02 16 55 02 12', 'P.O. Box 835, 8868 Aliquam Ave', 'Minturno', '23288', 163873, 1),
(34, 1, 'Julian Stewart', 'Convallis Convallis Dolor Foundation', '02 17 49 79 42', '310-3354 Massa. Ave', 'Blackwood', '17101', 129058, 1),
(35, 2, 'Alden Mullen', 'Nam Ac PC', '02 18 15 01 10', 'P.O. Box 400, 6475 Aliquam Avenue', 'Vitacura', '55911', 236230, 1),
(36, 2, 'Ashton Gamble', 'Commodo Auctor Industries', '02 86 87 87 17', 'P.O. Box 577, 2343 Rutrum, Avenue', 'Santipur', 'DT9F 3QD', 262784, 1),
(37, 1, 'Hyatt Hood', 'Ipsum Suspendisse LLC', '02 75 20 99 26', 'P.O. Box 887, 2059 Lobortis Road', 'Bever Bievene', 'Z6425', 175090, 1),
(38, 2, 'Alan Valenzuela', 'Malesuada Consulting', '02 09 69 95 51', '2766 Quisque St.', 'Palermo', '010617', 252246, 1),
(39, 2, 'Ray Castaneda', 'Consectetuer Euismod Est Corp.', '02 96 78 54 33', '269-5933 Sollicitudin Rd.', 'Zhukovka', '98071', 134295, 1),
(40, 2, 'Philip Hood', 'Morbi Sit Amet LLC', '02 19 59 10 22', '794-9019 Dui, Rd.', 'Alto Hospicio', '89049-50171', 198265, 1),
(41, 1, 'Kieran Newton', 'Erat Company', '02 62 44 55 64', 'P.O. Box 100, 1045 Aliquam St.', 'Sechura', '5743 WK', 261067, 1),
(42, 2, 'Thane Reilly', 'Sem PC', '02 37 25 59 26', '9976 Lectus Street', 'Helmsdale', 'Z2304', 221011, 1),
(43, 1, 'Kibo Wood', 'Ante Dictum Inc.', '02 75 15 23 22', '708-2113 Leo Rd.', 'Orp-Jauche', '64557', 296798, 1),
(44, 2, 'Bernard Lane', 'Lorem Ac Risus Consulting', '02 80 65 15 30', 'P.O. Box 130, 4486 Neque Rd.', 'Ambresin', '246194', 145639, 1),
(45, 1, 'Stuart Patton', 'A Industries', '02 23 50 91 22', '365-5015 Nisi Avenue', 'Dampicourt', '12232', 250980, 1),
(46, 1, 'Philip Frederick', 'Ante Ipsum Primis LLC', '02 99 32 94 29', 'P.O. Box 798, 8410 Et, Ave', 'Grand-Reng', '70220', 165684, 1),
(47, 1, 'Armand Larsen', 'Ut Ipsum Ac Foundation', '02 61 40 86 40', '6603 Orci Avenue', 'Huelva', '107206', 136414, 1),
(48, 2, 'Castor Mueller', 'Id Ante Nunc Ltd', '02 69 39 04 50', '8665 Ridiculus Rd.', 'Zlatoust', '35736-524', 297227, 1),
(49, 1, 'Merritt Cross', 'Aliquet Molestie Foundation', '02 69 60 81 23', 'Ap #222-3298 Lorem Rd.', 'Essene', '44518', 234930, 1),
(50, 1, 'Emmanuel Morgan', 'Odio Foundation', '02 31 84 32 29', '401-1340 Parturient Road', 'Dosquebradas', '9923', 242954, 1),
(51, 1, 'Raja Jimenez', 'Gravida Molestie Arcu Consulting', '02 95 11 55 30', '7107 Felis. Ave', 'Kemzeke', 'Z3150', 121392, 1),
(52, 2, 'Joseph Velasquez', 'Duis Cursus Limited', '02 24 14 75 53', '617-2490 Volutpat. Avenue', 'Hollange', '0873 DC', 168427, 1),
(53, 2, 'Damon English', 'Lectus Company', '02 45 45 88 54', '866-4191 Fermentum Rd.', 'Vico del Gargano', 'G8C 4M3', 102830, 1),
(54, 1, 'Christopher Maldonado', 'Nec Imperdiet Institute', '02 15 75 44 57', '9090 Curabitur Av.', 'Dörtyol', '63028', 136033, 1),
(55, 1, 'Hector Snider', 'Fermentum Arcu Incorporated', '02 22 12 20 36', 'Ap #997-212 Sem, St.', 'Aubange', '79211', 277448, 1),
(56, 2, 'Matthew Riggs', 'Metus Eu Corporation', '02 28 03 12 32', 'Ap #466-8614 Urna. Av.', 'Casalvieri', 'Z5124', 168394, 1),
(57, 1, 'Geoffrey Hughes', 'Pede Institute', '02 39 90 13 70', '328-4688 Urna Road', 'Bailivre', '55465', 269282, 1),
(58, 1, 'Reese Hendrix', 'Augue Sed Molestie Limited', '02 45 62 38 64', '5943 Montes, Avenue', 'Jafarabad', '2233', 225702, 1),
(59, 2, 'Mufutau Jordan', 'Nulla Facilisis Corporation', '02 77 15 83 86', 'Ap #615-3403 Lobortis, Ave', 'Gouda', '81758', 174328, 1),
(60, 2, 'Herrod Boone', 'Ut Odio Institute', '02 57 60 98 86', '787-3415 Tincidunt Road', 'Mataró', '389830', 76355, 1),
(61, 2, 'Victor Hogan', 'Adipiscing Elit Curabitur PC', '02 28 62 09 52', '528-5820 Dictum St.', 'Montgomery', '1258 DZ', 71811, 1),
(62, 2, 'Tad Irwin', 'Vestibulum Consulting', '02 12 28 87 89', '4483 Morbi Street', 'Deschambault', '64724', 57119, 1),
(63, 2, 'Tad Harris', 'In Scelerisque Scelerisque Ltd', '02 80 06 44 76', '5065 Ac Street', 'Albi', '732513', 56401, 1),
(64, 2, 'Dolan Hahn', 'Sed Congue Ltd', '02 84 71 08 52', '270-5792 Ac Street', 'Heerhugowaard', '45708', 298984, 1),
(65, 1, 'Drew Davenport', 'A Facilisis Non Incorporated', '02 95 81 52 64', 'P.O. Box 295, 8426 Diam. Ave', 'Okpoko', 'LV0C 9VF', 296960, 1),
(66, 1, 'Cullen Becker', 'Lorem Limited', '02 30 97 15 31', 'Ap #496-9278 Ac Avenue', 'Jonesboro', 'ZK4D 3GN', 257987, 1),
(67, 1, 'Erich Mayer', 'Fringilla Purus Mauris Incorporated', '02 55 25 55 15', 'P.O. Box 142, 5825 Donec Avenue', 'Ipiales', '17415', 260438, 1),
(68, 1, 'Tucker Odonnell', 'Feugiat Lorem Incorporated', '02 74 73 79 70', 'Ap #943-6858 Suspendisse Road', 'Pabianice', '83707', 268952, 1),
(69, 2, 'Dennis Barnes', 'Vehicula Risus Limited', '02 09 07 01 33', 'Ap #294-2720 Ut Road', 'Tramatza', '204343', 237164, 1),
(70, 1, 'Steel Raymond', 'Et Associates', '02 24 98 02 84', '7487 Faucibus. Avenue', 'Snellegem', '0779 UK', 190459, 1),
(71, 1, 'Damian Dickerson', 'Eleifend Corporation', '02 50 42 82 91', 'Ap #414-6434 Ornare, Rd.', 'Erembodegem', '154865', 274439, 1),
(72, 1, 'Flynn Odom', 'Duis Ltd', '02 21 40 51 04', 'P.O. Box 311, 2140 Orci. Rd.', 'Cunco', 'E3W 7Z3', 123861, 1),
(73, 2, 'Donovan Rivas', 'A Inc.', '02 27 22 38 32', '292-8956 Adipiscing Road', 'Pugwash', '95075', 106487, 1),
(74, 2, 'Hiram Horton', 'Mauris Consulting', '02 25 36 70 27', 'Ap #306-6955 Curabitur Av.', 'Iowa City', '201174', 213265, 1),
(75, 1, 'Tyler Schneider', 'Non Dapibus Company', '02 49 74 36 54', '1180 Tortor. Avenue', 'Ellikom', '66958', 58361, 1),
(76, 2, 'Elliott Murray', 'Ullamcorper LLP', '02 00 01 24 44', '487-1335 Magna. Street', 'Yungay', '596325', 196524, 1),
(77, 2, 'Neil Grant', 'Curabitur Dictum Industries', '02 91 70 46 31', 'Ap #247-327 Ultrices. Rd.', 'San Marcello', '75344-064', 168802, 1),
(78, 1, 'Kenneth Ruiz', 'Malesuada Vel Company', '02 22 36 99 58', '164-7382 Imperdiet Av.', 'Santa Croce sull\'Arno', 'E7Z 7E8', 161864, 1),
(79, 2, 'Finn Patton', 'Leo Cras Ltd', '02 12 30 63 84', 'Ap #254-9936 Sodales. St.', 'San Cesario di Lecce', '49210', 122780, 1),
(80, 1, 'Colt Mullins', 'A Corporation', '02 66 46 92 41', '3633 Tristique Street', 'Fréjus', '19923', 86072, 1),
(81, 2, 'Reece Hinton', 'Felis Company', '02 57 39 98 38', 'Ap #650-6567 Tempor Ave', 'Compiègne', '19889', 93911, 1),
(82, 1, 'Zeus Foley', 'Libero Nec Company', '02 24 01 47 40', '297-2441 Lectus Avenue', 'Isle-aux-Coudres', '63583', 151857, 1),
(83, 1, 'Raymond Stevens', 'Mattis Associates', '02 26 50 99 94', 'Ap #654-923 At Rd.', 'Zwettl-Niederösterreich', '27918-269', 126271, 1),
(84, 2, 'Charles Parker', 'Curabitur Company', '02 41 17 99 02', '2092 Praesent Ave', 'Maranguape', '51405', 233871, 1),
(85, 2, 'Clarke Fitzgerald', 'Fusce Dolor Associates', '02 62 36 16 72', 'Ap #671-8369 Quis Ave', 'Rycroft', '02977', 275866, 1),
(86, 1, 'Harrison Brooks', 'Turpis Limited', '02 73 43 72 47', '2781 Mollis. Road', 'Birmingham', '3748', 260194, 1),
(87, 1, 'Rafael Hill', 'Quam Industries', '02 45 08 34 96', 'Ap #743-3222 Et St.', 'Ahmedabad', 'H8T 9E9', 179150, 1),
(88, 1, 'Hammett Sexton', 'Neque LLC', '02 02 57 41 31', '2048 Vitae Avenue', 'Jackson', '65888', 163407, 1),
(89, 2, 'Jordan Miles', 'Feugiat Consulting', '02 63 92 76 71', '903-9621 Tincidunt St.', 'Lloydminster', '35705-73965', 168752, 1),
(90, 2, 'Brett Gates', 'Elit Elit Fermentum Inc.', '02 21 50 48 42', 'P.O. Box 341, 5632 Hendrerit Av.', 'Newport News', 'B6R 9FH', 228257, 1),
(91, 2, 'Palmer Garcia', 'Placerat Eget Corp.', '02 41 55 45 45', '265-7165 Facilisis Rd.', 'Accadia', 'LZ2I 3BD', 273338, 1),
(92, 1, 'Ashton Daugherty', 'Luctus Inc.', '02 70 03 65 35', '827-1238 Malesuada Rd.', 'Lapscheure', '339677', 197871, 1),
(93, 2, 'Steel Bauer', 'Aliquam Auctor PC', '02 48 53 48 37', '180 Urna, Ave', 'Mannheim', '258249', 239297, 1),
(94, 2, 'Dillon Grant', 'Ultricies Industries', '02 29 40 12 85', '182-1701 Fermentum Rd.', 'Wood Buffalo', '43729', 73519, 1),
(95, 2, 'Conan Burke', 'Mi Company', '02 78 40 08 39', '6700 Semper Ave', 'Joliet', '46931', 216368, 1),
(96, 1, 'Carter Estes', 'Rhoncus LLP', '02 90 03 86 90', 'P.O. Box 488, 7562 Justo Road', 'Eastbourne', '516376', 94199, 1),
(97, 2, 'Malik Randall', 'Enim LLC', '02 96 11 70 53', '320-5000 Eleifend Ave', 'Camporotondo di Fiastrone', '31741', 213158, 1),
(98, 1, 'Theodore Morgan', 'Non Vestibulum Inc.', '02 36 76 73 86', '1119 Vulputate St.', 'Jaén', '38144', 264125, 1),
(99, 2, 'Aaron Roy', 'Suscipit Inc.', '02 32 83 34 46', 'P.O. Box 421, 2627 Iaculis Ave', 'Friedrichsdorf', '21313', 57292, 1),
(100, 2, 'Holmes Griffith', 'Ultricies Ornare Elit Consulting', '02 85 52 84 95', '8725 At St.', 'Central Jakarta', '0107', 152664, 1),
(222, 2, '87928', 'Globagence', '09 76 48 95 10', 'Rue Delille', 'La Roche Sur-Yon / 85000', '85000', 0, 1),
(223, 2, '12467', 'Globagence', '09 76 48 95 10', 'Rue Delille', 'La Roche Sur-Yon / 85000', '85000', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `OWNER`
--

CREATE TABLE `OWNER` (
  `idOwner` int(11) NOT NULL,
  `firstnameOwner` varchar(100) DEFAULT NULL,
  `lastnameOwner` varchar(100) DEFAULT NULL,
  `socialHeadquarters` varchar(100) DEFAULT NULL,
  `socialDenomination` varchar(100) DEFAULT NULL,
  `addressCityOwner` varchar(100) DEFAULT NULL,
  `addressStreetOwner` varchar(100) DEFAULT NULL,
  `postalCodeOwner` varchar(15) DEFAULT NULL,
  `phoneOwner` varchar(20) DEFAULT NULL,
  `mailOwner` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `socialReson` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `OWNER`
--

INSERT INTO `OWNER` (`idOwner`, `firstnameOwner`, `lastnameOwner`, `socialHeadquarters`, `socialDenomination`, `addressCityOwner`, `addressStreetOwner`, `postalCodeOwner`, `phoneOwner`, `mailOwner`, `gender`, `socialReson`, `facebook`, `twitter`) VALUES
(1, 'Georgia', 'Jamal', 'Mogi das Cruzes', 'accumsan', 'Shreveport', 'P.O. Box 807, 1950 Augue, Road', '29493', '07 89 95 56 19', 'hendrerit.consectetuer@dapibusgravida.org', ' Female', 'Amet LLC', 'a,', 'vestibulum'),
(2, 'Philip', 'Jin', 'Bernau', 'pellentesque', 'Tapachula', 'P.O. Box 139, 6712 Ut, Rd.', '9300', '07 57 04 32 61', 'et.magna@velvulputate.co.uk', 'Male ', 'Nulla Associates', 'tincidunt', 'vitae'),
(3, 'Burton', 'Moses', 'Gubbio', 'cubilia', 'Cametá', 'Ap #985-2828 Integer Avenue', '614745', '07 27 34 32 36', 'lacus@feugiatnon.com', ' Female', 'Enim Consulting', 'aliquam', 'est.'),
(4, 'Karly', 'Kuame', 'Meißen', 'sit', 'Fort Smith', 'Ap #630-5060 Cursus St.', '45123-20332', '07 92 16 05 41', 'lorem@faucibusMorbi.net', ' Female', 'Mollis Dui In Inc.', 'Etiam', 'adipiscing'),
(5, 'Bevis', 'Dahlia', 'Mazy', 'nunc', 'Chelyabinsk', 'Ap #109-1145 Morbi Rd.', '922197', '07 79 64 34 21', 'Fusce.mollis@nisi.com', 'Male ', 'Egestas Associates', 'dui.', 'ipsum'),
(6, 'Nichole', 'Madison', 'Tillet', 'in', 'Mosocw', 'Ap #464-433 Malesuada Street', '1038', '07 70 54 36 06', 'Cras.vehicula@Phasellus.net', ' Female', 'Aenean Egestas Hendrerit Consulting', 'et', 'dui.'),
(7, 'September', 'Tamekah', 'Neustadt', 'aliquam', 'Suncheon', '3870 Faucibus Road', '95357', '07 86 75 57 48', 'accumsan.interdum@enimconsequatpurus.co.uk', 'Male ', 'Ipsum Primis In Institute', 'Ut', 'ipsum'),
(8, 'Harriet', 'Martha', 'Buckingham', 'ligula.', 'West Jordan', 'Ap #398-5895 Nam St.', '46027', '07 89 13 69 18', 'in.faucibus.orci@asollicitudinorci.co.uk', ' Female', 'Lorem Eu LLC', 'nisi', 'quis'),
(9, 'Mariam', 'Linus', 'Castellina in Chianti', 'quis', 'Borriana', 'P.O. Box 321, 8759 Mattis. Av.', 'Z8081', '07 66 28 58 97', 'tellus@orci.org', 'Male ', 'Lobortis Class Aptent PC', 'vel', 'Aliquam'),
(10, 'Cairo', 'Geoffrey', 'Hawera', 'non', 'Chelsea', '122 Elit Av.', '29939', '07 35 41 37 16', 'amet.luctus@facilisisegetipsum.com', ' Female', 'Nulla Semper Institute', 'felis', 'Donec'),
(11, 'Leslie', 'Cain', 'Sikar', 'Pellentesque', 'Yeongju', 'Ap #263-8198 Pede. Rd.', '402708', '07 96 84 16 04', 'libero.mauris@mollislectuspede.co.uk', 'Male ', 'Ultrices Vivamus Rhoncus Inc.', 'orci', 'nec'),
(12, 'Rowan', 'Casey', 'Palagianello', 'Sed', 'Cabras', '638-9514 Egestas. Avenue', '79751', '07 31 24 78 43', 'Curae.Phasellus.ornare@nascetur.net', ' Female', 'Tincidunt Dui Augue Corporation', 'metus', 'eleifend'),
(13, 'Trevor', 'Elijah', 'Essex', 'neque.', 'Mörfelden-Walldorf', '5860 Mauris Road', '47537-53280', '07 08 53 68 45', 'augue.eu.tempor@tellusjusto.net', ' Female', 'Libero Nec Foundation', 'diam', 'luctus'),
(14, 'Gretchen', 'Jin', 'Meduno', 'malesuada', 'Heidenheim', '4562 Gravida. St.', '361817', '07 23 71 19 93', 'Integer.sem.elit@elit.com', ' Female', 'Nulla Eu Institute', 'tellus', 'sed'),
(15, 'Jayme', 'Mannix', 'Lennik', 'egestas.', 'Waitakere', 'P.O. Box 158, 684 Tellus Road', '9724', '07 63 83 19 93', 'elit.Nulla@Aliquamnecenim.ca', ' Female', 'Lorem Foundation', 'eu', 'diam.'),
(16, 'Nomlanga', 'Shelley', 'Malang', 'et', 'Witney', '689-5173 Luctus, Avenue', '13973', '07 33 97 85 37', 'eu@Nullamscelerisqueneque.com', 'Male ', 'Cum Sociis Associates', 'libero', 'consequat'),
(17, 'Hedda', 'Alec', 'Santomenna', 'risus,', 'Saint Paul', '6364 Metus. Street', '80563', '07 22 54 97 63', 'est@blanditviverra.edu', ' Female', 'Neque Inc.', 'dictum', 'interdum.'),
(18, 'Rhoda', 'William', 'Uluberia', 'natoque', 'Negrete', 'P.O. Box 300, 7352 Iaculis Rd.', 'M0Z 6M9', '07 16 73 05 77', 'tempor.lorem@Nullaeuneque.co.uk', 'Male ', 'Sit Amet Massa PC', 'lectus', 'sed,'),
(19, 'Vladimir', 'Camille', 'Camaragibe', 'vulputate', 'Barmouth', 'Ap #112-3039 Magna, St.', '5989', '07 16 33 60 42', 'ipsum.dolor@massaMaurisvestibulum.org', ' Female', 'Sociis Natoque Penatibus Inc.', 'Aenean', 'a'),
(20, 'Beverly', 'Whilemina', 'Rothes', 'Integer', 'Allentown', 'P.O. Box 122, 2760 Nunc Rd.', '01816', '07 81 67 11 19', 'lacus.Mauris.non@liberoInteger.net', 'Male ', 'Sit Amet LLC', 'In', 'et'),
(21, 'Melyssa', 'Idola', 'Rivière-du-Loup', 'semper', 'Novoli', '256-6632 Elit Rd.', '2827', '07 70 46 33 86', 'varius.ultrices@eleifendvitaeerat.ca', 'Male ', 'Proin Dolor Industries', 'inceptos', 'risus,'),
(22, 'Wesley', 'Alyssa', 'Paço do Lumiar', 'sodales', 'Gyeongju', '291-4230 Ante, Av.', '34969', '07 26 07 36 37', 'placerat.orci@nascetur.org', 'Male ', 'Nam Ac Nulla Ltd', 'ante', 'malesuada'),
(23, 'Quincy', 'Lev', 'Retie', 'consequat', 'Tarsia', 'P.O. Box 757, 4297 Nunc Av.', '27155-126', '07 68 40 94 82', 'tempor.lorem.eget@liberoInteger.ca', 'Male ', 'Mus Proin Vel Industries', 'in', 'Etiam'),
(24, 'Perry', 'Buffy', 'Columbus', 'placerat.', 'Ruoti', 'P.O. Box 285, 8056 Ornare Rd.', '40213', '07 99 12 40 62', 'nibh.dolor@utquam.net', 'Male ', 'Nisi LLC', 'interdum.', 'Morbi'),
(25, 'Indigo', 'Oprah', 'Limena', 'nulla.', 'Casnate con Bernate', 'Ap #535-6050 Cum Rd.', '34175', '07 23 60 84 80', 'nonummy.ut.molestie@variusNam.edu', 'Male ', 'Eget Massa Suspendisse Incorporated', 'eget,', 'risus.'),
(26, 'Shelley', 'Nathaniel', 'Kawerau', 'tristique', 'Dunkerque', '7335 Aliquam Avenue', 'LT13 7ZV', '07 88 01 61 18', 'Praesent.eu.nulla@placerateget.com', 'Male ', 'Etiam Laoreet Libero LLC', 'Nulla', 'ornare,'),
(27, 'Thaddeus', 'Denton', 'Emblem', 'Aliquam', 'Bunbury', '585-5592 Sodales St.', '244931', '07 97 99 94 88', 'Nulla.facilisi.Sed@estmollis.com', 'Male ', 'Congue In PC', 'vulputate,', 'ullamcorper.'),
(28, 'Geoffrey', 'Laura', 'Mussy-la-Ville', 'ultricies', 'Pochep', '914-5277 Id, Street', '15009', '07 55 59 03 58', 'vehicula@eutempor.ca', ' Female', 'Eu Odio Ltd', 'mollis', 'libero.'),
(29, 'Erasmus', 'Alika', 'Pugwash', 'gravida', 'Penna San Giovanni', 'Ap #518-4795 Commodo Avenue', '5952', '07 33 95 72 82', 'natoque@Donec.co.uk', 'Male ', 'Odio A PC', 'eget,', 'orci.'),
(30, 'Gemma', 'Lynn', 'Banbury', 'Nulla', 'Gwadar', '1886 Risus. St.', '72934-04601', '07 74 14 33 16', 'Nunc.ullamcorper.velit@Pellentesqueut.org', ' Female', 'Donec Consectetuer Mauris Consulting', 'commodo', 'bibendum'),
(31, 'Callie', 'Gareth', 'Garbsen', 'tellus', 'Waarloos', 'P.O. Box 872, 5846 Nec St.', '5380 EI', '07 60 99 24 98', 'egestas.Aliquam.fringilla@feliseget.ca', ' Female', 'Faucibus Leo In Foundation', 'fermentum', 'ullamcorper'),
(32, 'Hillary', 'Breanna', 'Daska', 'magna.', 'Worcester', '1686 Risus. Av.', '21839', '07 77 46 29 22', 'quam@natoquepenatibus.edu', 'Male ', 'Ut Ltd', 'magna,', 'In'),
(33, 'Vaughan', 'Knox', 'Malambo', 'nulla', 'Krasnozavodsk', '404-8275 Eu Road', '84-464', '07 27 83 60 80', 'eu.sem@sapien.net', 'Male ', 'Tellus Sem Associates', 'at', 'Etiam'),
(34, 'Upton', 'Hasad', 'Clydebank', 'Integer', 'Opdorp', 'P.O. Box 797, 1830 Est. Rd.', '4932', '07 65 15 53 26', 'metus.Aliquam.erat@parturientmontes.net', 'Male ', 'Malesuada Company', 'pede', 'at,'),
(35, 'Jacob', 'Clementine', 'Meix-Devant-Virton', 'Cras', 'Delta', '881-8494 Rutrum Ave', '48642-280', '07 11 91 28 26', 'vestibulum@bibendumullamcorper.net', 'Male ', 'Aenean Institute', 'Quisque', 'Cras'),
(36, 'Mark', 'Adam', 'Fourbechies', 'Ut', '', '', '', '07 22 81 69 98', 'nunc.nulla.vulputate@nequesed.org', 'Femme', 'Interdum Libero Dui LLC', 'Nulla', 'porttitor'),
(37, 'Bell', 'Jerome', 'Castelluccio Superiore', 'lorem', 'Tampa', 'P.O. Box 465, 9467 Ultricies Road', '746468', '07 10 72 18 19', 'at.augue.id@etmagnisdis.ca', ' Female', 'Lorem Eget Mollis LLP', 'faucibus', 'mollis.'),
(38, 'Kellie', 'Clio', 'Cumaribo', 'auctor,', 'Sheikhupura', 'Ap #592-9769 Malesuada Ave', '7124', '07 33 49 58 69', 'dui.Fusce.aliquam@facilisislorem.ca', ' Female', 'Ac Facilisis Corp.', 'eu', 'neque'),
(39, 'Lunea', 'Cleo', 'Quilpué', 'aliquam', 'Oaxaca', '868-2746 Luctus St.', '70744', '07 67 81 66 98', 'pretium@eratnequenon.org', 'Male ', 'Ac Libero Institute', 'ac', 'dolor'),
(40, 'Hakeem', 'Jared', 'Sukabumi', 'aliquet.', 'Jeongeup', '341-4095 Ultrices Ave', '8881', '07 36 79 53 30', 'congue.In@penatibus.ca', 'Male ', 'Tristique Associates', 'Etiam', 'nec'),
(41, 'Oscar', 'Tamekah', 'Zvenigorod', 'eros.', 'Remscheid', '3989 Rutrum Street', '5862 EL', '07 37 40 97 94', 'pretium.et@in.ca', ' Female', 'Egestas Rhoncus Company', 'arcu', 'metus'),
(42, 'Eaton', 'Alec', 'Naro-Fominsk', 'enim.', 'Terni', '9460 Turpis Av.', '88151', '07 09 80 04 24', 'Morbi.metus.Vivamus@posuereenimnisl.co.uk', ' Female', 'In Incorporated', 'vitae', 'libero'),
(43, 'Ocean', 'Bertha', 'Caprino Bergamasco', 'mus.', 'Poucet', 'P.O. Box 303, 9283 Ligula Street', '528515', '07 88 33 97 07', 'Nullam.feugiat@liberoest.org', ' Female', 'Praesent Eu Nulla Corp.', 'Duis', 'vulputate'),
(44, 'Quentin', 'Reece', 'Logan City', 'orci.', 'Coalville', 'Ap #918-5327 Lobortis St.', '525063', '07 92 45 18 51', 'id.erat.Etiam@volutpatnunc.co.uk', ' Female', 'At Limited', 'non', 'Morbi'),
(45, 'Noah', 'Cody', 'Tongerlo', 'nulla', 'Hattian Bala', '1200 Nec Ave', '382937', '07 24 16 73 42', 'dictum.cursus.Nunc@Suspendissetristiqueneque.com', ' Female', 'Posuere LLC', 'facilisis', 'Fusce'),
(46, 'Elliott', 'MacKensie', 'Hoogeveen', 'Curabitur', 'Delta', 'P.O. Box 441, 4110 Dolor St.', '56182', '07 47 20 19 04', 'Proin@Nulla.edu', 'Male ', 'Tellus Industries', 'Praesent', 'nibh'),
(47, 'Rana', 'Ian', 'Cossignano', 'in', 'Prato Carnico', '2350 Curabitur St.', '517839', '07 37 10 28 92', 'et.malesuada@nisl.net', 'Male ', 'Bibendum Sed LLC', 'senectus', 'Nulla'),
(48, 'Wang', 'Maggy', 'Siedlce', 'ac', 'Auldearn', 'Ap #503-3184 Aliquam Rd.', '01609', '07 48 82 83 73', 'Nam.tempor@Seddictum.com', ' Female', 'Sit Amet Corporation', 'ipsum.', 'nascetur'),
(49, 'Paloma', 'Hamish', 'Dumbarton', 'sem.', 'Wokingham', '5991 Egestas. St.', '2894', '07 79 66 98 03', 'mi.eleifend@auctorvelit.edu', 'Male ', 'Quis LLC', 'in', 'In'),
(50, 'Philip', 'Rylee', 'Mango', 'fringilla', 'Deline', '3165 Arcu. Rd.', '58889', '07 21 46 07 33', 'Nunc.ac@dolor.com', ' Female', 'Id LLP', 'urna', 'lorem,'),
(51, 'Marsden', 'Lamar', 'Neerharen', 'Proin', 'Bouwel', 'P.O. Box 214, 9508 Velit. Road', '9686', '07 90 23 21 81', 'cubilia.Curae.Phasellus@lorem.ca', 'Male ', 'Malesuada Fames Corporation', 'dictum', 'vel'),
(52, 'Oleg', 'Stone', 'Suwon', 'mi.', 'Salem', 'P.O. Box 845, 1164 Gravida. Rd.', '52307', '07 60 70 29 53', 'tempus.scelerisque.lorem@rhoncus.net', ' Female', 'Dui Company', 'montes,', 'non,'),
(53, 'Mason', 'David', 'Oosterhout', 'Sed', 'Fernie', '526-5363 Sit Ave', '4605', '07 76 53 57 62', 'et.rutrum.eu@Nullamutnisi.edu', ' Female', 'Donec PC', 'gravida', 'ornare'),
(54, 'Sybill', 'Elijah', 'Vremde', 'amet,', 'Hénin-Beaumont', 'Ap #834-828 Sociis Rd.', '29856', '07 84 03 71 82', 'magna@nondapibus.edu', 'Male ', 'Tempor Industries', 'feugiat.', 'eu,'),
(55, 'Abra', 'Callum', '', '', 'Acosse', 'P.O. Box 431, 3675 Cursus Street', 'C7K 8E5', '07 85 66 93 31', 'risus.Duis@anteVivamus.net', ' Female', '', 'purus', 'ac'),
(56, 'Shaeleigh', 'Sydney', 'Delianuova', 'ac', 'Asigliano Veneto', 'Ap #696-388 A Avenue', '186575', '07 17 15 29 88', 'purus.Maecenas@malesuadamalesuadaInteger.edu', ' Female', 'Dictum Eleifend Nunc PC', 'Duis', 'elit,'),
(57, 'Wallace', 'Lars', 'Couture-Saint-Germain', 'non', 'Ethe', 'P.O. Box 256, 4822 Ornare Road', '3318', '07 49 24 54 25', 'quis.urna@consequatenim.edu', 'Male ', 'Odio Ltd', 'Nullam', 'elit'),
(58, 'Delilah', 'Laura', 'Bihar Sharif', 'amet,', 'Wyoming', 'P.O. Box 278, 7641 Semper St.', '7126', '07 40 13 91 93', 'ac.eleifend@convallis.com', 'Male ', 'Sagittis Augue Eu Incorporated', 'semper,', 'euismod'),
(59, 'Ivana', 'Barrett', '', '', 'Freux', '438-4959 Magna. St.', '78959', '07 52 56 66 46', 'Sed@placeratCras.ca', 'Femme', '', 'adipiscing', 'Fusce'),
(60, 'Noel', 'Ava', 'Te Awamutu', 'posuere,', 'Girona', 'P.O. Box 147, 360 Est. St.', '81229', '07 03 99 04 32', 'nec.metus@sapienAenean.net', 'Male ', 'Ornare Lectus Ante Inc.', 'amet', 'eu,'),
(61, 'Simon', 'Tana', 'Verkhny Ufaley', 'sem', 'Fürth', '1394 Eu St.', '33092', '07 81 78 56 84', 'dui@accumsaninterdum.net', 'Male ', 'At Sem Industries', 'sed', 'Cras'),
(62, 'Reuben', 'Kai', 'Barghe', 'urna', 'Stratford-upon-Avon', 'P.O. Box 743, 5188 Duis St.', '3578', '07 94 20 42 51', 'elit@non.edu', 'Male ', 'Lobortis Augue Scelerisque Limited', 'odio.', 'lectus'),
(63, 'Hiram', 'Kalia', 'Sunset Point', 'Ut', 'San Vicente', 'Ap #871-3107 Leo. Avenue', '8307', '07 54 23 53 30', 'sed@cursus.net', ' Female', 'Nam Porttitor Limited', 'mi', 'ut,'),
(64, 'Lacy', 'Teegan', 'Avin', 'massa.', 'Abohar', '609-2906 Risus, Av.', '16233-525', '07 94 41 93 32', 'eleifend.nec@ultricesaauctor.co.uk', 'Male ', 'In Nec Orci Corporation', 'purus', 'auctor'),
(65, 'Odysseus', 'Yoko', 'Montalto Uffugo', 'sociosqu', 'Fernie', 'Ap #877-8032 Ornare St.', 'P7R 5Y5', '07 04 25 80 77', 'tellus@lorem.com', ' Female', 'Ac Risus Morbi Foundation', 'facilisis.', 'Etiam'),
(66, 'Morgan', 'Owen', 'Damoh', 'id', 'Rycroft', 'Ap #921-7755 Aliquam St.', '837611', '07 56 37 48 25', 'sed.tortor@molestie.co.uk', ' Female', 'Ipsum Industries', 'ullamcorper,', 'posuere'),
(67, 'Phoebe', 'Shad', 'Lithgow', 'tristique', 'Brodick', 'Ap #899-7655 Massa. Rd.', '34550', '07 94 74 63 29', 'ligula@urna.edu', 'Male ', 'Fringilla Cursus PC', 'quam', 'Phasellus'),
(68, 'Britanney', 'Jerome', 'Tapachula', 'sodales', 'Seltso', '642-1953 Fermentum St.', '56869', '07 36 99 84 89', 'accumsan@et.co.uk', 'Male ', 'Justo Praesent Corporation', 'auctor', 'Maecenas'),
(69, 'Ina', 'Maia', 'Barrhead', 'placerat,', 'Gliwice', 'P.O. Box 331, 9861 Mauris Rd.', '68-366', '07 42 42 99 92', 'Integer.urna@a.ca', 'Male ', 'Ante Corp.', 'sodales', 'et'),
(70, 'Shelley', 'Chase', 'Ham-sur-Sambre', 'libero.', 'Marche-les-Dames', '8225 Ultricies St.', '91271', '07 56 20 65 03', 'vulputate.velit@pedeac.ca', 'Male ', 'Non Lorem Vitae Industries', 'enim.', 'consequat,'),
(71, 'Meredith', 'Brennan', 'Częstochowa', 'erat.', 'Pohang', 'P.O. Box 232, 6187 Condimentum. St.', '0506', '07 07 27 85 28', 'nisi@eu.com', 'Male ', 'Arcu Consulting', 'ipsum.', 'molestie'),
(72, 'Faith', 'Latifah', 'Georgia', 'neque.', 'Santarcangelo di Romagna', '694-2966 Sociis St.', '61043', '07 09 64 92 78', 'rutrum.Fusce.dolor@faucibusut.ca', ' Female', 'Urna Convallis Incorporated', 'Pellentesque', 'semper'),
(73, 'Tamara', 'Hayley', 'Bremen', 'lacus,', 'Coronel', 'Ap #309-1818 Vestibulum Av.', '677217', '07 69 13 89 69', 'convallis.ante.lectus@aliquamarcu.net', 'Male ', 'Venenatis A Magna Foundation', 'aliquet.', 'enim.'),
(74, 'Stacy', 'Simone', 'Carunchio', 'purus,', 'Otukpo', 'Ap #138-8605 Cursus Street', '03238', '07 05 48 61 57', 'Maecenas.iaculis@variusorci.co.uk', ' Female', 'Nonummy Ipsum Limited', 'Phasellus', 'ligula.'),
(75, 'Charity', 'Anjolie', 'Novy Oskol', 'mauris', 'Dumbarton', 'Ap #124-9083 Ligula. Av.', '639827', '07 47 77 80 08', 'fringilla@ultriciesligulaNullam.edu', 'Male ', 'Leo Elementum Sem Industries', 'sit', 'Aliquam'),
(76, 'Kylan', 'Gage', 'Cereté', 'malesuada', 'Ipswich', 'Ap #828-3562 Nonummy. Rd.', 'SV8 4WC', '07 05 74 71 94', 'dolor.Fusce@augueSedmolestie.com', ' Female', 'Bibendum Company', 'et', 'tincidunt'),
(77, 'Orson', 'Astra', 'Brive-la-Gaillarde', 'aliquam', 'Juliaca', '4314 Elit Avenue', '2664', '07 98 25 13 90', 'sed.dictum@Uttinciduntvehicula.com', 'Male ', 'Morbi Quis Company', 'pellentesque.', 'nibh.'),
(78, 'Quon', 'Lara', 'Heusden-Zolder', 'sed', 'Sedgewick', 'P.O. Box 333, 5882 Pede. Road', '598996', '07 24 23 57 72', 'arcu.vel@nonsollicitudin.ca', 'Male ', 'Tortor Nibh Sit Company', 'eros', 'Integer'),
(79, 'Carl', 'Aladdin', 'Mobile', 'Aliquam', 'Köflach', '738-4080 Mauris Road', '3616', '07 97 16 92 47', 'ultrices.sit@semconsequat.co.uk', 'Male ', 'Aptent Taciti Inc.', 'lectus,', 'at'),
(80, 'Brent', 'Bernard', 'Satka', 'nunc', 'Daegu', '845-4221 A Street', '45-069', '07 91 81 79 53', 'vitae@noncursusnon.co.uk', 'Male ', 'Hendrerit Neque Ltd', 'Nam', 'consectetuer'),
(81, 'Carson', 'Buckminster', 'Destelbergen', 'eros', 'Qualicum Beach', '2600 Tempor Rd.', '10804', '07 84 35 41 89', 'Integer.sem.elit@dolorelitpellentesque.co.uk', 'Male ', 'Est Congue LLP', 'Sed', 'lorem'),
(82, 'Elmo', 'Catherine', 'Guysborough', 'convallis', 'Bajardo', 'Ap #250-3011 Sapien, Avenue', '8587', '07 88 42 58 92', 'Aenean.gravida.nunc@vitaealiquam.com', ' Female', 'Sed Eget LLC', 'lacinia', 'Nulla'),
(83, 'Libby', 'Daria', 'Kansas City', 'mauris', 'Mauá', 'P.O. Box 651, 3201 Nec Road', '791674', '07 70 06 77 07', 'eget.metus@eu.net', ' Female', 'Congue A Aliquet LLC', 'arcu', 'viverra.'),
(84, 'Shelby', 'Kuame', 'Chennai', 'magna', 'Holman', 'P.O. Box 416, 1975 Natoque Ave', '84-149', '07 77 64 00 68', 'ac@risus.ca', ' Female', 'Erat Vivamus Nisi Institute', 'enim', 'vitae,'),
(85, 'Adrian', 'Tanek', 'Owensboro', 'dolor.', 'Sotteville-lès-Rouen', '755-4209 Vulputate, Avenue', '8622', '07 18 80 32 39', 'congue@QuisquevariusNam.ca', ' Female', 'Praesent Interdum Ligula Corporation', 'arcu.', 'arcu.'),
(86, 'Reese', 'Chadwick', 'Pochep', 'magnis', 'St. Petersburg', 'Ap #151-5339 In Street', '6618', '07 48 95 76 44', 'dolor@erategettincidunt.ca', 'Male ', 'Gravida Praesent Eu Limited', 'interdum.', 'iaculis'),
(87, 'Sacha', 'Sean', 'Bègles', 'magna,', 'Campobasso', 'Ap #986-5459 Hendrerit Av.', '07-066', '07 04 28 06 04', 'arcu@tinciduntduiaugue.ca', ' Female', 'Arcu Imperdiet Company', 'magna.', 'ut,'),
(88, 'Colt', 'Alice', 'Santipur', 'urna.', 'Bonn', 'Ap #230-5038 Lorem St.', '40512', '07 41 26 70 15', 'malesuada@Donecsollicitudinadipiscing.edu', 'Male ', 'Pede Institute', 'gravida', 'vel,'),
(89, 'Shellie', 'Gisela', 'Badin', 'dapibus', 'Lithgow', 'Ap #100-5522 Magna. Road', '4806', '07 57 12 53 66', 'posuere.cubilia@nisl.com', ' Female', 'At Company', 'tempus', 'arcu.'),
(90, 'Ivor', 'Alvin', 'Comblain-la-Tour', 'erat', 'Parkland County', '345-2796 Euismod Rd.', '3555', '07 36 91 73 56', 'Nullam.vitae.diam@facilisis.co.uk', ' Female', 'Sociis Natoque Penatibus Institute', 'Cras', 'mus.'),
(91, 'Laura', 'Isaac', 'San José de Alajuela', 'mi', 'Tulita', '253-9078 Turpis Road', '77-624', '07 78 21 31 31', 'Aliquam.adipiscing.lobortis@scelerisqueneque.org', ' Female', 'Cursus A Enim Institute', 'tristique', 'quis'),
(92, 'Macon', 'Gareth', 'Ludwigshafen', 'magna', 'Rosoux-Crenwick', 'P.O. Box 290, 7760 Nec, Road', '9174', '07 46 49 16 30', 'penatibus@arcu.edu', ' Female', 'Venenatis Inc.', 'auctor', 'eget'),
(93, 'Lenore', 'Sylvia', 'Bendigo', 'Nam', 'Venlo', '311-3130 Ut St.', '43488', '07 93 85 63 90', 'ultricies.dignissim@semelit.com', ' Female', 'Ipsum Ac Mi LLC', 'a', 'enim.'),
(94, 'Elaine', 'Brent', 'Joué-lès-Tours', 'vulputate,', 'Wasseiges', 'Ap #940-8106 Nulla St.', 'GN33 4RA', '07 54 08 32 53', 'Proin@acturpisegestas.net', 'Male ', 'Pede Ltd', 'tellus.', 'Nullam'),
(95, 'Brent', 'Gemma', 'Villa Latina', 'vulputate,', 'Alix', '1499 Egestas Rd.', '885720', '07 16 67 39 02', 'malesuada@porttitorinterdumSed.edu', ' Female', 'Purus PC', 'nunc', 'justo.'),
(96, 'Kuame', 'Aristotle', 'San Juan del Cesar', 'ultrices.', 'Bansberia', 'Ap #989-9703 Etiam St.', '509875', '07 72 02 20 72', 'mauris@atpede.org', ' Female', 'Ac Corp.', 'metus.', 'iaculis'),
(97, 'Colton', 'Xandra', 'Cerami', 'Maecenas', 'Montemilone', 'P.O. Box 502, 3144 Eu Road', '8462', '07 05 24 50 96', 'est@nascetur.co.uk', 'Male ', 'Vel Est Tempor LLC', 'at,', 'risus.'),
(98, 'Amos', 'Elvis', 'Sim', 'Donec', 'Puqueldón', '262-5357 Eu Rd.', '6170', '07 25 91 25 65', 'Aliquam.vulputate.ullamcorper@orciadipiscing.com', 'Male ', 'Massa Non Ante Corp.', 'malesuada', 'accumsan'),
(99, 'Noble', 'Jelani', 'Bekasi', 'metus.', 'Lanester', '141-9256 Vestibulum Rd.', '8280', '07 66 61 53 86', 'Sed.eget@asollicitudinorci.net', ' Female', 'Ipsum Ltd', 'Nulla', 'nascetur'),
(100, 'Teagan', 'Britanney', 'Trinità d\'Agultu e Vignola', 'eu,', 'Eisden', '222-7846 Egestas Avenue', 'Y0E 7P3', '07 02 74 70 65', 'pede.nonummy@facilisis.edu', ' Female', 'Arcu Curabitur Foundation', 'nec', 'dolor'),
(216, '', '', '', '', '', '', '', '', '', 'Femme', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `PROPERTY`
--

CREATE TABLE `PROPERTY` (
  `idProperty` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `typeProperty_id` int(11) NOT NULL,
  `nbRoom` int(3) DEFAULT NULL,
  `constructionDate` date DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `pictures` varchar(255) DEFAULT NULL,
  `propertySurface` int(5) DEFAULT NULL,
  `propertyGround` int(5) DEFAULT NULL,
  `addressStreetProperty` varchar(200) DEFAULT NULL,
  `addressCityProperty` varchar(50) DEFAULT NULL,
  `postalCodeProperty` varchar(10) DEFAULT NULL,
  `locality` varchar(50) DEFAULT NULL,
  `buildingNumber` int(4) DEFAULT NULL,
  `ISPPrice` float DEFAULT NULL,
  `agencyFee` float DEFAULT NULL,
  `expenses_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `PROPERTY`
--

INSERT INTO `PROPERTY` (`idProperty`, `owner_id`, `typeProperty_id`, `nbRoom`, `constructionDate`, `comment`, `pictures`, `propertySurface`, `propertyGround`, `addressStreetProperty`, `addressCityProperty`, `postalCodeProperty`, `locality`, `buildingNumber`, `ISPPrice`, `agencyFee`, `expenses_id`) VALUES
(1, 1, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(2, 2, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(3, 3, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(4, 4, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(5, 5, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(6, 6, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(7, 7, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(8, 8, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(9, 9, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(10, 10, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(11, 11, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(12, 12, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(13, 13, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(14, 14, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(15, 15, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(16, 16, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(17, 17, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(18, 18, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(19, 19, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(20, 20, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(21, 21, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(22, 22, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(23, 23, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(24, 24, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(25, 25, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(26, 26, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(27, 27, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(28, 28, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(29, 29, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(30, 30, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(31, 31, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(32, 32, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(33, 33, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(34, 34, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(35, 35, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(36, 36, 1, 2, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(37, 37, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(38, 38, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(39, 39, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(40, 40, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(41, 41, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(42, 42, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(43, 43, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(44, 44, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(45, 45, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(46, 46, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(47, 47, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(48, 48, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(49, 49, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(50, 50, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(51, 51, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(52, 52, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(53, 53, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(54, 54, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(55, 55, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(56, 56, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(57, 57, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(58, 58, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(59, 59, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(60, 60, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(61, 61, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(62, 62, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(63, 63, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(64, 64, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(65, 65, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(66, 66, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(67, 67, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(68, 68, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(69, 69, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(70, 70, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(71, 71, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(72, 72, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(73, 73, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(74, 74, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(75, 75, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(76, 76, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(77, 77, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(78, 78, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(79, 79, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(80, 80, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(81, 81, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(82, 82, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(83, 83, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(84, 84, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(85, 85, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(86, 86, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(87, 87, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(88, 88, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(89, 89, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(90, 90, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(91, 91, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(92, 92, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(93, 93, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(94, 94, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(95, 95, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(96, 96, 1, 0, '2020-04-01', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(97, 97, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(98, 98, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(99, 99, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(100, 100, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1),
(199, 216, 1, 0, '0000-00-00', '', '', 0, 0, '', '', '', '', 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `PURCHASE`
--

CREATE TABLE `PURCHASE` (
  `idPurchase` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `statutPurchase_id` int(11) NOT NULL,
  `startPurchase_date` date DEFAULT NULL,
  `endPurchase_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `PURCHASE`
--

INSERT INTO `PURCHASE` (`idPurchase`, `property_id`, `statutPurchase_id`, `startPurchase_date`, `endPurchase_date`) VALUES
(1, 1, 1, '2021-03-13', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `ROOM`
--

CREATE TABLE `ROOM` (
  `idRoom` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `libelleRoom` varchar(100) DEFAULT NULL,
  `surface` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ROOM`
--

INSERT INTO `ROOM` (`idRoom`, `property_id`, `libelleRoom`, `surface`) VALUES
(1, 7, ' Cuisine ', '7'),
(2, 7, ' Garage ', '9'),
(3, 1, ' Toilette ', '10'),
(4, 1, ' Garage ', '10'),
(5, 7, ' Chambre ', '9'),
(6, 7, ' Séjour ', '7'),
(7, 6, 'Salle de bain ', '8'),
(8, 8, ' Séjour ', '10'),
(9, 3, 'Salle de bain ', '5'),
(10, 8, 'Salle de bain ', '7'),
(11, 10, ' Toilette ', '6'),
(12, 5, ' Chambre ', '10'),
(13, 1, 'Salle de bain ', '6'),
(14, 1, ' Chambre ', '8'),
(15, 9, ' Cuisine ', '7'),
(16, 10, 'Salle de bain ', '6'),
(17, 2, ' Garage ', '8'),
(18, 6, ' Chambre ', '9'),
(19, 7, '  Toilette ', '9'),
(20, 6, ' Chambre ', '7'),
(21, 9, ' Chambre ', '9'),
(22, 7, ' Chambre ', '7'),
(23, 7, ' Cuisine ', '5'),
(24, 3, ' Séjour ', '9'),
(25, 2, ' Cuisine ', '7'),
(26, 5, 'Salle de bain ', '10'),
(27, 3, ' Cuisine ', '8'),
(28, 3, ' Chambre ', '6'),
(29, 2, ' Garage ', '6'),
(30, 10, ' Garage ', '7'),
(31, 5, ' Chambre ', '10'),
(32, 6, '  Toilette ', '6'),
(33, 5, ' Garage ', '5'),
(34, 2, ' Garage ', '10'),
(35, 9, ' Séjour ', '9'),
(36, 8, ' Toilette ', '5'),
(37, 3, ' Chambre ', '7'),
(38, 7, ' Garage ', '7'),
(39, 5, ' Séjour ', '7'),
(40, 6, ' Cuisine ', '9'),
(41, 6, 'Salle de bain ', '7'),
(42, 7, ' Garage ', '6'),
(43, 10, ' Séjour ', '10'),
(44, 1, '  Toilette ', '6'),
(45, 10, ' Garage ', '5'),
(46, 4, ' Toilette ', '8'),
(47, 5, ' Chambre ', '9'),
(48, 2, ' Chambre ', '6'),
(49, 5, '  Chambre ', '7'),
(50, 8, ' Cuisine ', '10'),
(51, 4, 'Salle de bain ', '9'),
(52, 4, '  Chambre ', '8'),
(53, 4, ' Cuisine ', '10'),
(54, 4, ' Chambre ', '8'),
(55, 6, ' Séjour ', '9'),
(56, 5, ' Toilette ', '7'),
(57, 3, '  Chambre ', '6'),
(58, 4, '  Chambre ', '8'),
(59, 4, ' Cuisine ', '8'),
(60, 8, '  Chambre ', '6'),
(61, 9, ' Chambre ', '8'),
(62, 5, 'Salle de bain ', '10'),
(63, 7, ' Garage ', '10'),
(64, 4, ' Garage ', '7'),
(65, 3, ' Chambre ', '10'),
(66, 6, '  Chambre ', '6'),
(67, 1, ' Chambre ', '7'),
(68, 6, ' Chambre ', '8'),
(69, 2, ' Toilette ', '8'),
(70, 8, ' Séjour ', '6'),
(71, 4, 'Salle de bain ', '6'),
(72, 9, ' Garage ', '8'),
(73, 7, ' Toilette ', '10'),
(74, 9, ' Garage ', '6'),
(75, 7, ' Chambre ', '10'),
(76, 9, ' Chambre ', '6'),
(77, 2, ' Toilette ', '5'),
(78, 2, '  Chambre ', '6'),
(79, 8, ' Toilette ', '10'),
(80, 1, '  Chambre ', '10'),
(81, 5, ' Chambre ', '9'),
(82, 6, ' Garage ', '9'),
(83, 10, 'Salle de bain ', '6'),
(84, 9, ' Toilette ', '5'),
(85, 4, ' Chambre ', '6'),
(86, 3, ' Chambre ', '9'),
(87, 8, ' Cuisine ', '6'),
(88, 5, 'Salle de bain ', '10'),
(89, 5, ' Toilette ', '8'),
(90, 3, '  Chambre ', '9'),
(91, 9, ' Garage ', '6'),
(92, 3, ' Toilette ', '8'),
(93, 7, ' Garage ', '10'),
(94, 9, ' Chambre ', '8'),
(95, 9, ' Garage ', '7'),
(96, 8, ' Cuisine ', '8'),
(97, 10, '  Chambre ', '7'),
(98, 6, ' Garage ', '9'),
(99, 1, ' Garage ', '6'),
(100, 4, ' Cuisine ', '7'),
(101, 11, ' Garage ', '10'),
(102, 14, ' Garage ', '7'),
(103, 19, 'Salle de bain ', '7'),
(104, 18, ' Séjour ', '9'),
(105, 15, ' Garage ', '7'),
(106, 13, ' Toilette ', '6'),
(107, 14, 'Salle de bain ', '6'),
(108, 15, ' Garage ', '6'),
(109, 12, ' Cuisine ', '7'),
(110, 16, ' Cuisine ', '5'),
(111, 14, ' Séjour ', '10'),
(112, 12, '  Chambre ', '5'),
(113, 18, 'Salle de bain ', '7'),
(114, 19, 'Salle de bain ', '9'),
(115, 20, ' Toilette ', '8'),
(116, 11, 'Salle de bain ', '7'),
(117, 20, ' Toilette ', '8'),
(118, 18, ' Séjour ', '7'),
(119, 19, ' Garage ', '8'),
(120, 19, ' Chambre ', '9'),
(121, 16, 'Salle de bain ', '7'),
(122, 17, ' Chambre ', '8'),
(123, 19, 'Salle de bain ', '6'),
(124, 20, ' Cuisine ', '7'),
(125, 13, '  Chambre ', '9'),
(126, 14, ' Toilette ', '8'),
(127, 13, ' Garage ', '9'),
(128, 12, ' Garage ', '10'),
(129, 11, ' Garage ', '5'),
(130, 20, 'Salle de bain ', '10'),
(131, 11, ' Toilette ', '9'),
(132, 20, '  Chambre ', '6'),
(133, 14, ' Cuisine ', '10'),
(134, 19, ' Toilette ', '5'),
(135, 19, '  Chambre ', '6'),
(136, 15, 'Salle de bain ', '10'),
(137, 13, ' Garage ', '6'),
(138, 20, ' Séjour ', '6'),
(139, 17, 'Salle de bain ', '9'),
(140, 12, ' Chambre ', '10'),
(141, 17, ' Garage ', '5'),
(142, 20, 'Salle de bain ', '10'),
(143, 14, '  Chambre ', '10'),
(144, 13, 'Salle de bain ', '9'),
(145, 20, '  Chambre ', '9'),
(146, 14, '  Chambre ', '6'),
(147, 14, 'Salle de bain ', '10'),
(148, 11, ' Garage ', '10'),
(149, 18, ' Séjour ', '9'),
(150, 17, 'Salle de bain ', '10'),
(151, 20, 'Salle de bain ', '7'),
(152, 20, ' Séjour ', '5'),
(153, 12, ' Toilette ', '6'),
(154, 11, ' Garage ', '6'),
(155, 15, ' Garage ', '8'),
(156, 12, '  Chambre ', '9'),
(157, 15, 'Salle de bain ', '10'),
(158, 19, ' Chambre ', '5'),
(159, 12, ' Cuisine ', '9'),
(160, 12, 'Salle de bain ', '9'),
(161, 12, ' Chambre ', '9'),
(162, 18, ' Garage ', '9'),
(163, 19, ' Garage ', '5'),
(164, 13, ' Toilette ', '6'),
(165, 11, ' Toilette ', '7'),
(166, 20, ' Séjour ', '8'),
(167, 12, ' Cuisine ', '6'),
(168, 19, ' Toilette ', '8'),
(169, 19, ' Séjour ', '9'),
(170, 12, ' Garage ', '5'),
(171, 17, ' Toilette ', '5'),
(172, 20, ' Séjour ', '7'),
(173, 17, ' Toilette ', '5'),
(174, 19, ' Toilette ', '7'),
(175, 13, ' Garage ', '6'),
(176, 11, '  Chambre ', '7'),
(177, 19, ' Séjour ', '10'),
(178, 15, ' Cuisine ', '10'),
(179, 14, '  Chambre ', '10'),
(180, 15, ' Séjour ', '7'),
(181, 12, ' Séjour ', '7'),
(182, 12, ' Séjour ', '7'),
(183, 17, ' Cuisine ', '7'),
(184, 19, ' Garage ', '5'),
(185, 17, ' Toilette ', '10'),
(186, 12, ' Toilette ', '10'),
(187, 14, 'Salle de bain ', '9'),
(188, 12, ' Garage ', '10'),
(189, 17, 'Salle de bain ', '8'),
(190, 15, '  Chambre ', '8'),
(191, 16, ' Cuisine ', '5'),
(192, 18, ' Garage ', '9'),
(193, 17, ' Toilette ', '9'),
(194, 13, ' Garage ', '7'),
(195, 16, ' Garage ', '5'),
(196, 19, ' Séjour ', '8'),
(197, 15, ' Garage ', '8'),
(198, 19, ' Cuisine ', '7'),
(199, 17, ' Séjour ', '8'),
(200, 17, ' Garage ', '9'),
(201, 27, ' Toilette ', '8'),
(202, 22, ' Séjour ', '5'),
(203, 27, ' Garage ', '6'),
(204, 28, 'Salle de bain ', '6'),
(205, 29, ' Garage ', '5'),
(206, 23, ' Garage ', '7'),
(207, 25, ' Garage ', '6'),
(208, 23, ' Séjour ', '7'),
(209, 27, ' Garage ', '5'),
(210, 27, ' Toilette ', '6'),
(211, 30, ' Séjour ', '8'),
(212, 22, ' Chambre ', '8'),
(213, 23, '  Chambre', '5'),
(214, 28, ' Garage ', '7'),
(215, 25, ' Séjour ', '6'),
(216, 22, '  Chambre', '8'),
(217, 27, ' Cuisine ', '9'),
(218, 23, ' Cuisine ', '6'),
(219, 24, ' Garage ', '5'),
(220, 23, ' Séjour ', '5'),
(221, 23, ' Garage ', '7'),
(222, 21, ' Cuisine ', '7'),
(223, 27, ' Toilette ', '7'),
(224, 30, ' Cuisine ', '7'),
(225, 30, ' Garage ', '6'),
(226, 22, ' Séjour ', '6'),
(227, 25, 'Salle de bain ', '9'),
(228, 24, ' Cuisine ', '5'),
(229, 21, ' Toilette ', '7'),
(230, 24, ' Toilette ', '10'),
(231, 22, ' Garage ', '10'),
(232, 28, 'Salle de bain ', '5'),
(233, 24, 'Salle de bain ', '10'),
(234, 23, ' Garage ', '5'),
(235, 23, ' Séjour ', '5'),
(236, 29, 'Salle de bain ', '10'),
(237, 22, ' Garage ', '8'),
(238, 30, ' Garage ', '5'),
(239, 25, ' Séjour ', '5'),
(240, 25, 'Salle de bain ', '7'),
(241, 22, ' Séjour ', '6'),
(242, 26, ' Séjour ', '9'),
(243, 30, ' Garage ', '5'),
(244, 28, ' Toilette ', '8'),
(245, 27, ' Toilette ', '10'),
(246, 25, ' Garage ', '9'),
(247, 28, 'Salle de bain ', '8'),
(248, 23, ' Chambre ', '6'),
(249, 27, ' Séjour ', '7'),
(250, 21, ' Séjour ', '7'),
(251, 29, '  Chambre', '9'),
(252, 27, ' Chambre ', '7'),
(253, 24, ' Cuisine ', '6'),
(254, 28, ' Toilette ', '10'),
(255, 23, ' Toilette ', '9'),
(256, 30, 'Salle de bain ', '8'),
(257, 27, ' Garage ', '6'),
(258, 27, ' Toilette ', '7'),
(259, 26, '  Chambre', '6'),
(260, 28, ' Garage ', '7'),
(261, 26, ' Séjour ', '10'),
(262, 25, ' Cuisine ', '8'),
(263, 28, ' Toilette ', '5'),
(264, 29, ' Garage ', '6'),
(265, 25, 'Salle de bain ', '9'),
(266, 28, ' Toilette ', '9'),
(267, 22, ' Cuisine ', '9'),
(268, 23, ' Garage ', '5'),
(269, 24, 'Salle de bain ', '6'),
(270, 26, ' Garage ', '9'),
(271, 29, ' Séjour ', '9'),
(272, 30, ' Séjour ', '8'),
(273, 26, ' Garage ', '5'),
(274, 26, ' Séjour ', '8'),
(275, 30, ' Garage ', '7'),
(276, 28, ' Chambre ', '7'),
(277, 24, ' Garage ', '9'),
(278, 23, ' Chambre ', '10'),
(279, 26, 'Salle de bain ', '7'),
(280, 30, ' Cuisine ', '6'),
(281, 29, 'Salle de bain ', '9'),
(282, 27, '  Chambre', '9'),
(283, 29, ' Séjour ', '5'),
(284, 23, ' Garage ', '9'),
(285, 23, 'Salle de bain ', '6'),
(286, 24, 'Salle de bain ', '9'),
(287, 24, ' Toilette ', '5'),
(288, 30, ' Cuisine ', '5'),
(289, 26, ' Chambre ', '8'),
(290, 26, ' Chambre ', '8'),
(291, 22, '  Chambre', '7'),
(292, 22, ' Cuisine ', '5'),
(293, 24, ' Garage ', '9'),
(294, 21, ' Garage ', '5'),
(295, 25, ' Garage ', '10'),
(296, 26, ' Garage ', '10'),
(297, 25, ' Chambre', '7'),
(298, 28, ' Chambre ', '6'),
(299, 29, ' Séjour ', '8'),
(300, 22, '  Chambre', '7'),
(301, 39, ' Chambre ', '5'),
(302, 39, 'Salle de bain ', '8'),
(304, 38, ' Cuisine ', '5'),
(305, 37, ' Chambre ', '7'),
(306, 34, ' Toilette ', '8'),
(307, 35, ' Garage ', '10'),
(308, 35, 'Salle de bain ', '7'),
(309, 33, '  Chambre', '5'),
(311, 35, ' Garage ', '9'),
(312, 39, ' Chambre ', '10'),
(313, 37, ' Garage ', '8'),
(314, 40, '  Chambre', '6'),
(317, 33, '  Chambre', '5'),
(318, 39, '  Chambre', '7'),
(319, 34, ' Garage ', '6'),
(320, 40, 'Salle de bain ', '9'),
(321, 32, '  Chambre', '7'),
(322, 35, ' Toilette ', '6'),
(323, 38, ' Garage ', '5'),
(324, 37, ' Garage ', '6'),
(325, 37, ' Toilette ', '7'),
(326, 40, ' Garage ', '10'),
(327, 40, ' Cuisine ', '6'),
(328, 34, 'Salle de bain ', '10'),
(329, 38, ' Garage ', '5'),
(331, 32, ' Cuisine ', '7'),
(333, 39, ' Garage ', '6'),
(335, 35, ' Garage ', '9'),
(336, 39, ' Garage ', '9'),
(337, 32, '  Chambre', '8'),
(338, 35, ' Garage ', '8'),
(340, 33, ' Garage ', '7'),
(341, 35, ' Garage ', '5'),
(342, 38, ' Garage ', '5'),
(343, 34, ' Garage ', '5'),
(344, 32, ' Toilette ', '9'),
(345, 38, ' Garage ', '7'),
(346, 34, ' Garage ', '9'),
(347, 31, ' Chambre ', '8'),
(349, 31, 'Salle de bain ', '8'),
(350, 35, ' Chambre ', '5'),
(351, 35, '  Chambre', '6'),
(352, 38, ' Toilette ', '10'),
(353, 31, ' Séjour ', '9'),
(354, 38, ' Cuisine ', '5'),
(355, 31, ' Cuisine ', '10'),
(356, 34, ' Chambre ', '6'),
(357, 37, ' Toilette ', '8'),
(358, 35, 'Salle de bain ', '5'),
(359, 31, ' Cuisine ', '9'),
(360, 39, ' Garage ', '6'),
(362, 33, ' Cuisine ', '5'),
(363, 40, ' Garage ', '9'),
(364, 40, 'Salle de bain ', '7'),
(365, 40, ' Chambre ', '9'),
(366, 40, ' Cuisine ', '10'),
(367, 32, ' Garage ', '10'),
(368, 37, ' Chambre ', '7'),
(369, 40, ' Garage ', '6'),
(370, 35, ' Séjour ', '6'),
(371, 32, ' Garage ', '6'),
(372, 34, ' Garage ', '9'),
(373, 32, '  Chambre', '10'),
(374, 39, 'Salle de bain ', '5'),
(375, 37, ' Séjour ', '6'),
(376, 34, ' Garage ', '8'),
(377, 33, ' Toilette ', '7'),
(378, 37, '  Chambre', '9'),
(379, 38, ' Séjour ', '10'),
(380, 35, ' Toilette ', '9'),
(381, 35, 'Salle de bain ', '8'),
(382, 31, ' Garage ', '8'),
(384, 32, ' Garage ', '8'),
(385, 35, ' Chambre ', '6'),
(386, 39, ' Séjour ', '8'),
(387, 34, ' Séjour ', '7'),
(389, 39, ' Séjour ', '8'),
(390, 32, ' Chambre ', '10'),
(391, 34, ' Chambre ', '10'),
(392, 40, ' Garage ', '7'),
(393, 39, ' Garage ', '8'),
(394, 38, ' Garage ', '10'),
(395, 38, ' Chambre ', '5'),
(396, 31, ' Garage ', '8'),
(397, 37, ' Garage ', '10'),
(398, 39, ' Cuisine ', '6'),
(399, 39, ' Toilette ', '10'),
(400, 37, ' Garage ', '7'),
(401, 49, ' Séjour ', '5'),
(402, 48, ' Garage ', '10'),
(403, 42, ' Garage ', '9'),
(404, 48, 'Salle de bain ', '5'),
(405, 48, ' Toilette ', '5'),
(406, 45, ' Toilette ', '9'),
(407, 48, ' Séjour ', '5'),
(408, 46, ' Cuisine ', '6'),
(409, 42, ' Garage ', '10'),
(410, 50, ' Cuisine ', '8'),
(411, 42, ' Toilette ', '10'),
(412, 50, ' Séjour ', '8'),
(413, 47, '  Chambre', '9'),
(414, 47, '  Chambre', '8'),
(415, 41, ' Garage ', '6'),
(416, 41, '  Chambre', '7'),
(417, 49, ' Séjour ', '7'),
(418, 49, ' Garage ', '5'),
(419, 41, ' Séjour ', '6'),
(420, 48, ' Cuisine ', '6'),
(421, 41, ' Toilette ', '10'),
(422, 41, 'Salle de bain ', '8'),
(423, 47, '  Chambre', '6'),
(424, 42, ' Garage ', '8'),
(425, 41, ' Garage ', '5'),
(426, 43, ' Chambre ', '7'),
(427, 48, ' Cuisine ', '10'),
(428, 48, ' Toilette ', '5'),
(429, 43, ' Toilette ', '5'),
(430, 44, 'Salle de bain ', '6'),
(431, 43, ' Chambre ', '5'),
(432, 45, ' Chambre ', '7'),
(433, 50, ' Cuisine ', '5'),
(434, 43, ' Garage ', '9'),
(435, 49, ' Séjour ', '5'),
(436, 48, ' Garage ', '7'),
(437, 47, ' Garage ', '10'),
(438, 46, 'Salle de bain ', '8'),
(439, 41, ' Garage ', '10'),
(440, 43, ' Toilette ', '5'),
(441, 42, '  Chambre', '8'),
(442, 46, ' Cuisine ', '9'),
(443, 42, ' Séjour ', '6'),
(444, 48, ' Séjour ', '5'),
(445, 50, ' Cuisine ', '8'),
(446, 47, 'Salle de bain ', '10'),
(447, 48, '  Chambre', '10'),
(448, 46, ' Chambre ', '6'),
(449, 43, ' Garage ', '6'),
(450, 47, 'Salle de bain ', '10'),
(451, 47, ' Chambre ', '10'),
(452, 49, ' Séjour ', '5'),
(453, 41, ' Cuisine ', '5'),
(454, 42, ' Chambre ', '6'),
(455, 50, ' Chambre ', '6'),
(456, 46, ' Toilette ', '6'),
(457, 46, ' Cuisine ', '10'),
(458, 43, ' Garage ', '7'),
(459, 47, ' Toilette ', '7'),
(460, 50, '  Chambre', '7'),
(461, 50, ' Chambre ', '10'),
(462, 41, 'Salle de bain ', '10'),
(463, 46, '  Chambre', '8'),
(464, 46, ' Chambre ', '5'),
(465, 49, ' Chambre ', '10'),
(466, 45, ' Chambre ', '5'),
(467, 44, ' Cuisine ', '7'),
(468, 48, '  Chambre', '5'),
(469, 43, ' Toilette ', '9'),
(470, 49, ' Chambre ', '9'),
(471, 45, ' Cuisine ', '10'),
(472, 46, ' Garage ', '8'),
(473, 46, ' Cuisine ', '6'),
(474, 50, ' Garage ', '6'),
(475, 48, 'Salle de bain ', '9'),
(476, 41, ' Garage ', '8'),
(477, 47, ' Garage ', '5'),
(478, 44, ' Toilette ', '6'),
(479, 46, ' Cuisine ', '9'),
(480, 42, ' Chambre ', '8'),
(481, 50, ' Garage ', '5'),
(482, 41, ' Chambre ', '9'),
(483, 50, '  Chambre', '5'),
(484, 50, ' Cuisine ', '7'),
(485, 50, ' Cuisine ', '7'),
(486, 46, ' Séjour ', '7'),
(487, 42, 'Salle de bain ', '7'),
(488, 41, ' Garage ', '10'),
(489, 41, 'Salle de bain ', '5'),
(490, 42, ' Garage ', '5'),
(491, 43, ' Garage ', '8'),
(492, 43, ' Cuisine ', '10'),
(493, 47, ' Cuisine ', '8'),
(494, 46, ' Toilette ', '6'),
(495, 43, ' Chambre ', '7'),
(496, 43, 'Salle de bain ', '10'),
(497, 48, '  Chambre', '10'),
(498, 41, ' Séjour ', '6'),
(499, 41, ' Garage ', '9'),
(500, 48, ' Cuisine ', '5'),
(501, 57, ' Garage ', '10'),
(502, 58, ' Séjour ', '9'),
(503, 57, ' Toilette ', '9'),
(504, 52, ' Séjour ', '9'),
(505, 52, ' Cuisine ', '6'),
(506, 58, 'Salle de bain ', '10'),
(507, 53, ' Toilette ', '9'),
(508, 52, ' Cuisine ', '10'),
(509, 55, ' Séjour ', '10'),
(510, 57, '  Chambre', '8'),
(511, 52, ' Séjour ', '5'),
(513, 51, ' Séjour ', '9'),
(514, 53, ' Séjour ', '7'),
(515, 55, ' Chambre ', '9'),
(516, 56, ' Cuisine ', '10'),
(517, 55, ' Séjour ', '8'),
(518, 53, '  Chambre', '10'),
(519, 51, 'Salle de bain ', '9'),
(520, 58, 'Salle de bain ', '8'),
(521, 57, ' Garage ', '7'),
(522, 51, ' Séjour ', '7'),
(523, 60, 'Salle de bain ', '5'),
(524, 56, ' Séjour ', '6'),
(525, 60, ' Chambre ', '8'),
(527, 52, ' Chambre ', '9'),
(528, 56, ' Séjour ', '10'),
(529, 53, ' Garage ', '10'),
(530, 60, ' Cuisine ', '7'),
(531, 56, ' Toilette ', '10'),
(532, 51, ' Chambre ', '6'),
(533, 54, '  Chambre', '6'),
(534, 51, ' Cuisine ', '8'),
(535, 60, ' Garage ', '6'),
(536, 57, 'Salle de bain ', '5'),
(537, 52, ' Séjour ', '5'),
(538, 55, ' Garage ', '8'),
(539, 57, ' Cuisine ', '5'),
(540, 58, ' Garage ', '8'),
(541, 58, ' Séjour ', '8'),
(542, 56, ' Garage ', '6'),
(543, 55, 'Salle de bain ', '8'),
(544, 54, '  Chambre', '5'),
(545, 58, 'Salle de bain ', '10'),
(546, 55, 'Salle de bain ', '10'),
(547, 51, 'Salle de bain ', '10'),
(549, 51, ' Cuisine ', '7'),
(550, 60, ' Séjour ', '9'),
(551, 58, ' Cuisine ', '5'),
(552, 51, ' Séjour ', '7'),
(553, 52, '  Chambre', '6'),
(554, 54, '  Chambre', '9'),
(555, 51, ' Garage ', '8'),
(556, 57, ' Séjour ', '8'),
(557, 54, ' Cuisine ', '10'),
(558, 51, ' Cuisine ', '7'),
(559, 54, ' Séjour ', '8'),
(561, 60, ' Séjour ', '5'),
(562, 55, ' Chambre ', '9'),
(563, 52, 'Salle de bain ', '6'),
(564, 58, ' Séjour ', '10'),
(565, 56, ' Garage ', '6'),
(566, 52, '  Chambre', '6'),
(567, 55, ' Garage ', '9'),
(568, 60, ' Séjour ', '5'),
(569, 58, ' Séjour ', '10'),
(570, 54, 'Salle de bain ', '10'),
(571, 52, ' Cuisine ', '9'),
(572, 54, ' Garage ', '9'),
(573, 57, ' Cuisine ', '8'),
(574, 57, ' Garage ', '6'),
(575, 53, ' Chambre ', '10'),
(576, 53, ' Garage ', '10'),
(577, 54, '  Chambre', '6'),
(578, 56, ' Toilette ', '6'),
(579, 51, ' Garage ', '9'),
(580, 54, ' Chambre ', '7'),
(581, 57, ' Séjour ', '5'),
(582, 56, ' Garage ', '8'),
(583, 55, ' Séjour ', '8'),
(584, 55, '  Chambre', '10'),
(585, 51, ' Toilette ', '5'),
(586, 55, ' Garage ', '7'),
(587, 54, '  Chambre', '6'),
(588, 55, ' Cuisine ', '5'),
(590, 55, ' Garage ', '6'),
(591, 58, ' Toilette ', '10'),
(592, 52, ' Cuisine ', '7'),
(593, 52, 'Salle de bain ', '7'),
(594, 53, 'Salle de bain ', '9'),
(596, 52, '  Chambre', '8'),
(597, 51, ' Garage ', '7'),
(598, 56, ' Cuisine ', '10'),
(599, 55, ' Chambre ', '6'),
(600, 55, ' Séjour ', '9'),
(601, 62, 'Salle de bain ', '9'),
(602, 65, ' Garage ', '5'),
(603, 66, 'Salle de bain ', '6'),
(604, 67, ' Garage ', '8'),
(605, 66, 'Salle de bain ', '10'),
(606, 63, ' Séjour ', '9'),
(607, 69, ' Toilette ', '10'),
(608, 70, 'Salle de bain ', '6'),
(609, 69, ' Cuisine ', '8'),
(610, 65, 'Salle de bain ', '6'),
(611, 64, ' Séjour ', '7'),
(612, 67, ' Garage ', '10'),
(613, 69, '  Chambre', '7'),
(614, 65, '  Chambre', '10'),
(615, 67, ' Cuisine ', '10'),
(616, 68, ' Cuisine ', '8'),
(617, 67, ' Chambre ', '10'),
(618, 64, ' Garage ', '9'),
(619, 69, ' Garage ', '10'),
(620, 68, '  Chambre', '8'),
(621, 63, '  Chambre', '6'),
(622, 66, '  Chambre', '6'),
(623, 69, '  Chambre', '5'),
(624, 70, ' Séjour ', '8'),
(625, 65, ' Toilette ', '8'),
(626, 65, ' Cuisine ', '6'),
(627, 63, ' Cuisine ', '7'),
(628, 67, ' Toilette ', '10'),
(629, 63, ' Chambre ', '9'),
(630, 64, ' Chambre ', '8'),
(631, 66, '  Chambre', '9'),
(632, 67, ' Garage ', '8'),
(633, 67, ' Séjour ', '8'),
(634, 62, ' Toilette ', '9'),
(635, 66, ' Cuisine ', '9'),
(636, 61, 'Salle de bain ', '5'),
(637, 63, 'Salle de bain ', '6'),
(638, 69, ' Toilette ', '9'),
(639, 68, ' Cuisine ', '7'),
(640, 65, '  Chambre', '6'),
(641, 61, ' Séjour ', '5'),
(642, 68, ' Cuisine ', '9'),
(643, 68, ' Chambre ', '6'),
(644, 70, ' Séjour ', '9'),
(645, 62, 'Salle de bain ', '9'),
(646, 62, ' Garage ', '9'),
(647, 61, ' Chambre ', '7'),
(648, 61, ' Cuisine ', '7'),
(649, 67, ' Cuisine ', '9'),
(650, 69, ' Garage ', '6'),
(651, 66, ' Garage ', '10'),
(652, 65, ' Garage ', '9'),
(653, 61, ' Garage ', '5'),
(654, 62, ' Garage ', '5'),
(655, 67, ' Chambre ', '6'),
(656, 61, '  Chambre', '9'),
(657, 70, ' Séjour ', '5'),
(658, 69, ' Cuisine ', '5'),
(659, 65, '  Chambre', '10'),
(660, 62, ' Cuisine ', '5'),
(661, 68, ' Toilette ', '5'),
(662, 65, ' Séjour ', '9'),
(663, 65, '  Chambre', '10'),
(664, 63, ' Cuisine ', '7'),
(665, 63, ' Chambre ', '7'),
(666, 69, ' Garage ', '9'),
(667, 61, ' Cuisine ', '6'),
(668, 68, ' Cuisine ', '8'),
(669, 61, 'Salle de bain ', '7'),
(670, 70, ' Séjour ', '6'),
(671, 70, ' Séjour ', '9'),
(672, 65, ' Garage ', '5'),
(673, 65, ' Toilette ', '9'),
(674, 68, ' Toilette ', '5'),
(675, 70, ' Cuisine ', '8'),
(676, 62, ' Garage ', '6'),
(677, 61, ' Garage ', '7'),
(678, 67, ' Toilette ', '6'),
(679, 70, ' Chambre ', '6'),
(680, 64, ' Garage ', '5'),
(681, 64, ' Cuisine ', '9'),
(682, 65, '  Chambre', '6'),
(683, 63, ' Séjour ', '10'),
(684, 70, ' Toilette ', '5'),
(685, 66, ' Chambre ', '5'),
(686, 64, ' Garage ', '7'),
(687, 68, ' Séjour ', '6'),
(688, 62, ' Cuisine ', '8'),
(689, 70, '  Chambre', '6'),
(690, 69, 'Salle de bain ', '10'),
(691, 65, ' Garage ', '7'),
(692, 68, ' Chambre ', '9'),
(693, 64, ' Garage ', '8'),
(694, 65, 'Salle de bain ', '8'),
(695, 65, ' Cuisine ', '5'),
(696, 64, ' Toilette ', '8'),
(697, 64, '  Chambre', '6'),
(698, 62, ' Cuisine ', '8'),
(699, 62, ' Cuisine ', '6'),
(700, 67, '  Chambre', '7'),
(701, 77, ' ', '5'),
(702, 76, ' Garage ', '8'),
(703, 74, ' Cuisine ', '6'),
(704, 74, ' Toilette ', '6'),
(705, 78, '  Chambre', '8'),
(706, 79, ' Chambre ', '9'),
(707, 80, ' Toilette ', '9'),
(708, 71, ' Séjour ', '6'),
(709, 77, ' Garage ', '9'),
(710, 74, '  Chambre', '6'),
(711, 79, ' Toilette ', '10'),
(712, 76, ' Cuisine ', '9'),
(713, 80, ' Chambre', '8'),
(714, 80, ' Séjour ', '8'),
(715, 79, ' Chambre ', '5'),
(716, 77, ' Garage ', '8'),
(717, 79, ' Garage ', '8'),
(718, 80, 'Salle de bain ', '9'),
(719, 75, ' Séjour ', '6'),
(720, 78, ' Garage ', '6'),
(721, 77, ' Cuisine ', '5'),
(722, 79, ' Séjour ', '6'),
(723, 78, ' Chambre ', '5'),
(724, 77, ' Toilette ', '9'),
(725, 76, ' Garage ', '5'),
(726, 75, ' Chambre ', '7'),
(727, 74, ' Séjour ', '6'),
(728, 79, '  Chambre', '6'),
(729, 78, 'Salle de bain ', '8'),
(730, 78, ' Garage ', '5'),
(731, 72, ' Garage ', '8'),
(732, 75, ' Garage ', '10'),
(733, 74, ' Cuisine ', '10'),
(734, 72, ' Garage ', '5'),
(735, 79, ' Chambre ', '9'),
(736, 71, ' Garage ', '8'),
(737, 74, ' Chambre ', '9'),
(738, 72, 'Salle de bain ', '8'),
(739, 77, 'Salle de bain ', '5'),
(740, 71, ' Chambre ', '5'),
(741, 80, ' Séjour ', '10'),
(742, 79, '  Chambre', '5'),
(743, 78, ' Garage ', '9'),
(744, 74, ' Chambre ', '10'),
(745, 74, '  Chambre', '9'),
(746, 79, ' Garage ', '7'),
(747, 76, ' Chambre ', '9'),
(748, 73, '  Chambre', '10'),
(749, 78, ' Garage ', '10'),
(750, 76, ' Toilette ', '5'),
(751, 71, 'Salle de bain ', '5'),
(752, 72, ' Séjour ', '10'),
(753, 72, ' Cuisine ', '6'),
(754, 75, 'Salle de bain ', '8'),
(755, 76, '  Chambre', '10'),
(756, 73, ' Séjour ', '8'),
(757, 75, ' Toilette ', '7'),
(758, 71, '  Chambre', '7'),
(759, 75, '  Chambre', '5'),
(760, 75, ' Cuisine ', '5'),
(761, 78, ' Garage ', '6'),
(762, 75, ' Toilette ', '9'),
(763, 74, ' Toilette ', '6'),
(764, 77, ' Garage ', '9'),
(765, 75, ' Chambre ', '6'),
(766, 77, ' Cuisine ', '9'),
(767, 75, ' Cuisine ', '7'),
(768, 78, ' Séjour ', '9'),
(769, 75, '  Chambre', '8'),
(770, 74, ' Chambre ', '9'),
(771, 73, ' Cuisine ', '9'),
(772, 72, ' Garage ', '10'),
(773, 71, ' Cuisine ', '6'),
(774, 80, ' Chambre ', '9'),
(775, 76, ' Garage ', '8'),
(776, 80, ' Cuisine ', '6'),
(777, 80, '  Chambre', '7'),
(778, 75, ' Garage ', '5'),
(779, 73, ' Séjour ', '10'),
(780, 74, ' Garage ', '10'),
(781, 73, ' Cuisine ', '5'),
(782, 76, ' Garage ', '9'),
(783, 74, ' Chambre ', '9'),
(784, 80, ' Chambre ', '7'),
(785, 78, ' Chambre', '6'),
(786, 79, '  Chambre', '9'),
(787, 79, ' Chambre ', '8'),
(788, 71, ' Séjour ', '7'),
(789, 75, ' Séjour ', '10'),
(790, 76, ' Chambre ', '8'),
(791, 77, ' Garage ', '6'),
(792, 75, ' Toilette ', '6'),
(793, 73, ' Garage ', '6'),
(794, 80, ' Toilette ', '9'),
(795, 78, ' Séjour ', '6'),
(796, 73, ' Toilette ', '7'),
(797, 77, ' Cuisine ', '10'),
(798, 78, ' Toilette ', '10'),
(799, 72, ' Garage ', '7'),
(800, 79, ' Garage ', '5'),
(801, 83, ' Garage ', '9'),
(802, 82, ' Séjour ', '5'),
(803, 82, '  Chambre', '8'),
(804, 84, '  Chambre', '5'),
(805, 82, '  Chambre', '5'),
(806, 84, ' Toilette ', '8'),
(807, 88, ' Garage ', '5'),
(808, 87, ' Séjour ', '5'),
(809, 90, ' Séjour ', '5'),
(810, 81, ' Chambre ', '5'),
(811, 83, ' Cuisine ', '5'),
(812, 85, 'Salle de bain ', '8'),
(813, 85, ' Garage ', '7'),
(814, 89, ' Séjour ', '9'),
(815, 82, 'Salle de bain ', '8'),
(816, 83, ' Chambre ', '9'),
(817, 87, ' Garage ', '8'),
(818, 81, ' Garage ', '7'),
(819, 88, ' Garage ', '8'),
(820, 86, ' Garage ', '8'),
(821, 83, ' Cuisine ', '5'),
(822, 87, ' Toilette ', '5'),
(823, 82, 'Salle de bain ', '7'),
(824, 88, ' Toilette ', '6'),
(825, 85, ' Toilette ', '9'),
(826, 85, ' Séjour ', '10'),
(827, 82, ' Garage ', '6'),
(828, 85, ' Garage ', '5'),
(829, 90, ' Cuisine ', '9'),
(830, 81, ' Toilette ', '6'),
(831, 81, 'Salle de bain ', '8'),
(832, 83, '  Chambre', '8'),
(833, 85, ' Chambre ', '7'),
(834, 90, '  Chambre', '10'),
(835, 84, '  Chambre', '6'),
(836, 83, ' Cuisine ', '9'),
(837, 82, ' Chambre ', '6'),
(838, 86, ' Garage ', '7'),
(839, 82, ' Cuisine ', '10'),
(840, 83, 'Salle de bain ', '7'),
(841, 87, ' Garage ', '6'),
(842, 82, ' Chambre ', '5'),
(843, 89, ' Cuisine ', '8'),
(844, 88, ' Cuisine ', '6'),
(845, 86, ' Chambre ', '8'),
(846, 87, ' Chambre ', '7'),
(847, 90, ' Garage ', '10'),
(848, 86, 'Salle de bain ', '5'),
(849, 82, ' Chambre ', '6'),
(850, 82, ' Cuisine ', '5'),
(851, 85, ' Chambre ', '8'),
(852, 85, ' Garage ', '8'),
(853, 88, ' Toilette ', '8'),
(854, 90, ' Toilette ', '9'),
(855, 85, ' Garage ', '10'),
(856, 85, 'Salle de bain ', '10'),
(857, 85, ' Garage ', '8'),
(858, 85, ' Cuisine ', '10'),
(859, 83, ' Toilette ', '7'),
(860, 84, 'Salle de bain ', '9'),
(861, 82, ' Chambre ', '9'),
(862, 89, ' Chambre', '6'),
(863, 86, ' Garage ', '7'),
(864, 85, ' Garage ', '5'),
(865, 89, ' Chambre ', '8'),
(866, 87, ' Séjour ', '6'),
(867, 90, ' Garage ', '9'),
(868, 85, 'Salle de bain ', '10'),
(869, 81, ' Toilette ', '9'),
(870, 82, 'Salle de bain ', '5'),
(871, 88, ' Garage ', '8'),
(872, 89, ' Garage ', '9'),
(873, 88, ' Garage ', '10'),
(874, 83, ' Garage ', '10'),
(875, 89, ' Chambre ', '7'),
(876, 90, ' Chambre ', '8'),
(877, 85, ' Chambre ', '9'),
(878, 87, ' Chambre ', '5'),
(879, 84, ' Garage ', '7'),
(880, 82, '  Chambre', '9'),
(881, 90, ' Garage ', '9'),
(882, 90, 'Salle de bain ', '5'),
(883, 86, ' Toilette ', '10'),
(884, 90, 'Salle de bain ', '7'),
(885, 88, 'Salle de bain ', '7'),
(886, 90, ' Garage ', '6'),
(887, 86, '  Chambre', '9'),
(888, 86, ' Garage ', '8'),
(889, 87, ' Garage ', '8'),
(890, 89, ' Cuisine ', '7'),
(891, 86, ' Séjour ', '6'),
(892, 89, ' Garage ', '9'),
(893, 87, ' Toilette ', '10'),
(894, 81, ' Toilette ', '5'),
(895, 89, ' Chambre ', '9'),
(896, 90, ' Toilette ', '9'),
(897, 90, ' Garage ', '7'),
(898, 86, 'Salle de bain ', '10'),
(899, 88, ' Garage ', '5'),
(900, 81, ' Cuisine ', '7'),
(901, 95, ' Garage ', '5'),
(902, 93, ' Cuisine ', '6'),
(903, 99, ' Toilette ', '6'),
(904, 98, ' Chambre ', '8'),
(905, 97, ' Garage ', '10'),
(906, 96, ' Chambre ', '5'),
(907, 95, ' Cuisine ', '5'),
(908, 99, ' Garage ', '7'),
(909, 92, ' Toilette ', '8'),
(910, 96, ' Chambre ', '5'),
(911, 99, ' Garage ', '6'),
(912, 98, ' Cuisine ', '10'),
(913, 97, ' Cuisine ', '10'),
(914, 98, ' Chambre ', '10'),
(915, 92, 'Salle de bain ', '5'),
(916, 91, 'Salle de bain ', '6'),
(917, 99, ' Chambre ', '9'),
(918, 93, ' Séjour ', '9'),
(919, 93, ' Garage ', '10'),
(920, 93, ' Garage ', '10'),
(921, 95, ' Garage ', '9'),
(922, 94, ' Garage ', '5'),
(923, 100, ' Cuisine ', '6'),
(924, 95, ' Cuisine ', '10'),
(925, 92, '  Chambre', '8'),
(926, 98, ' Chambre ', '8'),
(927, 98, ' Séjour ', '7'),
(928, 96, ' Séjour ', '5'),
(929, 91, ' Garage ', '9'),
(930, 95, '  Chambre', '6'),
(931, 95, ' Garage ', '9'),
(932, 94, '  Chambre', '9'),
(933, 92, ' Cuisine ', '6'),
(934, 95, ' Garage ', '5'),
(935, 95, ' Cuisine ', '7'),
(936, 96, ' Garage ', '8'),
(937, 99, ' Cuisine ', '6'),
(938, 95, ' Garage ', '5'),
(939, 94, 'Salle de bain ', '5'),
(940, 97, ' Séjour ', '9'),
(941, 92, ' Garage ', '9'),
(942, 96, ' Garage ', '7'),
(943, 95, 'Salle de bain ', '10'),
(944, 95, ' Garage ', '8'),
(945, 97, ' Séjour ', '9'),
(946, 91, ' Garage ', '6'),
(947, 96, ' Garage ', '10'),
(948, 94, ' Chambre ', '5'),
(949, 95, ' Séjour ', '9'),
(950, 100, ' Chambre ', '10'),
(951, 95, ' Cuisine ', '5'),
(952, 96, ' Séjour ', '5'),
(953, 96, ' Chambre ', '9'),
(954, 95, ' Cuisine ', '7'),
(955, 96, ' Séjour ', '5'),
(956, 96, '  Chambre', '10'),
(957, 91, ' Garage ', '8'),
(958, 97, 'Salle de bain ', '9'),
(959, 92, ' Garage ', '10'),
(960, 98, '  Chambre', '8'),
(961, 95, ' Toilette ', '7'),
(962, 98, ' Garage ', '7'),
(963, 92, 'Salle de bain ', '8'),
(964, 91, 'Salle de bain ', '9'),
(965, 94, ' Cuisine ', '10'),
(966, 98, ' Toilette ', '5'),
(967, 97, ' Cuisine ', '5'),
(968, 97, ' Chambre ', '8'),
(969, 99, ' Chambre', '5'),
(970, 91, ' Toilette ', '6'),
(971, 97, ' Toilette ', '5'),
(972, 97, ' Cuisine ', '8'),
(973, 97, ' Garage ', '5'),
(974, 95, ' Garage ', '9'),
(975, 94, ' Garage ', '10'),
(976, 97, ' Cuisine ', '6'),
(977, 93, ' Chambre ', '8'),
(978, 97, ' Toilette ', '9'),
(979, 93, ' Toilette ', '8'),
(980, 97, 'Salle de bain ', '6'),
(981, 91, ' Cuisine ', '10'),
(982, 92, ' Garage ', '10'),
(983, 94, 'Salle de bain ', '6'),
(984, 95, ' Séjour ', '7'),
(985, 95, ' Toilette ', '8'),
(986, 94, ' Garage ', '9'),
(987, 95, ' Chambre ', '6'),
(988, 92, ' Cuisine ', '6'),
(989, 92, ' Séjour ', '10'),
(990, 100, ' Toilette ', '8'),
(991, 97, ' Chambre ', '8'),
(992, 97, ' Séjour ', '7'),
(993, 99, ' Toilette ', '9'),
(994, 93, '  Chambre', '8'),
(995, 94, '  Chambre', '9'),
(996, 92, '  Chambre', '5'),
(997, 100, ' Cuisine ', '7'),
(998, 93, ' Séjour ', '6'),
(999, 100, ' Toilette ', '7'),
(1000, 93, ' Chambre ', '8');

-- --------------------------------------------------------

--
-- Table structure for table `SANITATION`
--

CREATE TABLE `SANITATION` (
  `idSanitation` int(11) NOT NULL,
  `libelleSanitation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `SANITATION`
--

INSERT INTO `SANITATION` (`idSanitation`, `libelleSanitation`) VALUES
(1, 'Pas d\'assainissement'),
(2, 'Individuel'),
(3, 'Collectif');

-- --------------------------------------------------------

--
-- Table structure for table `SIGN`
--

CREATE TABLE `SIGN` (
  `owner_id` int(11) NOT NULL,
  `consultant_id` int(11) NOT NULL,
  `mandate_id` int(11) NOT NULL,
  `date_signature` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `SIGN`
--

INSERT INTO `SIGN` (`owner_id`, `consultant_id`, `mandate_id`, `date_signature`) VALUES
(216, 1, 223, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `STATUT_MANDATE`
--

CREATE TABLE `STATUT_MANDATE` (
  `idStatutMandate` int(11) NOT NULL,
  `libelleStatutMandate` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `STATUT_MANDATE`
--

INSERT INTO `STATUT_MANDATE` (`idStatutMandate`, `libelleStatutMandate`) VALUES
(1, 'En cours'),
(2, 'Terminé'),
(3, 'Annulé');

-- --------------------------------------------------------

--
-- Table structure for table `STATUT_PURCHASE`
--

CREATE TABLE `STATUT_PURCHASE` (
  `idStatutPurchase` int(11) NOT NULL,
  `libelleStatutPurchase` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `STATUT_PURCHASE`
--

INSERT INTO `STATUT_PURCHASE` (`idStatutPurchase`, `libelleStatutPurchase`) VALUES
(1, 'En cours'),
(2, 'Vendu'),
(3, 'abandonné');

-- --------------------------------------------------------

--
-- Table structure for table `TYPEMANDATE`
--

CREATE TABLE `TYPEMANDATE` (
  `idTypeMandate` int(11) NOT NULL,
  `libelleTypeMandate` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `TYPEMANDATE`
--

INSERT INTO `TYPEMANDATE` (`idTypeMandate`, `libelleTypeMandate`) VALUES
(1, 'Mandat exclusif'),
(2, 'Mandat simple');

-- --------------------------------------------------------

--
-- Table structure for table `TYPEPROPERTY`
--

CREATE TABLE `TYPEPROPERTY` (
  `idTypeProperty` int(11) NOT NULL,
  `libelleTypeProperty` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `TYPEPROPERTY`
--

INSERT INTO `TYPEPROPERTY` (`idTypeProperty`, `libelleTypeProperty`) VALUES
(1, 'Maison'),
(2, 'Terrain'),
(3, 'Appartement');

-- --------------------------------------------------------

--
-- Table structure for table `TYPEUSER`
--

CREATE TABLE `TYPEUSER` (
  `idTypeUser` int(11) NOT NULL,
  `libelleTypeUser` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `TYPEUSER`
--

INSERT INTO `TYPEUSER` (`idTypeUser`, `libelleTypeUser`) VALUES
(1, 'Directeur'),
(2, 'Consultant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CONSULTANT`
--
ALTER TABLE `CONSULTANT`
  ADD PRIMARY KEY (`idConsultant`),
  ADD KEY `FK_CONSULTANT_TYPEUSER` (`typeUser_id`);

--
-- Indexes for table `ENERGY`
--
ALTER TABLE `ENERGY`
  ADD PRIMARY KEY (`idEnergy`);

--
-- Indexes for table `EXPENSES`
--
ALTER TABLE `EXPENSES`
  ADD PRIMARY KEY (`idExpenses`),
  ADD KEY `energy_id` (`energy_id`),
  ADD KEY `heatingMethod_id` (`heatingMethod_id`),
  ADD KEY `hotWater_id` (`hotWater_id`),
  ADD KEY `sanitation_id` (`sanitation_id`);

--
-- Indexes for table `HEATING_METHOD`
--
ALTER TABLE `HEATING_METHOD`
  ADD PRIMARY KEY (`idHeatingMethod`);

--
-- Indexes for table `HOT_WATER`
--
ALTER TABLE `HOT_WATER`
  ADD PRIMARY KEY (`idHotWater`);

--
-- Indexes for table `MANDATE`
--
ALTER TABLE `MANDATE`
  ADD PRIMARY KEY (`idMandate`),
  ADD KEY `FK_MANDATE_TYPEMANDATE` (`typeMandate_id`),
  ADD KEY `statusMandate_id` (`statusMandate_id`);

--
-- Indexes for table `OWNER`
--
ALTER TABLE `OWNER`
  ADD PRIMARY KEY (`idOwner`);

--
-- Indexes for table `PROPERTY`
--
ALTER TABLE `PROPERTY`
  ADD PRIMARY KEY (`idProperty`),
  ADD KEY `FK_PROPERTY_OWNER` (`owner_id`),
  ADD KEY `statutProperty_id` (`typeProperty_id`),
  ADD KEY `expenses_id` (`expenses_id`);

--
-- Indexes for table `PURCHASE`
--
ALTER TABLE `PURCHASE`
  ADD PRIMARY KEY (`idPurchase`),
  ADD KEY `FK_PURCHASE_OWNER` (`property_id`),
  ADD KEY `statutPurchase_id` (`statutPurchase_id`);

--
-- Indexes for table `ROOM`
--
ALTER TABLE `ROOM`
  ADD PRIMARY KEY (`idRoom`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `SANITATION`
--
ALTER TABLE `SANITATION`
  ADD PRIMARY KEY (`idSanitation`);

--
-- Indexes for table `SIGN`
--
ALTER TABLE `SIGN`
  ADD PRIMARY KEY (`owner_id`,`consultant_id`,`mandate_id`),
  ADD KEY `FK_SIGN_CONSULTANT` (`consultant_id`),
  ADD KEY `FK_SIGN_MANDATE` (`mandate_id`);

--
-- Indexes for table `STATUT_MANDATE`
--
ALTER TABLE `STATUT_MANDATE`
  ADD PRIMARY KEY (`idStatutMandate`);

--
-- Indexes for table `STATUT_PURCHASE`
--
ALTER TABLE `STATUT_PURCHASE`
  ADD PRIMARY KEY (`idStatutPurchase`);

--
-- Indexes for table `TYPEMANDATE`
--
ALTER TABLE `TYPEMANDATE`
  ADD PRIMARY KEY (`idTypeMandate`);

--
-- Indexes for table `TYPEPROPERTY`
--
ALTER TABLE `TYPEPROPERTY`
  ADD PRIMARY KEY (`idTypeProperty`);

--
-- Indexes for table `TYPEUSER`
--
ALTER TABLE `TYPEUSER`
  ADD PRIMARY KEY (`idTypeUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ENERGY`
--
ALTER TABLE `ENERGY`
  MODIFY `idEnergy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `EXPENSES`
--
ALTER TABLE `EXPENSES`
  MODIFY `idExpenses` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `HEATING_METHOD`
--
ALTER TABLE `HEATING_METHOD`
  MODIFY `idHeatingMethod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `HOT_WATER`
--
ALTER TABLE `HOT_WATER`
  MODIFY `idHotWater` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `MANDATE`
--
ALTER TABLE `MANDATE`
  MODIFY `idMandate` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT for table `OWNER`
--
ALTER TABLE `OWNER`
  MODIFY `idOwner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `PROPERTY`
--
ALTER TABLE `PROPERTY`
  MODIFY `idProperty` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT for table `PURCHASE`
--
ALTER TABLE `PURCHASE`
  MODIFY `idPurchase` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `ROOM`
--
ALTER TABLE `ROOM`
  MODIFY `idRoom` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1490;

--
-- AUTO_INCREMENT for table `SANITATION`
--
ALTER TABLE `SANITATION`
  MODIFY `idSanitation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `STATUT_MANDATE`
--
ALTER TABLE `STATUT_MANDATE`
  MODIFY `idStatutMandate` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `STATUT_PURCHASE`
--
ALTER TABLE `STATUT_PURCHASE`
  MODIFY `idStatutPurchase` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `TYPEPROPERTY`
--
ALTER TABLE `TYPEPROPERTY`
  MODIFY `idTypeProperty` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `TYPEUSER`
--
ALTER TABLE `TYPEUSER`
  MODIFY `idTypeUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `CONSULTANT`
--
ALTER TABLE `CONSULTANT`
  ADD CONSTRAINT `CONSULTANT_ibfk_1` FOREIGN KEY (`typeUser_id`) REFERENCES `TYPEUSER` (`idTypeUser`);

--
-- Constraints for table `EXPENSES`
--
ALTER TABLE `EXPENSES`
  ADD CONSTRAINT `EXPENSES_ibfk_1` FOREIGN KEY (`energy_id`) REFERENCES `ENERGY` (`idEnergy`),
  ADD CONSTRAINT `EXPENSES_ibfk_2` FOREIGN KEY (`heatingMethod_id`) REFERENCES `HEATING_METHOD` (`idHeatingMethod`),
  ADD CONSTRAINT `EXPENSES_ibfk_4` FOREIGN KEY (`hotWater_id`) REFERENCES `HOT_WATER` (`idHotWater`),
  ADD CONSTRAINT `EXPENSES_ibfk_5` FOREIGN KEY (`sanitation_id`) REFERENCES `SANITATION` (`idSanitation`);

--
-- Constraints for table `MANDATE`
--
ALTER TABLE `MANDATE`
  ADD CONSTRAINT `MANDATE_ibfk_2` FOREIGN KEY (`statusMandate_id`) REFERENCES `STATUT_MANDATE` (`idStatutMandate`),
  ADD CONSTRAINT `MANDATE_ibfk_3` FOREIGN KEY (`typeMandate_id`) REFERENCES `TYPEMANDATE` (`idTypeMandate`);

--
-- Constraints for table `PROPERTY`
--
ALTER TABLE `PROPERTY`
  ADD CONSTRAINT `PROPERTY_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `OWNER` (`idOwner`),
  ADD CONSTRAINT `PROPERTY_ibfk_3` FOREIGN KEY (`typeProperty_id`) REFERENCES `TYPEPROPERTY` (`idTypeProperty`),
  ADD CONSTRAINT `PROPERTY_ibfk_4` FOREIGN KEY (`expenses_id`) REFERENCES `EXPENSES` (`idExpenses`);

--
-- Constraints for table `PURCHASE`
--
ALTER TABLE `PURCHASE`
  ADD CONSTRAINT `PURCHASE_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `PROPERTY` (`idProperty`),
  ADD CONSTRAINT `PURCHASE_ibfk_3` FOREIGN KEY (`statutPurchase_id`) REFERENCES `STATUT_PURCHASE` (`idStatutPurchase`);

--
-- Constraints for table `ROOM`
--
ALTER TABLE `ROOM`
  ADD CONSTRAINT `ROOM_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `PROPERTY` (`idProperty`);

--
-- Constraints for table `SIGN`
--
ALTER TABLE `SIGN`
  ADD CONSTRAINT `SIGN_ibfk_1` FOREIGN KEY (`consultant_id`) REFERENCES `CONSULTANT` (`idConsultant`),
  ADD CONSTRAINT `SIGN_ibfk_2` FOREIGN KEY (`mandate_id`) REFERENCES `MANDATE` (`idMandate`),
  ADD CONSTRAINT `SIGN_ibfk_3` FOREIGN KEY (`owner_id`) REFERENCES `OWNER` (`idOwner`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

