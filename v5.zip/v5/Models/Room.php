<?php


class Room
{

    /** @var int */
    private $id;
    /** @var int */
    private $property_id;
    /** @var string */
    private $libelle;
    /** @var int */
    private $surface;

    /**
     * Room constructor.
     * @param int $id
     * @param Property $property
     * @param string $libelle
     * @param int $surface
     */
    public function __construct($id, $property_id, $libelle, $surface)
    {
        $this->id = $id;
        $this->property_id = $property_id;
        $this->libelle = $libelle;
        $this->surface = $surface;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getPropertyId()
    {
        return $this->property_id;
    }

    /**
     * @param  $property_id
     */
    public function setProperty($property_id)
    {
        $this->property_id = $property_id;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle($libelle)
    {
        $this->libelle = $libelle;
    }

    /**
     * @return int
     */
    public function getSurface()
    {
        return $this->surface;
    }

    /**
     * @param int $surface
     */
    public function setSurface($surface)
    {
        $this->surface = $surface;
    }
}