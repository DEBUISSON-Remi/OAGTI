<?php


class TypeUser
{

    /** @var int */
    private $id;
    /** @var string */
    private $libelle;

    /**
     * TypeUser constructor.
     * @param int $id
     * @param string $libelle
     */
    public function __construct($id, $libelle)
    {
        $this->id = $id;
        $this->libelle = $libelle;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelle;
    }


}