<?php


class Mandate
{
    /** @var int */
    private $idMandate;
    /** @var TypeMandate */
    private $typeMandate;
    /** @var string */
    private $mandateName;
    /** @var string */
    private $agencyName;
    /** @var string */
    private $agencyPhone;
    /** @var string */
    private $addressStreetAgency;
    /** @var string */
    private $addressCityAgency;
    /** @var string */
    private $postalCodeAgency;
    /** @var string */
    private $propertyPrice;
    /** @var StatutMandate */
    private $statutMandate;

    /**
     * Mandate constructor.
     * @param int $idMandate
     * @param Property $property
     * @param TypeMandate $typeMandate
     * @param string $mandateName
     * @param string $agencyName
     * @param string $agencyPhone
     * @param string $addressStreetAgency
     * @param string $addressCityAgency
     * @param string $postalCodeAgency
     * @param string $propertyPrice
     * @param StatutMandate $statutMandate
     */
    public function __construct($idMandate, TypeMandate $typeMandate, $mandateName, $agencyName, $agencyPhone, $addressStreetAgency, $addressCityAgency, $postalCodeAgency, $propertyPrice, StatutMandate $statutMandate)
    {
        $this->idMandate = $idMandate;
        $this->typeMandate = $typeMandate;
        $this->mandateName = $mandateName;
        $this->agencyName = $agencyName;
        $this->agencyPhone = $agencyPhone;
        $this->addressStreetAgency = $addressStreetAgency;
        $this->addressCityAgency = $addressCityAgency;
        $this->postalCodeAgency = $postalCodeAgency;
        $this->propertyPrice = $propertyPrice;
        $this->statutMandate = $statutMandate;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idMandate;
    }

    /**
     * @param int $idMandate
     */
    public function setId($idMandate)
    {
        $this->idMandate = $idMandate;
    }

    /**
     * @return TypeMandate
     */
    public function getTypeMandate()
    {
        return $this->typeMandate;
    }

    /**
     * @param TypeMandate $typeMandate
     */
    public function setTypeMandate($typeMandate)
    {
        $this->typeMandate = $typeMandate;
    }

    /**
     * @return string
     */
    public function getMandateName()
    {
        return $this->mandateName;
    }

    /**
     * @param string $mandateName
     */
    public function setMandateName($mandateName)
    {
        $this->mandateName = $mandateName;
    }

    /**
     * @return string
     */
    public function getAgencyName()
    {
        return $this->agencyName;
    }

    /**
     * @param string $agencyName
     */
    public function setAgencyName($agencyName)
    {
        $this->agencyName = $agencyName;
    }

    /**
     * @return string
     */
    public function getAgencyPhone()
    {
        return $this->agencyPhone;
    }

    /**
     * @param string $agencyPhone
     */
    public function setAgencyPhone($agencyPhone)
    {
        $this->agencyPhone = $agencyPhone;
    }

    /**
     * @return string
     */
    public function getAddressStreetAgency()
    {
        return $this->addressStreetAgency;
    }

    /**
     * @param string $addressStreetAgency
     */
    public function setAddressStreetAgency($addressStreetAgency)
    {
        $this->addressStreetAgency = $addressStreetAgency;
    }

    /**
     * @return string
     */
    public function getAddressCityAgency()
    {
        return $this->addressCityAgency;
    }

    /**
     * @param string $addressCityAgency
     */
    public function setAddressCityAgency($addressCityAgency)
    {
        $this->addressCityAgency = $addressCityAgency;
    }

    /**
     * @return string
     */
    public function getPostalCodeAgency()
    {
        return $this->postalCodeAgency;
    }

    /**
     * @param string $postalCodeAgency
     */
    public function setPostalCodeAgency($postalCodeAgency)
    {
        $this->postalCodeAgency = $postalCodeAgency;
    }

    /**
     * @return string
     */
    public function getPropertyPrice()
    {
        return $this->propertyPrice;
    }

    /**
     * @param string $propertyPrice
     */
    public function setPropertyPrice($propertyPrice)
    {
        $this->propertyPrice = $propertyPrice;
    }

    /**
     * @return StatutMandate
     */
    public function getStatutMandate()
    {
        return $this->statutMandate;
    }

    /**
     * @param StatutMandate $statutMandate
     */
    public function setStatutMandate($statutMandate)
    {
        $this->statutMandate = $statutMandate;
    }


}