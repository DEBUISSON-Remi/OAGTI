<?php


class Property
{
    /** @var int */
    private $idProperty;
    /** @var Owner */
    private $owner;
    /** @var TypeProperty */
    private $typeProperty;
    /** @var int */
    private $nbRoom;
    /** @var string */
    private $constructionDate;
    /** @var string */
    private $comment;
    /** @var string */
    private $pictures;
    /** @var float */
    private $propertySurface;
    /** @var float */
    private $propertyGround;
    /** @var string */
    private $addressStreetProperty;
    /** @var string */
    private $addressCityProperty;
    /** @var int */
    private $postalCodeProperty;
    /** @var string */
    private $locality;
    /** @var int */
    private $buildingNumber;
    /** @var float */
    private $ISPPrice;
    /** @var float */
    private $agencyFee;
    /** @var Expenses */
    private $expenses;

    /**
     * Property constructor.
     * @param int $idProperty
     * @param Owner $owner
     * @param TypeProperty $typeProperty
     * @param int $nbRoom
     * @param DateTime $constructionDate
     * @param string $comment
     * @param string $pictures
     * @param float $propertySurface
     * @param float $propertyGround
     * @param string $addressStreetProperty
     * @param string $addressCityProperty
     * @param int $postalCodeProperty
     * @param string $locality
     * @param int $buildingNumber
     * @param float $ISPPrice
     * @param float $agencyFee
     * @param Expenses $expenses
     */
    public function __construct($idProperty, Owner $owner, TypeProperty $typeProperty, $nbRoom, $constructionDate, $comment, $pictures, $propertySurface, $propertyGround, $addressStreetProperty, $addressCityProperty, $postalCodeProperty, $locality, $buildingNumber, $ISPPrice, $agencyFee, Expenses $expenses)
    {
        $this->idProperty = $idProperty;
        $this->owner = $owner;
        $this->typeProperty = $typeProperty;
        $this->nbRoom = $nbRoom;
        $this->constructionDate = $constructionDate;
        $this->comment = $comment;
        $this->pictures = $pictures;
        $this->propertySurface = $propertySurface;
        $this->propertyGround = $propertyGround;
        $this->addressStreetProperty = $addressStreetProperty;
        $this->addressCityProperty = $addressCityProperty;
        $this->postalCodeProperty = $postalCodeProperty;
        $this->locality = $locality;
        $this->buildingNumber = $buildingNumber;
        $this->ISPPrice = $ISPPrice;
        $this->agencyFee = $agencyFee;
        $this->expenses = $expenses;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idProperty;
    }

    /**
     * @param int $idProperty
     */
    public function setId($idProperty)
    {
        $this->idProperty = $idProperty;
    }

    /**
     * @return Owner
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * @param Owner $owner
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;
    }

    /**
     * @return TypeProperty
     */
    public function getTypeProperty()
    {
        return $this->typeProperty;
    }

    /**
     * @param TypeProperty $typeProperty
     */
    public function setTypeProperty($typeProperty)
    {
        $this->typeProperty = $typeProperty;
    }

    /**
     * @return int
     */
    public function getNbRoom()
    {
        return $this->nbRoom;
    }

    /**
     * @param int $nbRoom
     */
    public function setNbRoom($nbRoom)
    {
        $this->nbRoom = $nbRoom;
    }

    /**
     * @return
     */
    public function getConstructionDate()
    {
        return $this->constructionDate;
    }

    /**
     * @param $constructionDate
     */
    public function setConstructionDate($constructionDate)
    {
        $this->constructionDate = $constructionDate;
    }

    /**
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * @param string $comment
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * @return string
     */
    public function getPictures()
    {
        return $this->pictures;
    }

    /**
     * @param string $pictures
     */
    public function setPictures($pictures)
    {
        $this->pictures = $pictures;
    }

    /**
     * @return float
     */
    public function getPropertySurface()
    {
        return $this->propertySurface;
    }

    /**
     * @param float $propertySurface
     */
    public function setPropertySurface($propertySurface)
    {
        $this->propertySurface = $propertySurface;
    }

    /**
     * @return float
     */
    public function getPropertyGround()
    {
        return $this->propertyGround;
    }

    /**
     * @param float $propertyGround
     */
    public function setPropertyGround($propertyGround)
    {
        $this->propertyGround = $propertyGround;
    }

    /**
     * @return string
     */
    public function getAddressStreet()
    {
        return $this->addressStreetProperty;
    }

    /**
     * @param string $addressStreetProperty
     */
    public function setAddressStreet($addressStreetProperty)
    {
        $this->addressStreetProperty = $addressStreetProperty;
    }

    /**
     * @return string
     */
    public function getAddressCity()
    {
        return $this->addressCityProperty;
    }

    /**
     * @param string $addressCityProperty
     */
    public function setAddressCityProperty($addressCityProperty)
    {
        $this->addressCityProperty = $addressCityProperty;
    }

    /**
     * @return int
     */
    public function getPostalCode()
    {
        return $this->postalCodeProperty;
    }

    /**
     * @param int $postalCodeProperty
     */
    public function setPostalCode($postalCodeProperty)
    {
        $this->postalCodeProperty = $postalCodeProperty;
    }

    /**
     * @return string
     */
    public function getLocality()
    {
        return $this->locality;
    }

    /**
     * @param string $locality
     */
    public function setLocality($locality)
    {
        $this->locality = $locality;
    }

    /**
     * @return int
     */
    public function getBuildingNumber()
    {
        return $this->buildingNumber;
    }

    /**
     * @param int $buildingNumber
     */
    public function setBuildingNumber($buildingNumber)
    {
        $this->buildingNumber = $buildingNumber;
    }

    /**
     * @return float
     */
    public function getISPPrice()
    {
        return $this->ISPPrice;
    }

    /**
     * @param float $ISPPrice
     */
    public function setISPPrice($ISPPrice)
    {
        $this->ISPPrice = $ISPPrice;
    }

    /**
     * @return float
     */
    public function getAgencyFee()
    {
        return $this->agencyFee;
    }

    /**
     * @param float $agencyFee
     */
    public function setAgencyFee($agencyFee)
    {
        $this->agencyFee = $agencyFee;
    }

    /**
     * @return Expenses
     */
    public function getExpenses()
    {
        return $this->expenses;
    }

    /**
     * @param Expenses $expenses
     */
    public function setExpenses($expenses)
    {
        $this->expenses = $expenses;
    }


}