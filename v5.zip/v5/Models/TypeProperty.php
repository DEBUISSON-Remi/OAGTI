<?php


class TypeProperty
{
    /** @var int */
    private $idTypeProperty;
    /** @var string */
    private $libelleStatutProperty;

    /**
     * TypePropertyDAO constructor.
     * @param int $idTypeProperty
     * @param string $libelleStatutProperty
     */
    public function __construct($idTypeProperty, $libelleStatutProperty)
    {
        $this->idTypeProperty = $idTypeProperty;
        $this->libelleStatutProperty = $libelleStatutProperty;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idTypeProperty;
    }

    /**
     * @param int $idTypeProperty
     */
    public function setId($idTypeProperty)
    {
        $this->idTypeProperty = $idTypeProperty;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleStatutProperty;
    }

    /**
     * @param string $libelleStatutProperty
     */
    public function setLibelle($libelleStatutProperty)
    {
        $this->libelleStatutProperty = $libelleStatutProperty;
    }


}