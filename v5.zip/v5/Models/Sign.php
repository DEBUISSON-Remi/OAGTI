<?php


class Sign
{

    /** @var Owner */
    private $owner_id;
    /** @var Consultant */
    private $consultant_id;
    /** @var Mandate */
    private $mandate_id;
    /** @var Property */
    private $property_id;
    /** @var string */
    private $date_signature;

    /**
     * Sign constructor.
     * @param $owner_id
     * @param $consultant_id
     * @param $mandate_id
     * @param string $date_signature
     */
    public function __construct($owner_id,$consultant_id,$mandate_id,$property_id, $date_signature)
    {
        $this->owner_id = $owner_id;
        $this->consultant_id = $consultant_id;
        $this->mandate_id = $mandate_id;
        $this->property_id = $property_id;
        $this->date_signature = $date_signature;
    }

    /**
     * @return Owner
     */
    public function getOwnerId()
    {
        return $this->owner_id;
    }

    /**
     * @param Owner $owner_id
     */
    public function setOwnerId($owner_id)
    {
        $this->owner_id = $owner_id;
    }

    /**
     * @return Consultant
     */
    public function getConsultantId()
    {
        return $this->consultant_id;
    }

    /**
     * @param Consultant $consultant_id
     */
    public function setConsultantId($consultant_id)
    {
        $this->consultant_id = $consultant_id;
    }

    /**
     * @return Mandate
     */
    public function getMandateId()
    {
        return $this->mandate_id;
    }

    /**
     * @param Mandate $mandate_id
     */
    public function setMandateId($mandate_id)
    {
        $this->mandate_id = $mandate_id;
    }


    /**
     * @return Property
     */
    public function getPropertyId()
    {
        return $this->property_id;
    }
    /**
     * @return string
     */
    public function getDateSignature()
    {
        return $this->date_signature;
    }

    /**
     * @param string $date_signature
     */
    public function setDateSignature($date_signature)
    {
        $this->date_signature = $date_signature;
    }
}