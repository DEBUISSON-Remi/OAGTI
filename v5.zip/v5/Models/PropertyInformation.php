<?php


class PropertyInformation
{


    /** @var Owner */
    private $owner;
    /** @var Mandate */
    private $mandate;
    /** @var Property */
    private $property;
    /** @var Consultant */
    private $consultant;

    /**
     * PropertyInformation constructor.
     * @param Owner $owner
     * @param Mandate $mandate
     * @param Property $property
     */
    public function __construct(Owner $owner, Mandate $mandate, Property $property, Consultant $consultant)
    {
        $this->owner = $owner;
        $this->mandate = $mandate;
        $this->property = $property;
        $this->consultant = $consultant;
    }

    /**
     * @return Owner
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * @param Owner $owner
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;
    }

    /**
     * @return Mandate
     */
    public function getMandate()
    {
        return $this->mandate;
    }

    /**
     * @param Mandate $mandate
     */
    public function setMandate($mandate)
    {
        $this->mandate = $mandate;
    }

    /**
     * @return Property
     */
    public function getProperty()
    {
        return $this->property;
    }

    /**
     * @param Property $property
     */
    public function setProperty($property)
    {
        $this->property = $property;
    }

    /**
     * @return Consultant
     */
    public function getConsultant()
    {
        return $this->consultant;
    }

    /**
     * @param Consultant $consultant
     */
    public function setConsultant($consultant)
    {
        $this->consultant = $consultant;
    }

    /** Mandate */
    public function getTypeMandate(){

        return $this->getMandate()->getTypeMandate();
    }

    public function getStatutMandate(){

        return $this->getMandate()->getStatutMandate();
    }

    /** Property */
    public function getTypeProperty(){

        return $this->getProperty()->getTypeProperty();
    }

    public function getExpenses(){
        return $this->getProperty()->getExpenses();
    }

    public function getSanitation(){

        return $this->getProperty()->getExpenses()->getSanitation();
    }

    public function getHeatingMethod(){

        return $this->getProperty()->getExpenses()->getHeatingMethod();
    }

    public function getHotWater(){
        return $this->getProperty()->getExpenses()->getHotWater();
    }

    public function getEnergy(){
        return $this->getProperty()->getExpenses()->getEnergy();
    }

    /** Consultant */
    public function getTypeUser(){

        return $this->getConsultant()->getTypeUser();
    }

}