<?php


class StatutProperty
{
    /** @var int */
    private $idStatutProperty;
    /** @var string */
    private $libelleStatutProperty;

    /**
     * StatutProperty constructor.
     * @param int $idStatutProperty
     * @param string $libelleStatutProperty
     */
    public function __construct($idStatutProperty, $libelleStatutProperty)
    {
        $this->idStatutProperty = $idStatutProperty;
        $this->libelleStatutProperty = $libelleStatutProperty;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idStatutProperty;
    }

    /**
     * @param int $idStatutProperty
     */
    public function setId($idStatutProperty)
    {
        $this->idStatutProperty = $idStatutProperty;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleStatutProperty;
    }

    /**
     * @param string $libelleStatutProperty
     */
    public function setLibelle($libelleStatutProperty)
    {
        $this->libelleStatutProperty = $libelleStatutProperty;
    }


}