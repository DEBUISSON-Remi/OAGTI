<?php


class Owner
{

    /** @var int */
    private $id;
    /** @var string */
    private $name;
    /** @var string */
    private $surname;
    /** @var string */
    private $socialHeadquarters;
    /** @var string */
    private $socialDenomination;
    /** @var string */
    private $addressCity;
    /** @var string */
    private $addressStreet;
    /** @var string */
    private $postalCode;
    /** @var string */
    private $phone;
    /** @var string */
    private $mail;
    /** @var string */
    private $gender;
    /** @var string */
    private $socialReson;
    /** @var string */
    private $facebook;
    /** @var string */
    private $twitter;

    /**
     * Owner constructor.
     * @param int $id
     * @param string $name
     * @param string $surname
     * @param string $socialHeadquarters
     * @param string $socialDenomination
     * @param string $addressCity
     * @param string $addressStreet
     * @param string $postalCode
     * @param string $phone
     * @param string $mail
     * @param string $gender
     * @param string $socialReson
     * @param string $facebook
     * @param string $twitter
     */
    public function __construct($arg)
    {
        $this->id = $arg['idOwner'];
        $this->name = $arg['firstnameOwner'];
        $this->surname = $arg['lastnameOwner'];
        $this->socialHeadquarters = $arg['socialHeadquarters'];
        $this->socialDenomination = $arg['socialDenomination'];
        $this->addressCity = $arg['addressCityOwner'];
        $this->addressStreet = $arg['addressStreetOwner'];
        $this->postalCode = $arg['postalCodeOwner'];
        $this->phone = $arg['phoneOwner'];
        $this->mail = $arg['mailOwner'];
        $this->gender = $arg['gender'];
        $this->socialReson = $arg['socialReson'];
        $this->facebook = $arg['facebook'];
        $this->twitter = $arg['twitter'];
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getFirstname()
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getLastname()
    {
        return $this->surname;
    }

    /**
     * @return string
     */
    public function getSocialHeadquarters()
    {
        return $this->socialHeadquarters;
    }

    /**
     * @return string
     */
    public function getSocialDenomination()
    {
        return $this->socialDenomination;
    }

    /**
     * @return string
     */
    public function getAddressCity()
    {
        return $this->addressCity;
    }

    /**
     * @return string
     */
    public function getAddressStreet()
    {
        return $this->addressStreet;
    }

    /**
     * @return string
     */
    public function getPostalCode()
    {
        return $this->postalCode;
    }

    /**
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @return string
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * @return string
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * @return string
     */
    public function getSocialReson()
    {
        return $this->socialReson;
    }

    /**
     * @return string
     */
    public function getFacebook()
    {
        return $this->facebook;
    }

    /**
     * @return string
     */
    public function getTwitter()
    {
        return $this->twitter;
    }
}