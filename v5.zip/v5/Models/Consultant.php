<?php


class Consultant
{




    /** @var int */
    private $id;
    /** @var TypeUser */
    private $typeUser ;
    /** @var string */
    private $commissionRate;
    /** @var string */
    private $firstname;
    /** @var string */
    private $lastname;
    /** @var string */
    private $phone;
    /** @var string */
    private $streetAddress;
    /** @var string */
    private $cityAddress;
    /** @var string */
    private $postalCode;
    /** @var string */
    private $mail;
    /** @var string */
    private $password;

    /**
     * Consultant constructor.
     * @param int $id
     * @param TypeUser $typeUser
     * @param string $firstname
     * @param string $lastname
     * @param string $phone
     * @param string $streetAddress
     * @param string $cityAddress
     * @param string $postalCode
     * @param string $mail
     * @param string $password
     */
    public function __construct($id, $typeUser , $firstname, $lastname, $phone, $streetAddress, $cityAddress, $postalCode, $mail, $password, $commissionRate)
    {
        $this->id = $id;
        $this->typeUser  = $typeUser ;
        $this->firstname = $firstname;
        $this->lastname = $lastname;
        $this->phone = $phone;
        $this->streetAddress = $streetAddress;
        $this->cityAddress = $cityAddress;
        $this->postalCode = $postalCode;
        $this->mail = $mail;
        $this->password = $password;
        $this->commissionRate = $commissionRate;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return TypeUser
     */
    public function getTypeUser()
    {
        return $this->typeUser ;
    }

    /**
     * @return string
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * @return string
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @return string
     */
    public function getStreetAddress()
    {
        return $this->streetAddress;
    }

    /**
     * @return string
     */
    public function getCityAddress()
    {
        return $this->cityAddress;
    }

    /**
     * @return string
     */
    public function getPostalCode()
    {
        return $this->postalCode;
    }

    /**
     * @return string
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }
    /**
     * @return string
     */
    public function getCommissionRate()
    {
        return $this->commissionRate;
    }

    /**
     * @param string $commissionRate
     */
    public function setCommissionRate($commissionRate)
    {
        $this->commissionRate = $commissionRate;
    }
}