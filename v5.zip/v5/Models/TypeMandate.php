<?php


class TypeMandate
{
    /** @var int */
    private $idTypeMandate;
    /** @var string */
    private $libelleTypeMandate;

    /**
     * TypeMandate constructor.
     * @param int $idTypeMandate
     * @param string $libelleTypeMandat
     */
    public function __construct($idTypeMandate, $libelleTypeMandate)
    {
        $this->idTypeMandate = $idTypeMandate;
        $this->libelleTypeMandate = $libelleTypeMandate;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idTypeMandate;
    }

    /**
     * @param int $idTypeMandate
     */
    public function setId($idTypeMandate)
    {
        $this->idTypeMandate = $idTypeMandate;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleTypeMandate;
    }

    /**
     * @param string $libelleTypeMandate
     */
    public function setLibelle($libelleTypeMandate)
    {
        $this->libelleTypeMandate = $libelleTypeMandate;
    }

}