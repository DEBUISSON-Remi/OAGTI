<?php


class StatutMandate
{
    /** @var int */
    private $idStatutMandate;
    /** @var string */
    private $libelleStatutMandate;

    /**
     * StatutMandate constructor.
     * @param int $idStatutMandate
     * @param string $libelleStatutMandate
     */
    public function __construct($idStatutMandate, $libelleStatutMandate)
    {
        $this->idStatutMandate = $idStatutMandate;
        $this->libelleStatutMandate = $libelleStatutMandate;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idStatutMandate;
    }

    /**
     * @param int $idStatutMandate
     */
    public function setId($idStatutMandate)
    {
        $this->idStatutMandate = $idStatutMandate;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleStatutMandate;
    }

    /**
     * @param string $libelleStatutMandate
     */
    public function setLibelle($libelleStatutMandate)
    {
        $this->libelleStatutMandate = $libelleStatutMandate;
    }

}