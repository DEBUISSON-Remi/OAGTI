<?php


class HotWater
{
    /** @var int */
    private $idHotWater;
    /** @var string */
    private $libelleHotWater;

    /**
     * HotWater constructor.
     * @param int $idHotWater
     * @param string $libelleHotWater
     */
    public function __construct($idHotWater, $libelleHotWater)
    {
        $this->idHotWater = $idHotWater;
        $this->libelleHotWater = $libelleHotWater;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idHotWater;
    }

    /**
     * @param int $idHotWater
     */
    public function setId($idHotWater)
    {
        $this->idHotWater = $idHotWater;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleHotWater;
    }

    /**
     * @param string $libelleHotWater
     */
    public function setLibelle($libelleHotWater)
    {
        $this->libelleHotWater = $libelleHotWater;
    }

}