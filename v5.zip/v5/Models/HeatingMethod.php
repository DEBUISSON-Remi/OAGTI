<?php


class HeatingMethod
{
    /** @var int */
    private $idHeatingMethod;
    /** @var string */
    private $libelleHeatingMethod;

    /**
     * HeatingMethodDAO constructor.
     * @param int $idHeatingMethod
     * @param string $libelleHeatingMethod
     */
    public function __construct($idHeatingMethod, $libelleHeatingMethod)
    {
        $this->idHeatingMethod = $idHeatingMethod;
        $this->libelleHeatingMethod = $libelleHeatingMethod;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idHeatingMethod;
    }

    /**
     * @param int $idHeatingMethod
     */
    public function setId($idHeatingMethod)
    {
        $this->idHeatingMethod = $idHeatingMethod;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleHeatingMethod;
    }

    /**
     * @param string $libelleHeatingMethod
     */
    public function setLibelle($libelleHeatingMethod)
    {
        $this->libelleHeatingMethod = $libelleHeatingMethod;
    }

}