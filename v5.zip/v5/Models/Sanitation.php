<?php


class Sanitation
{
    /** @var int */
    private $idSanitation;
    /** @var string */
    private $libelleSanitation;

    /**
     * SanitationDAO constructor.
     * @param int $idSanitation
     * @param string $libelleSanitation
     */
    public function __construct($idSanitation, $libelleSanitation)
    {
        $this->idSanitation = $idSanitation;
        $this->libelleSanitation = $libelleSanitation;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idSanitation;
    }

    /**
     * @param int $idSanitation
     */
    public function setId($idSanitation)
    {
        $this->idSanitation = $idSanitation;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelleSanitation;
    }

    /**
     * @param string $libelleSanitation
     */
    public function setLibelle($libelleSanitation)
    {
        $this->libelleSanitation = $libelleSanitation;
    }


}