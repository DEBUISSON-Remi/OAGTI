<?php


class Expenses
{
    /** @var int */
    private $idExpenses;
    /** @var string */
    private $fonciere;
    /** @var float */
    private $livingExpenses;
    /** @var float */
    private $expenses;
    /** @var Sanitation */
    private $sanitation;
    /** @var HeatingMethod */
    private $heatingMethod;
    /** @var Energy */
    private $energy;
    /** @var HotWater */
    private $hotWater;

    /**
     * Expenses constructor.
     * @param int $idExpenses
     * @param string $fonciere
     * @param float $livingExpenses
     * @param float $expenses
     * @param Sanitation $sanitation
     * @param HeatingMethod $heatingMethod
     * @param Energy $energy
     * @param HotWater $hotWater
     */
    public function __construct($idExpenses, $fonciere, $livingExpenses, $expenses, Sanitation $sanitation, HeatingMethod $heatingMethod, Energy $energy, HotWater $hotWater)
    {
        $this->idExpenses = $idExpenses;
        $this->fonciere = $fonciere;
        $this->livingExpenses = $livingExpenses;
        $this->expenses = $expenses;
        $this->sanitation = $sanitation;
        $this->heatingMethod= $heatingMethod;
        $this->energy = $energy;
        $this->hotWater = $hotWater;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->idExpenses;
    }

    /**
     * @param int $idExpenses
     */
    public function setIdExpenses($idExpenses)
    {
        $this->idExpenses = $idExpenses;
    }

    /**
     * @return string
     */
    public function getFonciere()
    {
        return $this->fonciere;
    }

    /**
     * @param string $fonciere
     */
    public function setFonciere($fonciere)
    {
        $this->fonciere = $fonciere;
    }

    /**
     * @return float
     */
    public function getLivingExpenses()
    {
        return $this->livingExpenses;
    }

    /**
     * @param float $livingExpenses
     */
    public function setLivingExpenses($livingExpenses)
    {
        $this->livingExpenses = $livingExpenses;
    }

    /**
     * @return float
     */
    public function getExpenses()
    {
        return $this->expenses;
    }

    /**
     * @param float $expenses
     */
    public function setExpenses($expenses)
    {
        $this->expenses = $expenses;
    }

    /**
     * @return Sanitation
     */
    public function getSanitation()
    {
        return $this->sanitation;
    }

    /**
     * @param Sanitation $sanitation
     */
    public function setSanitation($sanitation)
    {
        $this->sanitation = $sanitation;
    }

    /**
     * @return HeatingMethod
     */
    public function getHeatingMethod()
    {
        return $this->heatingMethod;
    }

    /**
     * @param HeatingMethod $heatingMethod
     */
    public function setHeatingMethod($heatingMethod)
    {
        $this->heatingMethod = $heatingMethod;
    }

    /**
     * @return Energy
     */
    public function getEnergy()
    {
        return $this->energy;
    }

    /**
     * @param Energy $energy
     */
    public function setEnergy($energy)
    {
        $this->energy = $energy;
    }

    /**
     * @return HotWater
     */
    public function getHotWater()
    {
        return $this->hotWater;
    }

    /**
     * @param HotWater $hotWater
     */
    public function setHotWater($hotWater)
    {
        $this->hotWater = $hotWater;
    }


}