<?php


class SignDAO
{

    public static function insertNewSignPost($idMandate,$idOwner,$idConsultant, $idProperty){

        Connexion::exec('insert into SIGN values('.$idOwner.','.$idConsultant.','.$idMandate['idMandate'].','.$idProperty.',NULL)');
    }

    public static function getSignByConsultantId(){
        $datas = Connexion::query('select * from SIGN WHERE consultant_id ='.$_SESSION['id']);

        if(!isset($datas[0])){
            return null;
        }
        else {
            foreach ($datas as $data){

                $sign[] = new Sign($data['owner_id'],$data['consultant_id'],$data['mandate_id'],$data['property_id'],$data['date_signature']);
            }
            return $sign;
        }

    }

    public static function getSignByMandateId($idMandate){

        $data = Connexion::query('select * from SIGN where mandate_id ='.$idMandate['idMandate']);

        $sign = new Sign($data[0]['owner_id'],$data[0]['consultant_id'],$data[0]['mandate_id'],$data[0]['property_id'],$data[0]['date_signature']);

        return $sign;

    }

    public static function getSignByConsultantIdDirectory($idConsultant){
        $datas = Connexion::query('select * from SIGN WHERE consultant_id ='.$idConsultant);

        if(!isset($datas[0])){
            return null;
        }
        else {
            foreach ($datas as $data){

                $sign[] = new Sign($data['owner_id'],$data['consultant_id'],$data['mandate_id'],$data['property_id'],$data['date_signature']);
            }
            return $sign;
        }

    }

}