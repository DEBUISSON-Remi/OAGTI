<?php


class SanitationDAO
{
    public static function getNoSanitation()
    {
        $querys= Connexion::first('select * from SANITATION');

        $sanitation = new Sanitation($querys['idSanitation'],$querys['libelleSanitation']);
        return $sanitation;
    }

    public static function getAllEnergy()
    {
        $idSanitation= SanitationDAO::getNoSanitation();

        $querys = Connexion::query('select * from SANITATION where idSanitation !='.$idSanitation->getId());

        foreach ($querys as $query){
            $sanitation[] = new Sanitation($query['idSanitation'],$query['libelleSanitation']);
        }
        return $sanitation;
    }

    public static function insertNewSanitation($post){

        Connexion::exec('insert into SANITATION VALUES(NULL,"'.$post['newSanitation'].'")');
        $idSanitation = Connexion::first('select idSanitation from SANITATION order by idSanitation DESC');
        return $idSanitation['idSanitation'];
    }
}