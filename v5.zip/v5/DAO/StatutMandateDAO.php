<?php


class StatutMandateDAO
{

    public static function getFirstStatutMandate(){

        $query = Connexion::first('select idStatutMandate from STATUT_MANDATE order by idStatutMandate ASC');

        return $query;
    }
}