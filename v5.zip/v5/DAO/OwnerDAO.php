<?php


class OwnerDAO
{

    public static function insertNewOwnerPost($post){

        Connexion::exec('Insert into OWNER values(NULL,"'.$post['firstnameOwner'].'","'.$post['lastnameOwner'].'","'.$post['socialHeadquarters'].'","'.$post['socialDenomination'].'","'.$post['addressCityOwner'].'","'.$post['addressStreetOwner'].'","'.$post['postalCodeOwner'].'","'.$post['phoneOwner'].'","'.$post['mailOwner'].'","'.$post['gender'].'","'.$post['socialReson'].'","'.$post['facebook'].'","'.$post['twitter'].'")');
        $idOwner = Connexion::first('Select idOwner from OWNER order by idOwner DESC');
        return $idOwner['idOwner'];


    }

    public static function getOneOwnerById($idOwner){
        $data = Connexion::query('select * from OWNER where idOwner = '.$idOwner);

        $owner = new Owner($data[0]);
        return $owner;
    }

    public static function updateOwnerPost($post){

        Connexion::exec('Update OWNER SET firstnameOwner="'.$post['firstnameOwner'].'",lastnameOwner="'.$post['lastnameOwner'].'",socialHeadquarters="'.$post['socialHeadquarters'].'",socialDenomination="'.$post['socialDenomination'].'",addressCityOwner="'.$post['addressCityOwner'].'",addressStreetOwner="'.$post['addressStreetOwner'].'",postalCodeOwner="'.$post['postalCodeOwner'].'",phoneOwner="'.$post['phoneOwner'].'",mailOwner="'.$post['mailOwner'].'",gender="'.$post['gender'].'",socialReson="'.$post['socialReson'].'",facebook="'.$post['facebook'].'",twitter="'.$post['twitter'].'" where idOwner='.$post['idOwner']);

    }

    public static function getAllOwner(){

        $datas = Connexion::query('select * from OWNER order by lastnameOwner ASC');

        foreach ($datas as $data){

            $owners[] = new Owner($data);
        }

        return $owners;
    }

    public static function getOneOwnerIdById($idOwner){
        $data = Connexion::query('select idOwner from OWNER where idOwner = '.$idOwner);
        return $data;
    }
}