<?php


class TypeUserDAO
{
    public function findById($id)
    {

        $query = Connexion::first('select * from TYPEUSER where idTypeUser='.$id);

        $typeUser = new TypeUser($query['idTypeUser'], $query['libelleTypeUser']);

        return $typeUser;

    }

    public function findByLibelle($libelle)
    {

        $query = Connexion::first('select * from TYPEUSER where libelleTypeUser='.$libelle);

        $typeUser = new TypeUser($query['idTypeUser'], $query['libelleTypeUser']);

        return $typeUser;

    }

    public function getAll()
    {
        $typeUsers= [];

        $querys = connexion::query('select * from TYPEUSER');
        foreach ($querys as $query){
            $typeUsers[] = new TypeUser($query['idTypeUser'], $query['libelleTypeUser']);

        }

        return $typeUsers;

    }
}