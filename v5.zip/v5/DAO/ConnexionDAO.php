<?php





class ConnexionDAO
{

    public function getOneUser($email){
        $query=connexion::query('select * from CONSULTANT,TYPEUSER where TYPEUSER.idTypeUser=CONSULTANT.typeUser_id and mailConsultant="'.$email.'"');
        if (!isset($query[0])) {
            return null;
        }
        else {
            $typeUser = new TypeUser($query[0]['typeUser_id'],$query[0]['libelleTypeUser']);
            $consultant = new Consultant($query[0]['idConsultant'], $typeUser, $query[0]['firstnameConsultant'], $query[0]['lastnameConsultant'], $query[0]['phoneConsultant'], $query[0]['addressStreetConsultant'], $query[0]['addressCityConsultant'], $query[0]['postalCodeConsultant'], $query[0]['mailConsultant'], $query[0]['password'],$query[0]['commissionRate']);
            return $consultant;
        }
    }
    public function getOneUserById($id){

        $query=connexion::query('select * from CONSULTANT,TYPEUSER where TYPEUSER.idTypeUser=CONSULTANT.typeUser_id and CONSULTANT.idConsultant='.$id);

        $myAccount = new Consultant($query[0]['idConsultant'], $query[0]['libelleTypeUser'], $query[0]['firstnameConsultant'], $query[0]['lastnameConsultant'], $query[0]['phoneConsultant'], $query[0]['addressStreetConsultant'], $query[0]['addressCityConsultant'], $query[0]['postalCodeConsultant'], $query[0]['mailConsultant'], $query[0]['password'], $query[0]['commissionRate']);
        return $myAccount;

    }

    public static function updateAccountInformation($id,$addressCity,$codePostal,$phone){

        $update = connexion::exec('update CONSULTANT set phoneConsultant="'.$phone.'", addressCityConsultant="'.$addressCity.'", postalCodeConsultant="'.$codePostal.'" where idConsultant='.$id);
        return $update;
    }

}