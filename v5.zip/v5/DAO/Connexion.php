<?php



class Connexion {

    private static $_pdo = null;

    private function __construct() {
        
    }

    private function _get() {
        $dsn = 'mysql:dbname='.\Config::BDD_NAME.';host='.\Config::BDD_HOST;
        $user = \Config::BDD_USER;
        $password = \Config::BDD_PASSWORD;

        try {
            self::$_pdo = new \PDO($dsn, $user, $password);
        } catch (PDOException $e) {
            echo 'Connexion échouée : ' . $e->getMessage();
        }
        self::$_pdo->exec('SET NAMES \'utf8\'');
    }


    public function prepare($query){
        return $this->_pdo->prepare($query);
    }


    public static function query($query) {
        if (is_null(self::$_pdo)) {
            self::_get();
        }
        
        $result = self::$_pdo->query($query);
        if(!$result){
            throw new Exception('Erreur de requête : '.$query);
        }
        return $result->fetchAll(\PDO::FETCH_ASSOC);
    }


    public static function exec($query) {
        if (is_null(self::$_pdo)) {
            self::_get();
        }
        return self::$_pdo->exec($query);
    }
    /**
     * return first row from a query
     * @param $query
     * @param int $fetchResult
     * @return mixed|null
     * @throws Exception
     */
    public static function first($query, $fetchResult = \PDO::FETCH_NUM) {
        $result = self::query($query,$fetchResult);
        if(isset($result[0])){
            return $result[0];
        }else{
            return null;
        }
    }
}
