<?php


class ExpensesDAO
{


    public static function getFirstExpenses(){

        $query = Connexion::first('select * from EXPENSES');

        $newExpenses = new Expenses($query['idExpenses'],$query['fonciere'],$query['livingExpenses'],$query['expenses'],$query['sanitation_id'],$query['heatingMethod_id'],$query['energy_id'],$query['hotWater_id']);

        return $newExpenses;
    }


    public static function insertNewExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater){

        Connexion::exec('insert into EXPENSES values(NULL,'.$post['fonciere'].','.$post['livingExpenses'].','.$post['expenses'].','.$idSanitation.','.$idHeatingMethod.','.$idEnergy.','.$idHotWater.')');

        $query =Connexion::first('select idExpenses from EXPENSES order by idExpenses DESC');

        return $query;
    }

    public static function updateExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater){

        Connexion::exec('Update EXPENSES SET fonciere="'.$post['fonciere'].'",livingExpenses="'.$post['livingExpenses'].'",expenses="'.$post['expenses'].'",sanitation_id="'.$idSanitation.'",heatingMethod_id="'.$idHeatingMethod.'",energy_id="'.$idEnergy.'",hotWater_id="'.$idHotWater.'" where idExpenses='.$post['idExpenses']);
    }
}