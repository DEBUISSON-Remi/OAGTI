<?php


class HeatingMethodDAO
{
    public static function getNoHeatingMethod()
    {
        $querys= Connexion::first('select * from HEATING_METHOD');

        $heatingMethod = new HeatingMethod($querys['idHeatingMethod'],$querys['libelleHeatingMethod']);

        return $heatingMethod;
    }

    public static function getAllEnergy()
    {
        $idHeatingMethod= HeatingMethodDAO::getNoHeatingMethod();

        $querys = Connexion::query('select * from HEATING_METHOD where idHeatingMethod !='.$idHeatingMethod->getId());

        foreach ($querys as $query){
            $heatingMethod[] = new HeatingMethod($query['idHeatingMethod'],$query['libelleHeatingMethod']);
        }

        return $heatingMethod;
    }

    public static function insertHeatingMethod($post){

        Connexion::exec('insert into HEATING_METHOD VALUES(NULL,"'.$post['newHeatingMethod'].'")');
        $idHeatingMethod = Connexion::first('select * from HEATING_METHOD order by idHeatingMethod DESC');
        return $idHeatingMethod['idHeatingMethod'];
    }
}