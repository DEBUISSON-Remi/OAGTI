<?php


class DirectoryDAO
{
    public function getOwner()
    {
        $owner=[];
        $querys= connexion::query('select * from OWNER order by lastnameOwner ');
        foreach($querys as $query){
            $owner[] = new Owner($query);
        }
        return $owner;
    }

    public function getConsultant($idTypeUser)
    {
        $querys = connexion::query('select * from CONSULTANT, TYPEUSER WHERE TYPEUSER.idTypeUser=CONSULTANT.typeUser_id AND typeUser_id!='.$idTypeUser.' order by firstnameConsultant');
        foreach ($querys as $query){
            $typeUser = new TypeUser($query['typeUser_id'],$query['libelleTypeUser']);
            $consultant[] = new Consultant($query['idConsultant'], $typeUser, $query['firstnameConsultant'], $query['lastnameConsultant'], $query['phoneConsultant'], $query['addressStreetConsultant'], $query['addressCityConsultant'], $query['postalCodeConsultant'], $query['mailConsultant'], $query['password'], $query['commissionRate']);

        }

        return $consultant;

    }

}