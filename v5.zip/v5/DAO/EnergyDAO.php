<?php


class EnergyDAO
{
    public static function getNoEnergy()
    {
        $querys= Connexion::first('select * from ENERGY');

        $energy = new Energy($querys['idEnergy'],$querys['libelleEnergy']);

        return $energy;
    }

    public static function getAllEnergy()
    {
        $idEnergy= EnergyDAO::getNoEnergy();

        $querys = Connexion::query('select * from ENERGY where idEnergy !='.$idEnergy->getId().' order by libelleEnergy ASC');

        foreach ($querys as $query){
        $energy[] = new Energy($query['idEnergy'], $query['libelleEnergy']);
        }

        return $energy;
    }

    public static function insertNewEnergy($post){

        Connexion::exec('insert into ENERGY VALUES(NULL,"'.$post['newEnergy'].'")');
        $idEnergy = Connexion::first('select * from ENERGY order by idEnergy DESC');
        return $idEnergy['idEnergy'];
    }
}