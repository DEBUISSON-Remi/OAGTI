<?php


class RoomDAO
{


    public static function insertNewRoomPost($post,$idProperty){


        if($post['nbRoom'] != '0'){
            $nbRoom = $post['nbRoom'];
            $nbRoom = $nbRoom -1;

            $idRoom = 0;
            foreach(range(0,$nbRoom) as $room){

                $surface = $post['surfaceRoom'][$idRoom];
                if($surface == ""){
                    $surface = 0;
                }
                Connexion::exec('insert into ROOM values(NULL,'.$idProperty.',"'.$post['libelleRoom'][$idRoom].'",'.$surface.')');
                $idRoom++;

            }
        }

    }

    public static function getAllRoomByPropertyId($idProperty){

        $datas = Connexion::query('select * from ROOM where property_id ='.$idProperty);

        if (!isset($datas[0])){
            return null;
        }
        else{
            foreach($datas as $data){

                $room[] = new Room($data['idRoom'],$data['property_id'],$data['libelleRoom'],$data['surface']);
            }
        }
        return $room;
    }

    public static function updateRoom($post){

        if($post['nbRoom'] != '0'){
            Connexion::exec('Delete from ROOM where property_id ='.$post['idProperty']);

            $nbRoom = $post['nbRoom'];
            $nbRoom = $nbRoom -1;
            $idRoom = 0;

            foreach(range(0,$nbRoom) as $room){

                $surface = $post['surfaceRoom'][$idRoom];
                if($surface == ""){
                    $surface = 0;
                }
                Connexion::exec('insert into ROOM values(NULL,'.$post['idProperty'].',"'.$post['libelleRoom'][$idRoom].'",'.$surface.')');
                $idRoom++;

            }
        }


    }
}