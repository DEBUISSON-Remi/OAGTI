<?php


class HotWaterDAO
{
    public static function getNoHotWater()
    {
        $querys= Connexion::first('select * from HOT_WATER');

        $hotWater = new HotWater($querys['idHotWater'],$querys['libelleHotWater']);
        return $hotWater;
    }

    public static function getAllEnergy()
    {
        $idHotWater= HotWaterDAO::getNoHotWater();

        $querys = Connexion::query('select * from HOT_WATER where idHotWater !='.$idHotWater->getId());

        foreach ($querys as $query){
            $hotWater[] = new HotWater($query['idHotWater'],$query['libelleHotWater']);
        }

        return $hotWater;
    }

    public static function insertNewHotWater($post){

        Connexion::exec('insert into HOT_WATER values(NULL,"'.$post['newHotWater'].'")');
        $idHotWater = Connexion::first('select idHotWater from HOT_WATER order by idHotWater desc');
        return $idHotWater['idHotWater'];
    }
}