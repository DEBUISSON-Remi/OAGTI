<?php


class MandateDAO
{

    public static function insertNewMandatePost($post){

        $idStatutMandate = StatutMandateDAO::getFirstStatutMandate();

        Connexion::exec('insert into MANDATE values (NULL,'.$post['typeMandate_id'].',"'.$post['mandateName'].'","'.$post['agencyName'].'","'.$post['agencyPhone'].'","'.$post['addressStreetAgency'].'","'.$post['addressCityAgency'].'","'.$post['postalCodeAgency'].'",'.$post['propertyPrice'].','.$idStatutMandate['idStatutMandate'].')');

        $query = Connexion::first('select idMandate from MANDATE order by idMandate DESC');

        return $query;
    }

    public static function getOneMandateById($idMandate){


        $data = Connexion::query('select * from MANDATE, STATUT_MANDATE, TYPEMANDATE where STATUT_MANDATE.idStatutMandate = MANDATE.statusMandate_id AND TYPEMANDATE.idTypeMandate = MANDATE.typeMandate_id AND idMandate ='.$idMandate);

        $typeMandate = new TypeMandate($data[0]['idTypeMandate'],$data[0]['libelleTypeMandate']);

        $statutMandate = new StatutMandate($data[0]['idStatutMandate'],$data[0]['libelleStatutMandate']);

        $mandate = new Mandate($data[0]['idMandate'],$typeMandate,$data[0]['mandateName'],$data[0]['agencyName'],$data[0]['agencyPhone'],$data[0]['addressStreetAgency'],$data[0]['addressCityAgency'],$data[0]['postalCodeAgency'],$data[0]['propertyPrice'],$statutMandate);

        return $mandate;
    }

    public static function getSumPropertySellByOneConsultant($consultantId)

    {

        $resultat = Connexion::query('SELECT idConsultant,SUM(propertyPrice)  FROM MANDATE,SIGN,CONSULTANT WHERE MANDATE.idMandate= SIGN.mandate_id AND CONSULTANT.idConsultant = SIGN.consultant_id  AND  CONSULTANT.idConsultant ='.$consultantId);
        $sumPropertySell=$resultat[0]['SUM(propertyPrice)'];
        return $sumPropertySell;



    }

    public static function getCountPropertySoldByOneConsultant($consultantId)

    {
        $resultat = Connexion::query('SELECT idConsultant,COUNT(statutPurchase_id)FROM CONSULTANT ,PROPERTY, PURCHASE, STATUT_PURCHASE WHERE PURCHASE.statutPurchase_id=STATUT_PURCHASE.idStatutPurchase AND PURCHASE.property_id=PROPERTY.idProperty AND STATUT_PURCHASE.idStatutPurchase = "2" AND CONSULTANT.idConsultant ='.$consultantId);
        $sumPropertySold=$resultat[0]['COUNT(statutPurchase_id)'];

        return $sumPropertySold;
    }

    public static function getCountPropertiesForSaleByOneConsultant($consultantId)

    {
        $resultat = Connexion::query('SELECT idConsultant,COUNT(statutPurchase_id)FROM CONSULTANT ,PROPERTY, PURCHASE, STATUT_PURCHASE WHERE PURCHASE.statutPurchase_id=STATUT_PURCHASE.idStatutPurchase AND PURCHASE.property_id=PROPERTY.idProperty AND STATUT_PURCHASE.idStatutPurchase = "1" AND CONSULTANT.idConsultant ='.$consultantId);
        $countPropertyForSale=$resultat[0]['COUNT(statutPurchase_id)'];

        return $countPropertyForSale;
    }

    public static function getCountPropertiesCanceledByOneConsultant($consultantId)

    {
        $resultat = Connexion::query('SELECT idConsultant,COUNT(statutPurchase_id) FROM CONSULTANT ,PROPERTY, PURCHASE, STATUT_PURCHASE WHERE PURCHASE.statutPurchase_id=STATUT_PURCHASE.idStatutPurchase AND PURCHASE.property_id=PROPERTY.idProperty AND STATUT_PURCHASE.idStatutPurchase = "3"AND CONSULTANT.idConsultant ='.$consultantId);
        $countPropertyCanceled=$resultat[0]['COUNT(statutPurchase_id)'];

        return $countPropertyCanceled;
    }



    public static function getCountPropertiesCurrentFolderByOneConsultant($consultantId)

    {
        $resultat = Connexion::query('SELECT  COUNT(idMandate) FROM SIGN,MANDATE,STATUT_MANDATE WHERE MANDATE.statusMandate_id=STATUT_MANDATE.idStatutMandate AND SIGN.mandate_id = MANDATE.idMandate AND STATUT_MANDATE.idStatutMandate = "1"  AND consultant_id ='.$consultantId);
        $countCurrentFolder=$resultat[0]['COUNT(idMandate)'];

        return $countCurrentFolder;
    }

    public static function getCountPropertiesCompleteFolderByOneConsultant($consultantId)

    {
        $resultat = Connexion::query('SELECT  COUNT(idMandate) FROM SIGN,MANDATE,STATUT_MANDATE WHERE MANDATE.statusMandate_id=STATUT_MANDATE.idStatutMandate AND SIGN.mandate_id = MANDATE.idMandate AND STATUT_MANDATE.idStatutMandate = "2"  AND consultant_id ='.$consultantId);
        $countCompleteFolder=$resultat[0]['COUNT(idMandate)'];

        return $countCompleteFolder;
    }

    public static function getCountPropertiesArchivedFolderByOneConsultant($consultantId)

    {
        $resultat = Connexion::query('SELECT  COUNT(idMandate) FROM SIGN,MANDATE,STATUT_MANDATE WHERE MANDATE.statusMandate_id=STATUT_MANDATE.idStatutMandate AND SIGN.mandate_id = MANDATE.idMandate AND STATUT_MANDATE.idStatutMandate = "3"  AND consultant_id ='.$consultantId);
        $countArchivedFolder=$resultat[0]['COUNT(idMandate)'];

        return $countArchivedFolder;
    }




}