<?php


class PropertyDAO
{



    public static function registerHouse($post){


        if(null == $post['idOwnerExisting']){
            $idOwner = OwnerDAO::insertNewOwnerPost($post);
        }
        else{
            $idOwner = OwnerDAO::getOneOwnerIdById($post['idOwnerExisting']);

        }

        if('' != $post['newSanitation']){
            $idSanitation = SanitationDAO::insertNewSanitation($post);

        }
        else{
            $idSanitation = $post['sanitation_id'];
        }

        if( '' != $post['newHeatingMethod']){
            $idHeatingMethod = HeatingMethodDAO::insertHeatingMethod($post);

        }
        else{
            $idHeatingMethod = $post['heatingMethod_id'];
        }

        if( '' != $post['newEnergy']){
            $idEnergy = EnergyDAO::insertNewEnergy($post);

        }
        else{
            $idEnergy = $post['energy_id'];
        }

        if( '' != $post['newHotWater']){
            $idHotWater = HotWaterDAO::insertNewHotWater($post);

        }
        else{
            $idHotWater = $post['hotWater_id'];
        }

        $idOwner = $idOwner[0]['idOwner'];
        $idExpense = ExpensesDAO::insertNewExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater);

        $idProperty = PropertyDAO::insertNewPropertyPost($idOwner, $post, $idExpense);

        RoomDAO::insertNewRoomPost($post,$idProperty);

        $idMandate = MandateDAO::insertNewMandatePost($post);

        SignDAO::insertNewSignPost($idMandate,$idOwner,$_SESSION['id'],$idProperty);


    }

    public static function registerGround($post){

        if(null == $post['idOwnerExisting']){
            $idOwner = OwnerDAO::insertNewOwnerPost($post);
        }
        else{
            $idOwner = OwnerDAO::getOneOwnerIdById($post['idOwnerExisting']);

        }
        $idOwner = $idOwner[0]['idOwner'];
        $idSanitation = $post['sanitation_id'];
        $idHeatingMethod = $post['heatingMethod_id'];
        $idEnergy = $post['energy_id'];
        $idHotWater = $post['hotWater_id'];


        $idExpense = ExpensesDAO::insertNewExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater);

        $idProperty = PropertyDAO::insertNewPropertyPost($idOwner, $post, $idExpense);

        $idMandate = MandateDAO::insertNewMandatePost($post);

        SignDAO::insertNewSignPost($idMandate,$idOwner,$_SESSION['id'],$idProperty);
    }

    public static function registerAppartement($post){

        if(null == $post['idOwnerExisting']){
            $idOwner = OwnerDAO::insertNewOwnerPost($post);
        }
        else{
            $idOwner = OwnerDAO::getOneOwnerIdById($post['idOwnerExisting']);

        }

        if( null != $post['newSanitation']){
            $idSanitation = SanitationDAO::insertNewSanitation($post);

        }
        else{
            $idSanitation = $post['sanitation_id'];
        }

        if( null != $post['newHeatingMethod']){
            $idHeatingMethod = HeatingMethodDAO::insertHeatingMethod($post);
        }
        else{
            $idHeatingMethod = $post['heatingMethod_id'];
        }

        if( null != $post['newEnergy']){
            $idEnergy = EnergyDAO::insertNewEnergy($post);

        }
        else{
            $idEnergy = $post['energy_id'];
        }

        if( null != $post['newHotWater']){
            $idHotWater = HotWaterDAO::insertNewHotWater($post);

        }
        else{
            $idHotWater = $post['hotWater_id'];
        }

        $idOwner = $idOwner[0]['idOwner'];


        $idExpense = ExpensesDAO::insertNewExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater);

        $idProperty = PropertyDAO::insertNewPropertyPost($idOwner, $post, $idExpense);

        RoomDAO::insertNewRoomPost($post,$idProperty);

        $idMandate = MandateDAO::insertNewMandatePost($post);

        SignDAO::insertNewSignPost($idMandate,$idOwner,$_SESSION['id'], $idProperty);
    }


    public static function insertNewPropertyPost($idOwner, $post , $idExpense){
        $dateConstruct = $post['constructionDate'];
        if ($dateConstruct == null) {
            $dateConstruct = "0000-00-00";
        }
        Connexion::exec('Insert into PROPERTY values(NULL,'.$idOwner.','.$post['typeProperty_id'].','.$post['nbRoom'].',"'.$dateConstruct.'","'.$post['comment'].'","",'.$post['propertySurface'].','.$post['propertyGround'].',"'.$post['addressStreetProperty'].'","'.$post['addressStreetProperty'].'","'.$post['postalCodeProperty'].'","'.$post['locality'].'",'.$post['buildingNumber'].','.$post['ISPPrice'].','.$post['agencyFee'].','.$idExpense['idExpenses'].')');
        $idProperty = Connexion::first('select idProperty from PROPERTY ORDER BY idProperty DESC');
        return $idProperty['idProperty'];
    }


    public static function getPropertyNotFinish(){

        $signs = SignDAO::getSignByConsultantId();

        $consultant = ConsultantDAO::getOneConsultantById();

        if($signs == null){
            return null;
        }
        else {
            foreach ($signs as $sign) {
                if ($sign->getDateSignature() == null) {

                    $owner = OwnerDAO::getOneOwnerById($sign->getOwnerId());

                    $mandate = MandateDAO::getOneMandateById($sign->getMandateId());
                    $property = PropertyDAO::getOnePropertyById($sign->getPropertyId(), $owner);

                    $all[] = new PropertyInformation($owner, $mandate, $property, $consultant);
                }
            }
            if(!isset($all)){
                return null;
            }
            else{
                return $all;
            }
        }
    }

    public static function getOnePropertyById($idProperty,$owner){

        $data = Connexion::query('select * from PROPERTY,TYPEPROPERTY,EXPENSES,HOT_WATER,HEATING_METHOD,SANITATION,ENERGY where EXPENSES.idExpenses = PROPERTY.expenses_id and TYPEPROPERTY.idTypeProperty = PROPERTY.typeProperty_id and HOT_WATER.idHotWater = EXPENSES.hotWater_id and HEATING_METHOD.idHeatingMethod = EXPENSES.heatingMethod_id and SANITATION.idSanitation = EXPENSES.sanitation_id and ENERGY.idEnergy = EXPENSES.energy_id and PROPERTY.idProperty ='.$idProperty);

        $sanitation = new Sanitation($data[0]['idSanitation'],$data[0]['libelleSanitation']);
        $hotWater = new HotWater($data[0]['idHotWater'],$data[0]['libelleHotWater']);
        $energy = new Energy ($data[0]['idEnergy'],$data[0]['libelleEnergy']);
        $heatingMethod = new HeatingMethod($data[0]['idHeatingMethod'],$data[0]['libelleHeatingMethod']);

        $expenses = new Expenses($data[0]['idExpenses'],$data[0]['fonciere'],$data[0]['livingExpenses'],$data[0]['expenses'],$sanitation,$heatingMethod,$energy,$hotWater);

        $typeProperty = new TypeProperty($data[0]['idTypeProperty'],$data[0]['libelleTypeProperty']);

        $property = new Property($data[0]['idProperty'],$owner,$typeProperty,$data[0]['nbRoom'],$data[0]['constructionDate'],$data[0]['comment'],$data[0]['pictures'],$data[0]['propertySurface'],$data[0]['propertyGround'],$data[0]['addressStreetProperty'],$data[0]['addressCityProperty'],$data[0]['postalCodeProperty'],$data[0]['locality'],$data[0]['buildingNumber'],$data[0]['ISPPrice'],$data[0]['agencyFee'],$expenses);



        return $property;
    }


    public static function getPropertyByMandateId($post){

        $sign = SignDAO::getSignByMandateId($post);

        $consultant = ConsultantDAO::getOneConsultantById();

        $owner = OwnerDAO::getOneOwnerById($sign->getOwnerId());

        $mandate = MandateDAO::getOneMandateById($sign->getMandateId());

        $property = PropertyDAO::getOnePropertyById($sign->getPropertyId(), $owner);


        $all = new PropertyInformation($owner, $mandate, $property, $consultant);

        return $all;
    }

    public static function updateProperty($post)
    {
        if('' != $post['newSanitation']){
            $idSanitation = SanitationDAO::insertNewSanitation($post);

        }
        else{
            $idSanitation = $post['sanitation_id'];
        }

        if( '' != $post['newHeatingMethod']){
            $idHeatingMethod = HeatingMethodDAO::insertHeatingMethod($post);

        }
        else{
            $idHeatingMethod = $post['heatingMethod_id'];
        }

        if( '' != $post['newEnergy']){
            $idEnergy = EnergyDAO::insertNewEnergy($post);

        }
        else{
            $idEnergy = $post['energy_id'];
        }

        if( '' != $post['newHotWater']){
            $idHotWater = HotWaterDAO::insertNewHotWater($post);

        }
        else{
            $idHotWater = $post['hotWater_id'];
        }

        OwnerDAO::updateOwnerPost($post);

        ExpensesDAO::updateExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater);

        RoomDAO::updateRoom($post);

        PropertyDAO::updatePropertyPost($post);

        MandateDAO::updateMandatePost($post);
    }

    public static function updateGround($post)
    {
        $idSanitation = $post['sanitation_id'];
        $idHeatingMethod = $post['heatingMethod_id'];
        $idEnergy = $post['energy_id'];
        $idHotWater = $post['hotWater_id'];

        OwnerDAO::updateOwnerPost($post);

        ExpensesDAO::updateExpensesPost($post,$idSanitation,$idHeatingMethod,$idEnergy,$idHotWater);

        PropertyDAO::updatePropertyPost($post);

        MandateDAO::updateMandatePost($post);
    }

    public static function updatePropertyPost($post)
    {
        $dateConstruct = $post['constructionDate'];
        if ($dateConstruct == null) {
            $dateConstruct = "0000-00-00";
        }
        Connexion::exec('Update PROPERTY SET nbRoom='.$post['nbRoom'].',constructionDate="'.$dateConstruct.'",comment="'.$post['comment'].'",propertySurface='.$post['propertySurface'].',propertyGround='.$post['propertyGround'].',addressStreetProperty="'.$post['addressStreetProperty'].'",addressCityProperty="'.$post['addressCityProperty'].'",postalCodeProperty="'.$post['postalCodeProperty'].'",locality="'.$post['locality'].'",buildingNumber='.$post['buildingNumber'].',ISPPrice='.$post['ISPPrice'].',agencyFee='.$post['agencyFee'].' where idProperty='.$post['idProperty']);
    }

    public static function getPropertyByOwner($idOwner)
    {
        $owner= OwnerDAO::getOneOwnerById($idOwner);

        $datas = Connexion::query('select * from PROPERTY,TYPEPROPERTY,EXPENSES,HOT_WATER,HEATING_METHOD,SANITATION,ENERGY where EXPENSES.idExpenses = PROPERTY.expenses_id and TYPEPROPERTY.idTypeProperty = PROPERTY.typeProperty_id and HOT_WATER.idHotWater = EXPENSES.hotWater_id and HEATING_METHOD.idHeatingMethod = EXPENSES.heatingMethod_id and SANITATION.idSanitation = EXPENSES.sanitation_id and ENERGY.idEnergy = EXPENSES.energy_id and PROPERTY.owner_id ='.$idOwner);

        if(!isset ($datas[0])){
            return null;
        }
        else{
            foreach($datas as $data){

                $sanitation = new Sanitation($data['idSanitation'],$data['libelleSanitation']);
                $hotWater = new HotWater($data['idHotWater'],$data['libelleHotWater']);
                $energy = new Energy ($data['idEnergy'],$data['libelleEnergy']);
                $heatingMethod = new HeatingMethod($data['idHeatingMethod'],$data['libelleHeatingMethod']);

                $expenses = new Expenses($data['idExpenses'],$data['fonciere'],$data['livingExpenses'],$data['expenses'],$sanitation,$heatingMethod,$energy,$hotWater);

                $typeProperty = new TypeProperty($data['idTypeProperty'],$data['libelleTypeProperty']);

                $property[] = new Property($data['idProperty'],$owner,$typeProperty,$data['nbRoom'],$data['constructionDate'],$data['comment'],$data['pictures'],$data['propertySurface'],$data['propertyGround'],$data['addressStreetProperty'],$data['addressCityProperty'],$data['postalCodeProperty'],$data['locality'],$data['buildingNumber'],$data['ISPPrice'],$data['agencyFee'],$expenses);
            }
        }
        return $property;
    }

    public static function getPropertyNotFinishConsultant($idConsultant){

        $signs = SignDAO::getSignByConsultantIdDirectory($idConsultant);

        $consultant = ConsultantDAO::getOneConsultantById();

        if($signs == null){
            return null;
        }
        else {
            foreach ($signs as $sign) {
                if ($sign->getDateSignature() == null) {

                    $owner = OwnerDAO::getOneOwnerById($sign->getOwnerId());

                    $mandate = MandateDAO::getOneMandateById($sign->getMandateId());
                    $property = PropertyDAO::getOnePropertyById($sign->getOwnerId(), $owner);

                    $all[] = new PropertyInformation($owner, $mandate, $property, $consultant);
                }
            }
            if(!isset($all)){
                return null;
            }
            else{
                return $all;
            }
        }
    }

    public static function getAllInformationPDF($post){
        $sign = SignDAO::getSignByMandateId($post);

        $consultant = ConsultantDAO::getOneConsultantById();

        $owner = OwnerDAO::getOneOwnerById($sign->getOwnerId());

        $mandate = MandateDAO::getOneMandateById($sign->getMandateId());

        $property = PropertyDAO::getOnePropertyById($sign->getPropertyId(), $owner);

        $all = new PropertyInformation($owner, $mandate, $property, $consultant);

        return $all;
    }
}