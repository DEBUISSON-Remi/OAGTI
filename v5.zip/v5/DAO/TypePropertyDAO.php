<?php


class TypePropertyDAO
{
    public function getAllTypeProperty()
    {
        $querys= Connexion::query('select * from TYPEPROPERTY');

        foreach ($querys as $query ){
        $typeProperty = new TypeProperty($query ['idTypeProperty'], $query ['libelleStatutProperty']);
    }

        return $typeProperty;
    }

}