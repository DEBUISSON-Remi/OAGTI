<?php


class ConsultantDAO
{

    public static function getOneConsultantById(){

        $data = Connexion::query('select * from CONSULTANT,TYPEUSER where TYPEUSER.idTypeUser = CONSULTANT.typeUser_id  and idConsultant ='.$_SESSION['id']);

        $typeUser = new TypeUser($data[0]['typeUser_id'],$data[0]['libelleTypeUser']);
        $consultant = new Consultant($data[0]['idConsultant'], $typeUser, $data[0]['firstnameConsultant'], $data[0]['lastnameConsultant'], $data[0]['phoneConsultant'], $data[0]['addressStreetConsultant'], $data[0]['addressCityConsultant'], $data[0]['postalCodeConsultant'], $data[0]['mailConsultant'], $data[0]['password'],$data[0]['commissionRate']);
        return $consultant;
    }
}