<?php


class TransactionController
{

    public static function switchAction($action)
    {
        $objet=new DashboardController();
        $methodToBeCalled = $action . "Action";
        if (method_exists($objet,$methodToBeCalled)) {
            call_user_func('self::' . $methodToBeCalled, []);
        } else {
            self::defaultAction();
        }
    }

    private static function defaultAction() {
        $titreOnglet=APPLI_NAME;
        $titrePage="Accueil";
        include('../page/accueilPage_default.php');
    }
}