<?php


class LoginController
{

    public static function switchAction($action)
    {
        $objet=new LoginController();
        $methodToBeCalled = $action . "Action";
        if (method_exists($objet,$methodToBeCalled)) {
            call_user_func('self::' . $methodToBeCalled, []);
        } else {
            self::defaultAction();
        }
    }

    private static function defaultAction() {
        $titreOnglet=Config::APPLI_NAME;
        include('../page/page_login.php');
    }

    private static function logoutAction() {
        unset($_SESSION['name']);
        unset($_SESSION['surname']);
        unset($_SESSION['typeUser']);
        unset($_SESSION['id']);
        header("Cache-Control: no-store, no-cache, must-revalidate");
        include('../page/page_login.php');
    }

    public static function loginCheck(){
        $etat=null;
        $consultant = ConnexionDAO::getOneUser($_POST['mail']);
        if ($consultant == null) {
            return $etat;
        }
        elseif ($consultant->getPassword() == $_POST['password']){
            return $consultant;


        }
    }


    public static function myAccountAction(){

        $myAccount= ConnexionDAO::getOneUserById($_SESSION['id']);
        include ('../page/page_myAccount.php');
    }

    public static function updateAccountAction(){
        ConnexionDAO::updateAccountInformation($_POST['idConsultant'],$_POST['adresseVille'],$_POST['codePostal'],$_POST['tel']);
        $myAccount= ConnexionDAO::getOneUserById($_SESSION['id']);
        include ('../page/page_myAccount.php');
    }

}