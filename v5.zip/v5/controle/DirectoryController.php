<?php


class DirectoryController
{

    public static function switchAction($action)
    {
        $objet=new DirectoryController();
        $methodToBeCalled = $action . "Action";
        if (method_exists($objet,$methodToBeCalled)) {
            call_user_func('self::' . $methodToBeCalled, []);
        } else {
            self::defaultAction();
        }
    }

    private static function defaultAction() {
        $titreOnglet=Config::APPLI_NAME;

        include('../page/page_directoryConsultantSearch.php');
    }

    private static function consultantSearchAction(){
        $titrePage = "Rechercher un consultant :";
        $consultants = DirectoryDAO::getConsultant($_SESSION['typeUser']->getId());
        include('../page/page_directoryConsultantSearch.php');
    }

    private static function ownerSearchAction(){
        $titrePage = "Rechercher un client :";
        $owners = DirectoryDAO::getOwner();
        include('../page/page_directoryOwnerSearch.php');
    }

    private static function viewRegistrationByConsultantAction(){

        $informations = PropertyDAO::getPropertyNotFinishConsultant($_POST['idConsultant']);
        if ($informations == null){
            $etatProperty = 0;
        }
        else {
            $etatProperty = 1;
        }
        include('../page/page_directoryListPropertyOneConsultant.php');

    }

    private static function viewPropertyByOwnerAction(){

        $informations = PropertyDAO::getPropertyByOwner($_POST['idOwner']);
        if ($informations == null){
            $etatProperty = 0;
        }
        else {
            $etatProperty = 1;
        }

        include('../page/page_directoryListPropertyOneOwner.php');

    }
}