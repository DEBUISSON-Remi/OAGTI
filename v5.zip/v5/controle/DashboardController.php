<?php

class DashboardController{


    public static function switchAction($action)
    {
        $objet=new DashboardController();
        $methodToBeCalled = $action . "Action";
        if (method_exists($objet,$methodToBeCalled)) {
            call_user_func('self::' . $methodToBeCalled, []);
        } else {
            self::defaultAction();
        }
    }

    private static function defaultAction() {
        /** Argent généré */
        $totalPropertiesSell = MandateDAO::getSumPropertySellByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var ArgentGenere = <?php echo json_encode($totalPropertiesSell); ?>;
        </script>
        <?php

        /** nombres de biens vendus */
        $totalPropertiesSold = MandateDAO::getCountPropertySoldByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var nbBiensVendus = <?php echo json_encode($totalPropertiesSold); ?>;
        </script>
        <?php

        /**  Biens en cours de vente */
        $totalPropertiesForSale = MandateDAO::getCountPropertiesForSaleByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var BiensEnCoursDeVente = <?php echo json_encode($totalPropertiesForSale); ?>;
        </script>
        <?php

        /** Biens abandonnés ou archivés */
        $totalPropertiesCanceled = MandateDAO::getCountPropertiesCanceledByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var BiensAbandonnes = <?php echo json_encode($totalPropertiesCanceled); ?>;
        </script>
        <?php


        /** Dossier en cours */
        $totalCurrentFolder = MandateDAO::getCountPropertiesCurrentFolderByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var DossierEnCours = <?php echo json_encode($totalCurrentFolder); ?>;
        </script>
        <?php


        /** Dossier complet*/
        $totalCompleteFolder = MandateDAO::getCountPropertiesCompleteFolderByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var DossierComplet = <?php echo json_encode($totalCompleteFolder); ?>;
        </script>
        <?php


        /** Dossier archivé*/
        $totalArchivedFolder =  MandateDAO::getCountPropertiesArchivedFolderByOneConsultant($_SESSION['id']);
        ?>
        <script>
            var dossierArchive = <?php echo json_encode($totalArchivedFolder); ?>;
        </script>
        <?php

        $consultant = ConsultantDAO:: getOneConsultantById();

        $commissionRate=$consultant->getCommissionRate()/100;
        include('../page/page_dashboard.php');

    }

}
