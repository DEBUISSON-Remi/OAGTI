<?php


class PropretyController
{

    public static function switchAction($action)
    {
        $objet=new PropretyController();
        $methodToBeCalled = $action . "Action";
        if (method_exists($objet,$methodToBeCalled)) {
            call_user_func('self::' . $methodToBeCalled, []);
        } else {
            self::defaultAction();
        }
    }

    private static function defaultAction() {
        $titreOnglet=Config::APPLI_NAME;
        include('../page/page_dashboard.php');
    }

    private static function registerHouseAction(){
        $owners = OwnerDAO::getAllOwner();
        $sanitations = SanitationDAO::getAllEnergy();
        $heatingMethods = HeatingMethodDAO::getAllEnergy();
        $energys = EnergyDAO::getAllEnergy();
        $hotWaters = HotWaterDAO::getAllEnergy();
        $consultant = ConnexionDAO::getOneUserById($_SESSION['id']);
        include('../page/page_registerHouse.php');

    }

    private static  function registerGroundAction(){
        $owners = OwnerDAO::getAllOwner();
        $sanitations = SanitationDAO::getNoSanitation();
        $heatingMethods = HeatingMethodDAO::getNoHeatingMethod();
        $energys = EnergyDAO::getNoEnergy();
        $hotWaters = HotWaterDAO::getNoHotWater();
        $consultant = ConnexionDAO::getOneUserById($_SESSION['id']);
        include('../page/page_registerGround.php');
    }

    private static function registerApartmentAction(){
        $owners = OwnerDAO::getAllOwner();
        $sanitations = SanitationDAO::getAllEnergy();
        $heatingMethods = HeatingMethodDAO::getAllEnergy();
        $energys = EnergyDAO::getAllEnergy();
        $hotWaters = HotWaterDAO::getAllEnergy();
        $consultant = ConnexionDAO::getOneUserById($_SESSION['id']);
        include('../page/page_registerApartment.php');
    }

    private static function currentHouseRegistersAction(){



        PropertyDAO::registerHouse($_POST);
        header('location: ?route=property&action=propertyUnderRegistration');



    }

    private static function currentAppartementRegistersAction(){


        PropertyDAO::registerAppartement($_POST);
        header('location: ?route=property&action=propertyUnderRegistration');
    }

    private static function currentGroundRegisterAction(){

        PropertyDAO::registerGround($_POST);
        header('location: ?route=property&action=propertyUnderRegistration');
    }

    private static function propertyUnderRegistrationAction(){

        $informations = PropertyDAO::getPropertyNotFinish();
        if ($informations == null){
            $etatProperty = 0;
        }
        else {
            $etatProperty = 1;
        }
        include('../page/page_listPropertyUnderRegistration.php');
    }


    private static function propertyUpdateAction(){

        $information = PropertyDAO::getPropertyByMandateId($_POST);

        if($information->getTypeProperty()->getId() === '1' ){
            $rooms = RoomDAO::getAllRoomByPropertyId($information->getProperty()->getId());
            $sanitations = SanitationDAO::getAllEnergy();
            $heatingMethods = HeatingMethodDAO::getAllEnergy();
            $energys = EnergyDAO::getAllEnergy();
            $hotWaters = HotWaterDAO::getAllEnergy();
            include('../page/updateProperty/page_updateHouse.php');
        }

        elseif ($information->getTypeProperty()->getId() === '2' ){

            include('../page/updateProperty/page_updateGround.php');
        }

        elseif ($information->getTypeProperty()->getId() === '3') {
            $rooms = RoomDAO::getAllRoomByPropertyId($information->getProperty()->getId());
            $sanitations = SanitationDAO::getAllEnergy();
            $heatingMethods = HeatingMethodDAO::getAllEnergy();
            $energys = EnergyDAO::getAllEnergy();
            $hotWaters = HotWaterDAO::getAllEnergy();
            include('../page/updateProperty/page_updateApartment.php');
        }
    }

    private static function PropertyUpdateClickAction()
    {

        PropertyDAO::updateProperty($_POST);
        header('location: ?route=property&action=propertyUnderRegistration');
    }

    private static function GroundUpdateClickAction()
    {

        PropertyDAO::updateGround($_POST);
        header('location: ?route=property&action=propertyUnderRegistration');
    }

    private static function PDFAction(){
        $information = PropertyDAO::getAllInformationPDF($_POST);
        include ('../page/pdf.php');
    }



}