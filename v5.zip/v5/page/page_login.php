<?php
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Globagence - Login</title>
    <link rel="stylesheet" href="./css/login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
<form method="post" action="">
    <div class="entite-title"><h1>Globagence - connexion</h1></div>
    <div class="entite-login">
        <div class="username">
            <p>Login :</p><input class="pseudo" type="text" name="mail" required>
        </div>
        <div class="password">
            <p>Password :</p><input class="mdp" type="password" name="password" required>
        </div>
        <div class="button-login">
            <input class="button-connecter" type="submit" value="Se connecter">
            <br><br>
            <button type="button" class="btn btn-primary" data-toggle="collapse" data-target="#demo" style="position: center">Informations utiles</button>
            <div id="demo" class="collapse">
                <b>Nom de l'application : </b><?php echo Config::APPLI_NAME ?>
                <br>
                <b>Version de l'application : </b><?php echo Config::APPLI_VERSION ?>
                <br>
                <b>Membres de l'équipe : </b>
                <br>
                <i>Piccerelle Killian - Martineau Antoine</i>
                <br>
                <i>Debuisson Rémi - Nicol Anthony</i>
                <br>
                <i>Villemaine Jordan - Alexandre Samy</i>
                <br>
                <i>Bellouard Valentin</i>
                <br>
                <b>Identifiant du directeur : </b>
                <br>
                <b>Email : </b> Jhon.Wick@globagence.com<br>
                <b>Mdp : </b>  	DVP56TCG3ZV<br>
                <b>Identifiant d'un consultant : </b>
                <br>
                <b>Email :</b> dexter.Lucius@globagence.com<br>
                <b>Mdp :</b> KOF97MAB4MD<br>
            </div>
        </div>

    </div>
    <?php if ($_SESSION['etat'] == 0 ){
        echo('<script>alert("Vos identifiants sont incorrects")</script>');
    }
    ?>
    <?php if ($_SESSION['etat'] == 2 ){
        echo('<script>alert("Votre session a expirée veuillez vous reconnecter")</script>');
    }
    ?>
</form>
</body>
</html>
