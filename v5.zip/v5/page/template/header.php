<!DOCTYPE html>
<html lang="fr">
<head>
    <title><?php echo( Config::APPLI_NAME ); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body onload="checkInformations()" onchange="publishButton()">
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="?route=dashboard">oagti - <?php echo Config::APPLI_VERSION?></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li class=""><a href="?route=dashboard">Accueil</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Inscrire un bien<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?route=property&action=registerHouse">Enregistrer une maison</a></li>
                        <li><a href="?route=property&action=registerGround">Enregistrer un terrain</a></li>
                        <li><a href="?route=property&action=registerApartment">Enregistrer un appartement</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="?route=directory">Acceder aux biens<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Biens publiés</a></li>
                        <li><a href="#">Biens vendus</a></li>
                        <li><a href="?route=property&action=propertyUnderRegistration">Biens en cours d'enregistrement</a></li>
                    </ul>
                </li>
                <li><a href="#">Transactions</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Annuaire<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?route=directory&action=consultantSearch">Annuaire Consultants</a></li>
                        <li><a href="?route=directory&action=ownerSearch">Annuaire Clients</a></li>
                    </ul>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="navbar-brand"><?php echo($_SESSION['name']." ".$_SESSION['surname']." - ".$_SESSION['typeUser']->getLibelle()) ?></li>
                <li class="navbar-brand"> - </li>
                <li><a href="?route=login&action=myAccount"><span class="glyphicon glyphicon-user"></span> Mon compte</a></li>
                <li><a href="?route=login&action=logout"><span class="glyphicon glyphicon-off"></span> Déconnexion</a></li>
            </ul>
        </div>
    </div>
</nav>
