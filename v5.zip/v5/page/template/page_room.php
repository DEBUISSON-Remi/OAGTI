<?php ?>

<script>

    function changePiece() {

        var nbRoom = document.getElementById("nbRoom").value;
        var div = document.getElementById("info");
        var placement = document.getElementById("div-inserrer");

        for(i=0; i<101; i++){
            var libelle = document.getElementById("libelleRoom"+i);
            var surface = document.getElementById("surfaceRoom"+i);
            var ligne1 = document.getElementById("firstLigne"+i);
            var ligne2 = document.getElementById("secondLigne"+i);
            if (document.getElementById("libelleRoom"+i)){
                libelle.parentNode.removeChild(libelle);
                surface.parentNode.removeChild(surface);
                ligne1.parentNode.removeChild(ligne1);
                ligne2.parentNode.removeChild(ligne2);
            }
            else {

            }

        }

        for(i=0; i<nbRoom; i++){
            div = document.createElement("div");
            div.class = "row";
            div.id = "info";

            input =document.createElement("input");
            input.placeholder = "Libelle de la piece";
            input.type = "text";
            input.name = "libelleRoom[]";
            input.id = "libelleRoom"+i;
            input.style.marginLeft = "1%";
            input.maxLength = "30";

            inputSurface = document.createElement("input");
            inputSurface.placeholder = "Surface de la piece";
            inputSurface.type = "text";
            inputSurface.name = "surfaceRoom[]";
            inputSurface.id = "surfaceRoom"+i;
            inputSurface.style.marginLeft = "1%";
            inputSurface.maxLength = "2";

            sautLigne = document.createElement("br");
            sautLigne.id = "firstLigne"+i;
            sautLigne2 = document.createElement("br");
            sautLigne2.id = "secondLigne"+i;

            placement.append(div);
            div.appendChild(sautLigne);
            div.appendChild(input);
            div.appendChild(inputSurface);
            div.appendChild(sautLigne2);

        }

    }
</script>
<div>
    <h3>Nombre de pièces :</h3>
    <div class="row" style="margin-left: 1%" id="div-inserrer">
        <input type="number" name="nbRoom" id="nbRoom" placeholder="Nombre de pièces" style="-moz-appearance: textfield" maxlength="2" max="99"> -
        <button onclick="changePiece()" class="btn btn-primary" type="button">Valider</button>
    </div>
</div>
