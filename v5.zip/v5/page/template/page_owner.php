<?php ?>
<script>
    function entrepriseChecked() {
        document.getElementById("socialHeadquarters").type = "text";
        document.getElementById("socialReson").type = "text";
        document.getElementById("socialDenomination").type = "text";

        document.getElementById("addressCityOwner").type = "hidden";
        document.getElementById("addressCityOwner").value = "";
        document.getElementById("addressStreetOwner").type = "hidden";
        document.getElementById("addressStreetOwner").value = "";
        document.getElementById("postalCodeOwner").type = "hidden";
        document.getElementById("postalCodeOwner").value = "";

        document.getElementById("inscrire").innerHTML = "Vous inscriver actuellement un profil de type : Entreprise";
        document.getElementById("partie").innerHTML = "Partie Entreprise :";
    }


    function particulierChecked() {

        document.getElementById("socialHeadquarters").type = "hidden";
        document.getElementById("socialHeadquarters").value = "";
        document.getElementById("socialReson").type = "hidden";
        document.getElementById("socialReson").value = "";
        document.getElementById("socialDenomination").type = "hidden";
        document.getElementById("socialDenomination").value = "";


        document.getElementById("addressCityOwner").type = "text";
        document.getElementById("addressStreetOwner").type = "text";
        document.getElementById("postalCodeOwner").type = "text";

        document.getElementById("inscrire").innerHTML = "Vous inscriver actuellement un profil de type : Particulier";
        document.getElementById("partie").innerHTML = "Partie Particulier :";
    }


    function OwnerList() {
        var male = "Male";
        var female = "Female";
        var owner =document.getElementById("ownerList").value;
        if(owner != ""){

            document.getElementById("lastnameOwner").value = document.getElementById("lastnameFromBdd"+owner).value;
            document.getElementById("firstnameOwner").value = document.getElementById("firstnameFromBdd"+owner).value;
            document.getElementById("addressCityOwner").value = document.getElementById("addressCityFromBdd"+owner).value;
            document.getElementById("addressStreetOwner").value = document.getElementById("addressStreetFromBdd"+owner).value;
            document.getElementById("postalCodeOwner").value = document.getElementById("postalCodeFromBdd"+owner).value;
            document.getElementById("socialHeadquarters").value = document.getElementById("socialHeadquartersFromBdd"+owner).value;
            document.getElementById("socialReson").value = document.getElementById("socialReasonFromBdd"+owner).value;
            document.getElementById("socialDenomination").value = document.getElementById("socialDenominationFromBdd"+owner).value;
            document.getElementById("phoneOwner").value = document.getElementById("phoneOwnerFromBdd"+owner).value;
            document.getElementById("mailOwner").value = document.getElementById("mailOwnerFromBdd"+owner).value;
            document.getElementById("facebook").value = document.getElementById("facebookFromBdd"+owner).value;
            document.getElementById("twitter").value = document.getElementById("twitterFromBdd"+owner).value;
            if(document.getElementById("addressCityFromBdd"+owner).value != "" || document.getElementById("addressStreetFromBdd"+owner).value != "" || document.getElementById("postalCodeFromBdd"+owner).value != ""){
                particulierChecked();
                document.getElementById("particulier").checked = true;

            }
            else if(document.getElementById("socialHeadquartersFromBdd"+owner).value != "" || document.getElementById("socialDenominationFromBdd"+owner).value != "" || document.getElementById("socialReasonFromBdd"+owner).value != ""){

                entrepriseChecked();
                document.getElementById("entreprise").checked = true;
            }

            document.getElementById("checkGender").style.display = "none";
        }
        else {

            document.getElementById("lastnameOwner").value = "";
            document.getElementById("firstnameOwner").value = "";
            document.getElementById("addressCityOwner").value = "";
            document.getElementById("addressStreetOwner").value = "";
            document.getElementById("postalCodeOwner").value = "";
            document.getElementById("socialHeadquarters").value = "";
            document.getElementById("socialReson").value = "";
            document.getElementById("socialDenomination").value = "";
            document.getElementById("phoneOwner").value = "";
            document.getElementById("mailOwner").value = "";
            document.getElementById("facebook").value = "";
            document.getElementById("twitter").value = "";
            particulierChecked();
            document.getElementById("particulier").checked = true;
            document.getElementById("checkGender").style.display = "block";
        }
    }
</script>
<br>
    <div class="form-check-inline">
        <label class="form-check-label">
            <input type="radio" id="particulier" name="type" checked onclick="particulierChecked()"> Particulier
        </label>
        <label class="form-check-label">
            <input type="radio" id="entreprise" name="type" onclick="entrepriseChecked()"> Entreprise
        </label>
        <br><br>
        <label>Nom du propriétaire : (Choisissez un propriétaire dans la liste sinon inscrivez le)</label>
        <select name="idOwnerExisting" onchange="OwnerList()" id="ownerList">
            <option value=""></option>
            <?php foreach ($owners as $owner){ ?>
                <option value="<?php echo $owner->getId();?>"><?php echo $owner->getLastname(); ?><?php echo(" "); ?><?php echo($owner->getFirstname()); ?></option>
            <?php } ?>
        </select>
    </div>
    <br>
    <div>
        <h4 id="inscrire">Vous inscriver actuellement un profil de type : Particulier</h4>
    </div>
    <br>
    <div class="">
        <h3>Identité du Client :</h3>
        <input type="text" name="lastnameOwner" id="lastnameOwner" placeholder="Nom du client" maxlength="100"> -
        <input type="text" name="firstnameOwner" id="firstnameOwner" placeholder="Prénom du client" maxlength="100">
    </div>
<br>
<div class="form-check-inline" id="checkGender">
    <label class="form-check-label">
        <input type="radio" class="form-check-input" id="Male" name="gender" value="Male" checked> Homme
    </label>
    <label class="form-check-label">
        <input type="radio" class="form-check-input" id="Female" name="gender" value="Female"> Femme
    </label>
</div>
    <h3 id="partie">Partie Particulier :</h3>

        <input type="text" id="addressCityOwner" name="addressCityOwner" placeholder="Ville" maxlength="100">
        <input type="text" id="addressStreetOwner" name="addressStreetOwner" placeholder="Rue" maxlength="100">
        <input type="text" id="postalCodeOwner" name="postalCodeOwner" placeholder="Code Postal" maxlength="15">

        <input type="hidden" id="socialHeadquarters" name="socialHeadquarters" placeholder="Siège sociale" maxlength="100">
        <input type="hidden" id="socialReson" name="socialReson" placeholder="Raison sociale" maxlength="100">
        <input type="hidden" id="socialDenomination" name="socialDenomination" placeholder="Dénomination sociale" maxlength="100">
    <div>
        <h3>Moyens de contacts :</h3>
        <input type="text" name="phoneOwner" id="phoneOwner" placeholder="Téléphone" maxlength="20"> -
        <input type="text" name="mailOwner" id="mailOwner" placeholder="Email" maxlength="100">
        <br>
        <br>
        <input type="text" name="facebook" id="facebook" placeholder="Facebook (optionel)" maxlength="100"> -
        <input type="text" name="twitter" id="twitter" placeholder="Twitter (optionel)" maxlength="100">
        <br>
        <br>
    </div>

<?php

$compteur = 1;

foreach ($owners as $owner){ ?>

    <input type="hidden" id="idFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getId()); ?>" disabled>
    <input type="hidden" id="firstnameFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getFirstname()); ?>" disabled>
    <input type="hidden" id="lastnameFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getLastname()); ?>" disabled>
    <input type="hidden" id="socialHeadquartersFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getSocialHeadquarters()); ?>" disabled>
    <input type="hidden" id="socialDenominationFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getSocialDenomination()); ?>" disabled>
    <input type="hidden" id="socialReasonFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getSocialReson()); ?>" disabled>
    <input type="hidden" id="phoneOwnerFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getPhone()); ?>" disabled>
    <input type="hidden" id="mailOwnerFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getMail()); ?>" disabled>
    <input type="hidden" id="addressCityFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getAddressCity()); ?>" disabled>
    <input type="hidden" id="addressStreetFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getAddressStreet()); ?>" disabled>
    <input type="hidden" id="postalCodeFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getPostalCode()); ?>" disabled>
    <input type="hidden" id="twitterFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getTwitter()); ?>" disabled>
    <input type="hidden" id="facebookFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getFacebook()); ?>" disabled>
    <input type="hidden" id="genderFromBdd<?php echo($owner->getId()); ?>" value="<?php echo($owner->getGender()); ?>" disabled>

<?php
$compteur++;
}
?>
