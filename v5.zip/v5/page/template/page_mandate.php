<?php ?>
<script>


</script>

<div class="">
    <input class="" placeholder="Nom du mandat" type="hidden" name="mandateName" maxlength="5">
    <br>
    <div class="form-check">
        <label class="form-check-label" for="mandatSimple">
            <input type="radio" class="form-check-input" id="mandatSimple" name="typeMandate_id" value="2" checked> Mandat simple
        </label>
    </div>
    <div class="form-check">
        <label class="form-check-label" for="mandatExclusif">
            <input type="radio" class="form-check-input" id="mandatExclusif" name="typeMandate_id" value="1"> Mandat Exclusif
        </label>
    </div>
    <div class="">

    </div>
    <h3>Agence (pré-rempli) :</h3>
    <br>
    <div>
        <input class="" type="text" name="agencyName" value="<?php echo(Config::NOM_AGENCE); ?>" disabled> -
        <input class="" type="hidden" name="agencyName" value="<?php echo(Config::NOM_AGENCE); ?>" >
        <input class="" type="text" name="nomConsultant" value="<?php echo($consultant->getFirstname());  ?>" disabled>
        <input class="" type="hidden"  value="<?php echo($consultant->getFirstname());  ?>" >
    </div>
    <br>
    <div>
        <input class="" type="text" name="agencyPhone" value="<?php echo(Config::TEL_AGENCE); ?>" disabled> -
        <input class="" type="hidden" name="agencyPhone" value="<?php echo(Config::TEL_AGENCE); ?>" >
        <input class="" type="text" name="telConsultant" value="<?php echo($consultant->getPhone()); ?>" disabled>
        <input class="" type="hidden" value="<?php echo($consultant->getPhone()); ?>" >
    </div>
    <br>
    <div>
        <input class="" type="text" name="addressCityAgency" value="<?php echo(Config::ADDR_AGENCE); ?>" disabled> -
        <input class="" type="hidden" name="addressCityAgency" value="<?php echo(Config::ADDR_AGENCE); ?>" >
        <input class="" type="text" name="postalCodeAgency" value="<?php echo(Config::CP_AGENCE); ?>" disabled>
        <input class="" type="hidden" name="postalCodeAgency" value="<?php echo(Config::CP_AGENCE); ?>" >

    </div>
    <br>
    <div>
        <input class="" type="text" name="addressStreetAgency" value="<?php echo(Config::ADDR_AGENCE_STREET); ?>" disabled>
        <input class="" type="hidden" name="addressStreetAgency" value="<?php echo(Config::ADDR_AGENCE_STREET); ?>">
    </div>
    <br>
    <div>
        Titre de propriété : <a href="#">Inserez ici</a>
    </div>
    <br>
    <div>
        <input type="number" name="propertyPrice" id="prixBien" placeholder="Prix du bien" style="-moz-appearance: textfield;">
    </div>
    <br>
    <div class="btn-group">
        <button type="button" class="btn btn-primary">Aperçu</button>
    </div>
</div>

