<?php include('../page/template/header.php') ?>

<script>
    function checkInformations() {

        if (document.getElementById("typeMandate").value === document.getElementById("mandatSimple").value) {
            document.getElementById("mandatSimple").checked = true;
        } else {
            document.getElementById("mandatExclusif").checked = true;
        }

        if (document.getElementById("sexe").value === document.getElementById("homme").value) {
            document.getElementById("homme").checked = true;
        } else {
            document.getElementById("femme").checked = true;
        }

        if (document.getElementById("addressCityOwner").value != "" || document.getElementById("addressStreetOwner").value != "" || document.getElementById("postalCodeOwner").value != "") {
            document.getElementById("particulier").checked = true;
            particulierChecked();
        } else if (document.getElementById("socialHeadquarters").value != "" || document.getElementById("socialReson").value != "" || document.getElementById("socialDenomination").value != "") {
            document.getElementById("entreprise").checked = true;
            entrepriseChecked();
        } else {
            document.getElementById("particulier").checked = true;
        }

        if (document.getElementById("prixBien").value == 0) {
            document.getElementById("prixBien").value = null;
        }

        if (document.getElementById("propertyGround").value == 0) {
            document.getElementById("propertyGround").value = null;
        }
    }

    function checkInformationUpdate() {

        if (document.getElementById("prixBien").value === '') {
            document.getElementById("prixBien").value = 0;
        }

        if (document.getElementById("propertyGround").value === '') {
            document.getElementById("propertyGround").value = 0;
        }

        if (document.getElementById("agencyFee").value === '') {
            document.getElementById("agencyFee").value = 0;
        }

    }

    function publishButton(){
        var inputMandate = false;
        var inputOwner = false;
        var inputInformation = false;


        inputMandate = checkMandateForm();
        inputOwner = checkOwnerForm();
        inputInformation = checkHouseInformationForm();

        if(inputMandate && inputOwner && inputInformation){
            document.getElementById("buttonPublish").disabled = false;
        }
        else{
            document.getElementById("buttonPublish").disabled = true;
        }

    }

</script>
<form method="post" action="?route=property&action=GroundUpdateClick">
    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#mandat">Mandat</a></li>
        <li class=""><a data-toggle="tab" href="#proprietaire">Informations sur le propriétaire</a></li>
        <li><a data-toggle="tab" href="#information">Informations sur le terrain</a></li>
        <li><input type="submit" value="Enregistrer" onclick="checkInformationUpdate()" class="btn btn-primary"></li>
        <li><button type="button" id="buttonPublish" class="btn btn-danger" disabled>Publier</button></li>

    </ul>

    <div class="tab-content">
        <div id="mandat" class="tab-pane fade in active" style="margin-left: 1%">
            <?php include('../page/updateProperty/page_updateMandate.php'); ?>
        </div>
        <div id="proprietaire" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/updateProperty/page_updateOwner.php'); ?>
        </div>
        <div id="information" class="tab-pane fade" style="margin-left: 1%">
            <?php include ('../page/updateProperty/ground/page_updateInformation.php'); ?>
        </div>
    </div>

</form>
</body>
</html>