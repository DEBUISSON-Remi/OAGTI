<script>
    function checkAdditionalInformationHouse() {


        const taxeFonciere = document.getElementById("taxeFonciere").value;
        const taxeHabitation = document.getElementById("taxeHabitation").value;
        const charges = document.getElementById("charges").value;
        const sanitation_id = document.getElementById("sanitation_id").value;
        const heatingMethod_id = document.getElementById("heatingMethod_id").value;
        const energy_id = document.getElementById("energy_id").value;
        const hotWater_id = document.getElementById("hotWater_id").value;
        let inputList = [taxeFonciere,taxeHabitation,charges,sanitation_id,heatingMethod_id,energy_id,hotWater_id];
        for(let oneInput of inputList){
            if (oneInput !== ''){

            }
            else{
                return false;
            }
        }
        return true;
    }
</script>
<div>
    <input type="hidden" name="idExpenses" value="<?php echo($information->getExpenses()->getId()); ?>">
    <h3>Informations complémentaire sur la maison</h3>
    <br>
    <h3>Charges :</h3>
    <div class="">
        <input type="number" id="taxeFonciere" name="fonciere" placeholder="Fonciere" style="-moz-appearance: textfield;" value="<?php echo($information->getExpenses()->getFonciere()); ?>" maxlength="11"> -
        <input type="number" id="taxeHabitation" name="livingExpenses" placeholder="Habitation" style="-moz-appearance: textfield;" value="<?php echo($information->getExpenses()->getLivingExpenses()); ?>" maxlength="11"> -
        <input type="number" id="charges" name="expenses" placeholder="Charges" style="-moz-appearance: textfield;" value="<?php echo($information->getExpenses()->getExpenses()); ?>" maxlength="11">
    </div>
    <br>
    <div>
        <label>Assainissement :</label>
        <select name="sanitation_id" size="1" id="sanitation_id">
            <option value="" selected>Séléctionnez...</option>
            <?php $infoSanitation = $information->getSanitation();
            foreach ($sanitations as $sanitation){
                $selected = "";
                if($infoSanitation->getId() == $sanitation->getId()){
                    $selected = "selected";
                }
                echo'<option value="'.$sanitation->getId().'" '.$selected.'>'.$sanitation->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select>
        <input type="text" name="newSanitation" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
    </div>
    <br>
    <div>
        <h3>Chauffage :</h3>

        <label>Mode de chauffage :</label>
        <select name="heatingMethod_id" size="1" id="heatingMethod_id">
            <option value="" selected>Séléctionnez...</option>
            <?php
            $infoHeatingMethod = $information->getHeatingMethod();
            foreach ($heatingMethods as $heatingMethod){
                $selected = "";
                if($infoHeatingMethod->getId() == $heatingMethod->getId()){
                    $selected = "selected";
                }
                echo'<option value="'.$heatingMethod->getId().'"'.$selected.'>'.$heatingMethod->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select>
        <input type="text" name="newHeatingMethod" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
        <br><br>
        <label>Energie :</label>
        <select name="energy_id" size="1" id="energy_id">
            <option value="" selected>Séléctionnez...</option>
            <?php
            $infoEnergy = $information->getEnergy();
            foreach ($energys as $energy){
                $selected = "";
                if($infoEnergy->getId() == $energy->getId()){
                    $selected = "selected";
                }
                echo'<option value="'.$energy->getId().'"'.$selected.'>'.$energy->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select>
        <input type="text" name="newEnergy" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
    </div>
    <br>
    <div>
        <h3>Eau chaude :</h3>
        <label>Energie :</label>
        <select name="hotWater_id" size="1" id="hotWater_id">
            <option value="" selected>Séléctionnez...</option>
            <?php
            $infoHotWater = $information->getHotWater();
            foreach ($hotWaters as $hotWater){
                $selected = "";
                if($infoHotWater->getId() == $hotWater->getId()){
                    $selected = "selected";
                }
                echo'<option value="'.$hotWater->getId().'"'.$selected.'>'.$hotWater->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select>
        <input type="text" name="newHotWater" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
    </div>
    <br>
</div>








