<?php ?>


<script>

    function changePiece() {

        var nbRoom = document.getElementById("nbRoom").value;
        var div = document.getElementById("info");
        var placement = document.getElementById("div-inserrer");

        for(i=0; i<101; i++){
            var libelle = document.getElementById("libelleRoom"+i);
            var surface = document.getElementById("surfaceRoom"+i);
            var ligne1 = document.getElementById("firstLigne"+i);
            var ligne2 = document.getElementById("secondLigne"+i);
            var hiddenLibelle = document.getElementById("libelle"+i);
            var hiddenSurface = document.getElementById("surface"+i);
            if (document.getElementById("libelleRoom"+i)){
                if (hiddenLibelle){
                    hiddenLibelle.value = libelle.value;
                    hiddenSurface.value = surface.value;
                    libelle.parentNode.removeChild(libelle);
                    surface.parentNode.removeChild(surface);
                    ligne1.parentNode.removeChild(ligne1);
                    ligne2.parentNode.removeChild(ligne2);
                }
                else {
                    inputHidden =document.createElement("input");
                    inputHidden.type = "hidden";
                    inputHidden.id = "libelle"+i;
                    inputHidden.value = libelle.value;
                    inputHidden.disabled = "disabled";

                    inputSurfaceHidden = document.createElement("input");
                    inputSurfaceHidden.type = "hidden";
                    inputSurfaceHidden.id = "surface"+i;
                    inputSurfaceHidden.value = surface.value;
                    inputSurfaceHidden.disabled = "disabled";

                    document.body.appendChild(inputSurfaceHidden);
                    document.body.appendChild(inputHidden);

                    hiddenLibelle = document.getElementById("libelle"+i);
                    hiddenSurface = document.getElementById("surface"+i);

                    hiddenLibelle.value = libelle.value;
                    hiddenSurface.value = surface.value;
                    libelle.parentNode.removeChild(libelle);
                    surface.parentNode.removeChild(surface);
                    ligne1.parentNode.removeChild(ligne1);
                    ligne2.parentNode.removeChild(ligne2);
                }

            }
            else {

            }

        }

        for(i=0; i<nbRoom; i++){

            if(document.getElementById("libelle"+i)){
                var libelleValue = document.getElementById("libelle"+i).value;
                var surfaceValue = document.getElementById("surface"+i).value;
            }
            else {
                libelleValue = null;
                surfaceValue = null;
            }



            div = document.createElement("div");
            div.class = "row";
            div.id = "info";

            input =document.createElement("input");
            input.placeholder = "Libelle de la piece";
            input.type = "text";
            input.name = "libelleRoom[]";
            input.id = "libelleRoom"+i;
            input.style.marginLeft = "1%";
            input.maxLength = "30";
            input.value = libelleValue;

            inputSurface = document.createElement("input");
            inputSurface.placeholder = "Surface de la piece";
            inputSurface.type = "text";
            inputSurface.name = "surfaceRoom[]";
            inputSurface.id = "surfaceRoom"+i;
            inputSurface.style.marginLeft = "1%";
            inputSurface.maxLength = "2";
            inputSurface.value = surfaceValue;

            sautLigne = document.createElement("br");
            sautLigne.id = "firstLigne"+i;
            sautLigne2 = document.createElement("br");
            sautLigne2.id = "secondLigne"+i;

            placement.append(div);
            div.appendChild(sautLigne);
            div.appendChild(input);
            div.appendChild(inputSurface);
            div.appendChild(sautLigne2);

        }

    }

    function checkRoomForm() {


        if(document.getElementById("nbRoom").value !== ''){
            return true;
        }
        else{
            return false;
        }

    }
</script>
<div>
    <h3>Nombre de pièces :</h3>
    <div class="row" style="margin-left: 1%" id="div-inserrer">
        <input type="number" name="nbRoom" id="nbRoom" placeholder="Nombre de pièces" style="-moz-appearance: textfield" maxlength="2" max="99" value="<?php echo($information->getProperty()->getNbRoom()); ?>"> -
        <button onclick="changePiece()" class="btn btn-primary" type="button">Valider</button>
        <br><br>
        <?php
        if($rooms != null){
        $increment = 0;
        foreach ($rooms as $room){
            $idLibelle = "libelle".trim($increment);
            $idSurface = "surface".trim($increment);
            ?>
            <input type="hidden" id="<?php echo $idLibelle ?>" value="<?php echo ($room->getLibelle()); ?>" disabled>
            <input type="hidden" id="<?php echo $idSurface ?>" value="<?php echo ($room->getSurface()); ?>" disabled>
            <?php
            $increment++;
        }
        } ?>

    </div>
</div>
