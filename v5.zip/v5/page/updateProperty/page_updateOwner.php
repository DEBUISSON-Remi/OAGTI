<?php ?>
<script>
    function entrepriseChecked() {
        document.getElementById("socialHeadquarters").type = "text";
        document.getElementById("socialReson").type = "text";
        document.getElementById("socialDenomination").type = "text";

        document.getElementById("addressCityOwner").type = "hidden";
        document.getElementById("addressCityOwner").value = "";
        document.getElementById("addressStreetOwner").type = "hidden";
        document.getElementById("addressStreetOwner").value = "";
        document.getElementById("postalCodeOwner").type = "hidden";
        document.getElementById("postalCodeOwner").value = "";

        document.getElementById("inscrire").innerHTML = "Vous modifiez actuellement un profil de type : Entreprise";
        document.getElementById("partie").innerHTML = "Partie Entreprise :";
    }


    function particulierChecked() {

        document.getElementById("socialHeadquarters").type = "hidden";
        document.getElementById("socialHeadquarters").value = "";
        document.getElementById("socialReson").type = "hidden";
        document.getElementById("socialReson").value = "";
        document.getElementById("socialDenomination").type = "hidden";
        document.getElementById("socialDenomination").value = "";


        document.getElementById("addressCityOwner").type = "text";
        document.getElementById("addressStreetOwner").type = "text";
        document.getElementById("postalCodeOwner").type = "text";

        document.getElementById("inscrire").innerHTML = "Vous modifiez actuellement un profil de type : Particulier";
        document.getElementById("partie").innerHTML = "Partie Particulier :";
    }

    function checkOwnerForm(){


        const lastname = document.getElementById("lastnameOwner").value;
        const firstname = document.getElementById("firstnameOwner").value;
        const phone = document.getElementById("phoneOwner").value;
        const mail = document.getElementById("mailOwner").value;
        const addressCity = document.getElementById("addressCityOwner").value;
        const addressStreet = document.getElementById("addressStreetOwner").value;
        const postalCode = document.getElementById("postalCodeOwner").value;
        const denomination = document.getElementById("socialDenomination").value;
        const headquarter = document.getElementById("socialHeadquarters").value;
        const reson = document.getElementById("socialReson").value;



        if(document.getElementById("particulier").checked){
            let inputList =[lastname,firstname,phone,mail,addressStreet,addressCity,postalCode];
            for(let oneInput of inputList){
                if (oneInput !== ''){

                }
                else{
                    return true;
                }
            }

        }
        else{
            let inputList =[lastname,firstname,phone,mail,denomination,headquarter,reson];
            for(let oneInput of inputList){
                if (oneInput !== ''){

                }
                else{
                    return false;
                }
            }
        }
        return true;
    }

</script>

<input type="hidden" name="idOwner" value="<?php echo($information->getOwner()->getId()); ?>">
    <br>
    <div class="form-check-inline">
        <label class="form-check-label">
            <input type="radio" id="particulier" name="type" checked onclick="particulierChecked()"> Particulier
        </label>
        <label class="form-check-label">
            <input type="radio" id="entreprise" name="type" onclick="entrepriseChecked()"> Entreprise
        </label>
    </div>
    <br>
    <div>
        <h4 id="inscrire">Vous modifiez actuellement un profil de type : Particulier</h4>
    </div>
    <br>
    <div class="">
        <h3>Identité du Client :</h3>
        <input type="text" name="lastnameOwner" id="lastnameOwner" placeholder="Nom du client" onchange="changeNomOwner()" value="<?php echo($information->getOwner()->getLastname()); ?>" maxlength="100"> -
        <input type="text" name="firstnameOwner" id="firstnameOwner" placeholder="Prénom du client" onchange="changePrenomOwner()" value="<?php echo($information->getOwner()->getFirstname()); ?>" maxlength="100">
    </div>
<br>
<div class="form-check-inline">
    <label class="form-check-label" for="homme">
        <input type="radio" class="form-check-input" id="homme" name="gender" value="Homme" > Homme
    </label>
    <label class="form-check-label" for="femme">
        <input type="radio" class="form-check-input" id="femme" name="gender" value="Femme"> Femme
    </label>
</div>

    <h3 id="partie">Partie Particulier :</h3>

        <input type="text" id="addressCityOwner" name="addressCityOwner" placeholder="Ville" value="<?php echo($information->getOwner()->getAddressCity()); ?>" maxlength="100">
        <input type="text" id="addressStreetOwner" name="addressStreetOwner" placeholder="Rue" value="<?php echo($information->getOwner()->getAddressStreet()); ?>" maxlength="100">
        <input type="text" id="postalCodeOwner" name="postalCodeOwner" placeholder="Code Postal" value="<?php echo($information->getOwner()->getPostalCode()); ?>" maxlength="15">

        <input type="hidden" id="socialHeadquarters" name="socialHeadquarters" placeholder="Siège sociale" value="<?php echo($information->getOwner()->getSocialHeadquarters()); ?>" maxlength="100">
        <input type="hidden" id="socialReson" name="socialReson" placeholder="Raison sociale" value="<?php echo($information->getOwner()->getSocialReson()); ?>" maxlength="100">
        <input type="hidden" id="socialDenomination" name="socialDenomination" placeholder="Dénomination sociale" value="<?php echo($information->getOwner()->getSocialDenomination()); ?>" maxlength="100">
    <div>
        <h3>Moyens de contacts :</h3>
        <input type="text" name="phoneOwner" id="phoneOwner" placeholder="Téléphone" value="<?php echo($information->getOwner()->getPhone()); ?>" maxlength="20"> -
        <input type="text" name="mailOwner" id="mailOwner" placeholder="Email" value="<?php echo($information->getOwner()->getMail()); ?>" maxlength="100">
        <br>
        <br>
        <input type="text" name="facebook" placeholder="Facebook (optionel)" value="<?php echo($information->getOwner()->getFacebook()); ?>" maxlength="100"> -
        <input type="text" name="twitter" placeholder="Twitter (optionel)" value="<?php echo($information->getOwner()->getTwitter()); ?>" maxlength="100">
        <br>
        <br>
    </div>
