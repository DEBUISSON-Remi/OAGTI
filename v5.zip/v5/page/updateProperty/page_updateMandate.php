<?php ?>
<script>
    function checkMandateForm(){

        if(document.getElementById("prixBien").value !== ''){
            return true;
        }
        else{
            return false;
        }

    }


</script>

<input type="hidden" value="<?php echo($information->getMandate()->getId()); ?>" name="idMandate">
<div class="">
    <br>
    <h3>Numéros de mandat :</h3>
    <input class="" placeholder="Nom du mandat" type="hidden" name="mandateName" value="<?php echo($information->getMandate()->getMandateName()); ?>">
    <input class="" type="text" name="mandateName" value="<?php echo($information->getMandate()->getMandateName()); ?>" disabled>
    <br><br>
    <div class="form-check">
        <label class="form-check-label" for="mandatSimple">
            <input type="radio" class="form-check-input" id="mandatSimple" name="typeMandate_id" value="2"> Mandat simple
        </label>
    </div>
    <div class="form-check">
        <label class="form-check-label" for="mandatExclusif">
            <input type="radio" class="form-check-input" id="mandatExclusif" name="typeMandate_id" value="1"> Mandat Exclusif
        </label>
    </div>
    <br>
    <h3>Agence (pré-rempli) :</h3>
    <br>
    <div>
        <input class="" type="text" name="agencyName" value="<?php echo($information->getMandate()->getAgencyName()); ?>" disabled> -
        <input class="" type="hidden" name="agencyName" value="<?php echo($information->getMandate()->getAgencyName()); ?>" >
        <input class="" type="text" name="nomConsultant" value="<?php echo($information->getConsultant()->getLastname()); ?>" disabled>
        <input class="" type="hidden"  value="<?php echo($information->getConsultant()->getLastname()); ?>" >
    </div>
    <br>
    <div>
        <input class="" type="text" name="agencyPhone" value="<?php echo($information->getMandate()->getAgencyPhone()); ?>" disabled> -
        <input class="" type="hidden" name="agencyPhone" value="<?php echo($information->getMandate()->getAgencyPhone()); ?>" >
        <input class="" type="text" name="telConsultant" value="<?php echo($information->getConsultant()->getPhone()); ?>" disabled>
        <input class="" type="hidden" value="<?php echo($information->getConsultant()->getPhone()); ?>" >
    </div>
    <br>
    <div>
        <input class="" type="text" name="addressCityAgency" value="<?php echo($information->getMandate()->getAddressCityAgency()); ?>" disabled> -
        <input class="" type="hidden" name="addressCityAgency" value="<?php echo($information->getMandate()->getAddressCityAgency()); ?>" >
        <input class="" type="text" name="postalCodeAgency" value="<?php echo($information->getMandate()->getPostalCodeAgency()); ?>" disabled>
        <input class="" type="hidden" name="postalCodeAgency" value="<?php echo($information->getMandate()->getPostalCodeAgency()); ?>" >

    </div>
    <br>
    <div>
        <input class="" type="text" name="addressStreetAgency" value="<?php echo($information->getMandate()->getAddressStreetAgency()); ?>" disabled>
        <input class="" type="hidden" name="addressStreetAgency" value="<?php echo($information->getMandate()->getAddressStreetAgency()); ?>">
    </div>
    <br>
    <div>
        Titre de propriété : <a href="#">Inserez ici</a>
    </div>
    <br>
    <div>
        <input type="number" name="propertyPrice" id="prixBien" placeholder="Prix du bien" style="-moz-appearance: textfield;" value="<?php echo($information->getMandate()->getPropertyPrice()); ?>">
    </div>
    <br>
    <div class="btn-group">
        <button type="button" class="btn btn-primary">Aperçu</button>
    </div>
    <input type="hidden" value="<?php echo($information->getTypeMandate()->getId()); ?>" id="typeMandate">
    <input type="hidden" value="<?php echo($information->getOwner()->getGender()); ?>" id="sexe">
</div>

