<?php ?>
<script>
    function checkHouseInformationForm() {
        const propertyGround = document.getElementById("propertyGround").value;
        const comment = document.getElementById("comment").value;
        const addressStreetProperty = document.getElementById("addressStreetProperty").value;
        const addressCityProperty = document.getElementById("addressCityProperty").value;
        const postalCodeProperty = document.getElementById("postalCodeProperty").value;
        const locality = document.getElementById("locality").value;
        let inputList = [propertyGround,comment,addressStreetProperty,addressCityProperty,postalCodeProperty,locality];
        for(let oneInput of inputList){
            if (oneInput !== ''){

            }
            else{
                return false;
            }
        }
        return true;
    }
</script>
<input type="hidden" value="<?php echo($information->getProperty()->getId()) ?>" name="idProperty">
<input type="text" value="<?php echo($information->getTypeProperty()->getLibelle()) ?>">
<h3>Commentaires sur le bien :</h3>
<input type="text" name="comment" id="comment" placeholder="Décriver le bien en quelques lignes :" style="width: 800px" value="<?php echo($information->getProperty()->getComment()) ?>" maxlength="255">
<br>
    <div>
        <h3>Surface de terrain :</h3>
        <input type="number" name="propertyGround" id="propertyGround" placeholder="Insérez la surface du terrain en m²" style="width: 250px;  -moz-appearance: textfield;" value="<?php echo($information->getProperty()->getPropertyGround()) ?>" maxlength="5">
        <input type="hidden" name="propertySurface" value="<?php echo($information->getProperty()->getPropertySurface()) ?>" >
    </div>

    <div >
        <h3>Adresse complète :</h3>
        <input type="text" name="addressStreetProperty" id="addressStreetProperty" placeholder="Rue" value="<?php echo($information->getProperty()->getAddressStreet()) ?>" maxlength="200"> -
        <input type="text" name="addressCityProperty" id="addressCityProperty" placeholder="Ville" value="<?php echo($information->getProperty()->getAddressCity()) ?>" maxlength="50"> -
        <input type="text" name="postalCodeProperty" id="postalCodeProperty" placeholder="Code Postal" value="<?php echo($information->getProperty()->getPostalCode()) ?>" maxlength="10"> -
        <input type="text" name="locality" id="locality" placeholder="Lieu-dit" value="<?php echo($information->getProperty()->getLocality()) ?>" maxlength="50">
    </div>
    <div>

        <input type="hidden" name="ISPPrice" id="ISPPrice" value="<?php echo($information->getProperty()->getISPPrice()) ?>">
    </div>
    <div>

        <input type="hidden" name="agencyFee" value="<?php echo($information->getProperty()->getAgencyFee()) ?>">
    </div>
    <div >
        <h3>Rénumération Consultant :</h3>
        <input type="text" name="commisionRate" value="<?php echo $information->getConsultant()->getCommissionRate();?> %" disabled>
    </div>


    <input type="hidden" value="<?php echo($information->getProperty()->getNbRoom()) ?>" name="nbRoom">
    <input type="hidden" value="<?php echo($information->getProperty()->getConstructionDate()) ?>" name="constructionDate">
    <input type="hidden" value="<?php echo($information->getProperty()->getBuildingNumber()) ?>" name="buildingNumber">
    <input type="hidden" value="<?php echo($information->getExpenses()->getFonciere()) ?>" name="fonciere">
    <input type="hidden" value="<?php echo($information->getExpenses()->getLivingExpenses()) ?>" name="livingExpenses">
    <input type="hidden" value="<?php echo($information->getExpenses()->getExpenses()) ?>" name="expenses">
    <input type="hidden" value="<?php echo($information->getSanitation()->getId()) ?>" name="sanitation_id">
    <input type="hidden" value="<?php echo($information->getHeatingMethod()->getId()) ?>" name="heatingMethod_id">
    <input type="hidden" value="<?php echo($information->getEnergy()->getId()) ?>" name="energy_id">
    <input type="hidden" value="<?php echo($information->getHotWater()->getId()) ?>" name="hotWater_id">
