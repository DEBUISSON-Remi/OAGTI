<?php ?>
<script>
    function checkHouseInformationForm() {
        const constructionDate = document.getElementById("constructionDate").value;
        const propertySurface = document.getElementById("propertySurface").value;
        const comment = document.getElementById("comment").value;
        const addressStreetProperty = document.getElementById("addressStreetProperty").value;
        const addressCityProperty = document.getElementById("addressCityProperty").value;
        const postalCodeProperty = document.getElementById("postalCodeProperty").value;
        const locality = document.getElementById("locality").value;
        const buildingNumber = document.getElementById("buildingNumber").value;
        let inputList = [constructionDate,propertySurface,comment,addressStreetProperty,addressCityProperty,postalCodeProperty,locality,buildingNumber];
        for(let oneInput of inputList){
            if (oneInput !== ''){

            }
            else{
                return false;
            }
        }
        return true;
    }
</script>
<input type="hidden" value="<?php echo($information->getProperty()->getId()) ?>" name="idProperty">
    <div>
        <h3>Type :</h3>
        <input type="text" value="<?php echo($information->getTypeProperty()->getLibelle()) ?>" disabled>
        <input type="hidden" value="<?php echo($information->getTypeProperty()->getLibelle()) ?>">
    </div>
    <br>
    <div>
        <h3>Date de construction :</h3>
        <input type="date" name="constructionDate" id="constructionDate" placeholder="Date de construction" value="<?php echo($information->getProperty()->getConstructionDate()) ?>">
    </div>
    <div>
        <h3>Commentaires :</h3>
        <input type="text" name="comment" id="comment" placeholder="Décriver le bien en quelques lignes :" style="width: 800px" value="<?php echo($information->getProperty()->getComment()) ?>" maxlength="255">
    </div>
    <br>
    <div>
        <h3>Surface :</h3>
        <input type="number" name="propertySurface" id="propertySurface" placeholder="Surface du bien en m2" style="-moz-appearance: textfield;" value="<?php echo($information->getProperty()->getPropertySurface()) ?>" maxlength="5">
        <input type="hidden" name="propertyGround" id="propertyGround" value="<?php echo($information->getProperty()->getPropertyGround()) ?>" maxlength="5">
    </div>
    <br>
    <div>
        <h3>Adresse :</h3>
        <input type="text" name="addressStreetProperty" id="addressStreetProperty" placeholder="Rue" value="<?php echo($information->getProperty()->getAddressStreet()) ?>" maxlength="200"> -
        <input type="text" name="addressCityProperty"  id="addressCityProperty" placeholder="Ville" value="<?php echo($information->getProperty()->getAddressCity()) ?>" maxlength="50"> -
        <input type="text" name="postalCodeProperty" id="postalCodeProperty"   placeholder="Code Postal" value="<?php echo($information->getProperty()->getPostalCode()) ?>" maxlength="10"> -
        <input type="text" name="locality" id="locality" placeholder="Lieu-dit" value="<?php echo($information->getProperty()->getLocality()) ?>" maxlength="50"> -
        <input type="number" name="buildingNumber" id="buildingNumber" placeholder="Détails de situation (n° bâtiment, n° appartement, autre)" style="-moz-appearance: textfield;" value="<?php echo($information->getProperty()->getBuildingNumber()) ?>" maxlength="4">
    </div>
    <br>
    <div>
        <h3>Prix FAI en € :</h3>
        <input type="number" name="ISPPrice" id="ISPPrice" placeholder="Calculé à partir des informations fourni dans le contrat mandataire" style="-moz-appearance: textfield;" value="<?php echo($information->getProperty()->getISPPrice()) ?>">
    </div>
    <br>
    <div>
        <h3>Honoraires de l'agence en € :</h3>
        <input type="number" name="agencyFee" id="agencyFee" placeholder="Fonction du pourcentage pratiqué par globAgence" style="-moz-appearance: textfield;" value="<?php echo($information->getProperty()->getAgencyFee()) ?>">
    </div>
    <br>
    <div>
        <h3>Rémunération du consultant : </h3>
        <input type="text" name="commitionRate" value="<?php echo($information->getConsultant()->getCommissionRate());?> %" disabled >
    </div>
    <br>

