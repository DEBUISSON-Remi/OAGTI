<?php  include('../page/template/header.php'); ?>

<script>
    function checkInformations() {

        if(document.getElementById("typeMandate").value === document.getElementById("mandatSimple").value){
            document.getElementById("mandatSimple").checked = true;
        }
        else{
            document.getElementById("mandatExclusif").checked = true;
        }

        if(document.getElementById("sexe").value === document.getElementById("homme").value){
            document.getElementById("homme").checked = true;
        }
        else{
            document.getElementById("femme").checked = true;
        }

        if(document.getElementById("addressCityOwner").value != "" || document.getElementById("addressStreetOwner").value != "" || document.getElementById("postalCodeOwner").value != ""){
            document.getElementById("particulier").checked = true;
            particulierChecked();
        }
        else if(document.getElementById("socialHeadquarters").value != "" || document.getElementById("socialReson").value != "" || document.getElementById("socialDenomination").value != ""){
            document.getElementById("entreprise").checked = true;
            entrepriseChecked();
        }
        else{
            document.getElementById("particulier").checked = true;
        }

        if(document.getElementById("prixBien").value == 0){
            document.getElementById("prixBien").value = null;
        }

        if(document.getElementById("propertySurface").value == 0){
            document.getElementById("propertySurface").value = null;
        }


        if(document.getElementById("buildingNumber").value == 0){
            document.getElementById("buildingNumber").value = null;
        }

        if(document.getElementById("ISPPrice").value == 0){
            document.getElementById("ISPPrice").value = null;
        }

        if(document.getElementById("agencyFee").value == 0){
            document.getElementById("agencyFee").value = null;
        }

        if(document.getElementById("taxeFonciere").value == 0){
            document.getElementById("taxeFonciere").value = null;
        }

        if(document.getElementById("taxeHabitation").value == 0){
            document.getElementById("taxeHabitation").value = null;
        }

        if(document.getElementById("charges").value == 0){
            document.getElementById("charges").value = null;
        }

        if(document.getElementById("nbRoom").value == 0){
            document.getElementById("nbRoom").value = null;
        }

        var nbRoom = document.getElementById("nbRoom").value;
        var div = document.getElementById("info");
        var placement = document.getElementById("div-inserrer");

        for(i=0; i<nbRoom; i++){

            var libelleValue = document.getElementById("libelle"+i).value;
            var surfaceValue = document.getElementById("surface"+i).value;
            if (surfaceValue == 0){
                surfaceValue = null;
            }


            div = document.createElement("div");
            div.class = "row";
            div.id = "info";

            input =document.createElement("input");
            input.placeholder = "Libelle de la piece";
            input.type = "text";
            input.name = "libelleRoom[]";
            input.id = "libelleRoom"+i;
            input.style.marginLeft = "1%";
            input.maxLength = "30";
            input.value = libelleValue;

            inputSurface = document.createElement("input");
            inputSurface.placeholder = "Surface de la piece";
            inputSurface.type = "text";
            inputSurface.name = "surfaceRoom[]";
            inputSurface.id = "surfaceRoom"+i;
            inputSurface.style.marginLeft = "1%";
            inputSurface.maxLength = "2";
            inputSurface.value = surfaceValue;

            sautLigne = document.createElement("br");
            sautLigne.id = "firstLigne"+i;
            sautLigne2 = document.createElement("br");
            sautLigne2.id = "secondLigne"+i;

            placement.append(div);
            div.appendChild(sautLigne);
            div.appendChild(input);
            div.appendChild(inputSurface);
            div.appendChild(sautLigne2);

        }


    }

    function checkInformationUpdate() {
        if (document.getElementById("prixBien").value === '') {
            document.getElementById("prixBien").value = 0;
        }

        if (document.getElementById("nbRoom").value === '') {
            document.getElementById("nbRoom").value = 0;
        }

        if (document.getElementById("constructionDate").value === '') {
            document.getElementById("constructionDate").value = "0000-00-00";
        }

        if (document.getElementById("propertySurface").value === '') {
            document.getElementById("propertySurface").value = 0;
        }

        if (document.getElementById("buildingNumber").value === '') {
            document.getElementById("buildingNumber").value = 0;
        }

        if (document.getElementById("ISPPrice").value === '') {
            document.getElementById("ISPPrice").value = 0;
        }

        if (document.getElementById("agencyFee").value === '') {
            document.getElementById("agencyFee").value = 0;
        }

        if (document.getElementById("taxeFonciere").value === '') {
            document.getElementById("taxeFonciere").value = 0;
        }

        if (document.getElementById("taxeHabitation").value === '') {
            document.getElementById("taxeHabitation").value = 0;
        }

        if (document.getElementById("charges").value === '') {
            document.getElementById("charges").value = 0;
        }
    }

    function publishButton(){
        var inputMandate = false;
        var inputOwner = false;
        var inputInformation = false;
        var inputRoom = false;
        var inputAdditionalInformation = false;
        inputMandate = checkMandateForm();
        inputRoom = checkRoomForm();
        inputOwner = checkOwnerForm();
        inputInformation = checkHouseInformationForm();
        inputAdditionalInformation = checkAdditionalInformationHouse();



        if(inputMandate && inputRoom && inputOwner && inputInformation && inputAdditionalInformation){
            document.getElementById("buttonPublish").disabled = false;
        }
        else{
            document.getElementById("buttonPublish").disabled = true;
        }
    }
</script>
<form method="post" action="?route=property&action=PropertyUpdateClick">
    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#mandat">Mandat</a></li>
        <li class=""><a data-toggle="tab" href="#proprietaire">Informations sur le proprietaire</a></li>
        <li><a data-toggle="tab" href="#information">Informations sur le bien</a></li>
        <li><a data-toggle="tab" href="#room">Informations sur les pièces</a></li>
        <li><a data-toggle="tab" href="#information-complement">Informations complémentaires sur la maison</a></li>
        <li><input type="submit" value="Modifier" class="btn btn-primary" onclick="checkInformationUpdate()"></li>
        <li><button type="button" id="buttonPublish" class="btn btn-danger" disabled>Publier</button></li>
    </ul>

    <div class="tab-content">
        <div id="mandat" class="tab-pane fade in active" style="margin-left: 1%">
            <?php include('../page/updateProperty/page_updateMandate.php'); ?>
        </div>
        <div id="proprietaire" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/updateProperty/page_updateOwner.php'); ?>
        </div>
        <div id="information" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/updateProperty/apartment/page_updateInformation.php'); ?>
        </div>
        <div id="room" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/updateProperty/page_updateRoom.php'); ?>
        </div>
        <div id="information-complement" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/updateProperty/apartment/page_updateAdditionalInformation.php'); ?>
        </div>
    </div>

</form>

</body>
</html>