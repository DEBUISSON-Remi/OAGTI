<?php ?>

    <div>
        <h3>Type de bien :</h3>
        <input type="hidden" name="typeProperty_id" placeholder="Type de bien" value="3">
    </div>
    <br>
    <div>
        <h3>Date de construction :</h3>
        <input type="date" name="constructionDate" id="constructionDate" placeholder="yyyy/mm/dd" >
    </div>
    <br>
    <div>
        <h3>Commentaires sur le bien :</h3>
        <input type="text" name="comment" placeholder="Décriver le bien en quelques lignes :" style="width: 250px" maxlength="255">
    </div>
    <br>
    <div>
        <h3>Photos du bien :</h3>
    </div>
    <br>
    <div>
        <h3>Référence du bien qui est le numéro du mandat :</h3>
        <input type="text" name="mandateName" placeholder="Nombre unique à 5 chiffres (2 premiers correspondent au département, les 3 autres à un nombre aléatoire)" style="width: 700px">
    </div>
    <br>
    <div>
        <h3>Surface du biens :</h3>
        <input type="number" name="propertySurface" id="propertySurface" placeholder="Surface du bien en m2" style="-moz-appearance: textfield;" maxlength="5">
        <input type="hidden" name="propertyGround" value="0" maxlength="5">
    </div>
    <br>
    <div>
        <h3>Adresse du bien :</h3>
        <input type="text" name="addressStreetProperty" placeholder="Rue" maxlength="200"> -
        <input type="text" name="addressCityProperty " placeholder="Ville" maxlength="50"> -
        <input type="text" name="postalCodeProperty" placeholder="Code Postal" maxlength="10"> -
        <input type="text" name="locality" placeholder="Lieu-dit" maxlength="50"> -
        <input type="number" name="buildingNumber" id="buildingNumber" placeholder="Détails de situation (n° bâtiment, n° appartement, autre)" style="-moz-appearance: textfield;" maxlength="4">
    </div>
    <br>
    <div>
        <h3>Prix FAI en € :</h3>
        <input type="number" name="ISPPrice" id="ISPPrice" placeholder="Calculé à partir des informations fourni dans le contrat mandataire" style="width: 500px;-moz-appearance: textfield;" >
    </div>
    <br>
    <div>
        <h3>Honoraires de l'agence sur le bien en € :</h3>
        <input type="number" name="agencyFee" id="agencyFee" placeholder="Fonction du pourcentage pratiqué par globAgence" style="-moz-appearance: textfield;">
    </div>
    <br>
    <div>
        <h3>Rémunération du consultant sur le bien : </h3>
        <input type="text" name="commissionRate" value="<?php echo $consultant->getCommissionRate();?> %" disabled>
    </div>

