<?php
include 'template/header.php';

?>
<body>
<?php

if ($etatProperty == 0){
    ?>
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <a href="?route=dashboard"><button type="button" class="close" data-dismiss="modal">&times;</button></a>
                <h4 class="modal-title">Pas de bien </h4>
            </div>
        <div class="modal-body">
            <p>Ce client n'a actuellement pas de bien en sa possession </p>
    </div>
</body>
<?php
}
else {
?>

<div class="" style="margin-left: 1%; margin-right: 1%">


    <h2>Bien en cours d'enregistrement</h2>
    <table class="table">
        <thead class="" style="color:#fff;background-color:#343a40;border-color:#454d55">
        <tr>
            <th style="text-align: center">Bien</th>
            <th style="text-align: center">Rue</th>
            <th style="text-align: center">Ville</th>
            <th style="text-align: center">Code postal</th>
            <th style="text-align: center">Date de construction</th>
            <th style="text-align: center">Nombre de pièce</th>
            <th style="text-align: center">Commentaire du bien</th>
            <th style="text-align: center">Surface du bien</th>
            <th style="text-align: center">Surface de terrain</th>
            <th style="text-align: center">Photos</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($informations as $information){ ?>
            <tr style="text-align: center;">
                <td><?php echo $information->getTypeProperty()->getLibelle() ?></td>
                <td><?php echo $information->getAddressStreet() ?></td>
                <td><?php echo $information->getAddressCity() ?></td>
                <td><?php echo $information->getPostalCode() ?></td>
                <td><?php echo $information->getConstructionDate() ?></td>
                <td><?php echo $information->getNbRoom() ?></td>
                <td><?php echo $information->getComment() ?></td>
                <td><?php echo $information->getPropertySurface() ?></td>
                <td><?php echo $information->getPropertyGround() ?></td>
                <td><?php echo $information->getPictures() ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

</div>
<?php } ?>
</body>
</html>
