<?php
include 'template/header.php';
?>
<body>
<div  style="margin-left: 1%">
    <h1><?php echo $titrePage ?></h1>
</div>
<br>
<div class="container">
    <input class="form-control" id="myInput" type="text" placeholder="Recherchez un consultant...">
</div>
<br>
<table class="table table-bordered">
    <thead>
    <tr>
        <th>Prénom</th>
        <th>Nom</th>
        <th>Téléphone</th>
        <th>Adresse rue</th>
        <th>Ville</th>
        <th>Code postale</th>
        <th>Mail</th>
    </tr>
    </thead>
    <tbody id="myTable">
    <?php
    foreach ($consultants as $consultant){
        ?>
        <form method="post" action="?route=directory&action=viewRegistrationByConsultant"><input type="hidden" name="idConsultant" value="<?php echo $consultant->getId() ?>">
        <?php
        echo '<tr>';
        echo '<td><p style="display: none">'.$consultant->getFirstname().'</p><input type="submit" style="color: brown; border: none; background-color: white" value="'.$consultant->getFirstname().'" ></td>';
        echo '<td>'.$consultant->getLastname().'</td>';
        echo '<td>'.$consultant->getPhone().'</td>';
        echo '<td>'.$consultant->getStreetAddress().'</td>';
        echo '<td>'.$consultant->getCityAddress().'</td>';
        echo '<td>'.$consultant->getPostalCode().'</td>';
        echo '<td>'.$consultant->getMail().'</td>';
        echo '</tr>';
        ?></form><?php
    }
    ?>
    </tbody>
</table>
<script>
    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>
</body>

</html>