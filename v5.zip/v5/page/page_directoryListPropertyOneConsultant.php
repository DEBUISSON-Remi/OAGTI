<?php
include 'template/header.php';

?>
<body>
<?php

if ($etatProperty == 0){
    ?>
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <a href="?route=dashboard"><button type="button" class="close" data-dismiss="modal">&times;</button></a>
                <h4 class="modal-title">Pas de bien en cours d'enregistrement</h4>
            </div>
        <div class="modal-body">
            <p>Ce consultant n'a actuellement pas de bien en cours d'enregistrement </p>
        </div>
        </div>
    </div>
</body>
<?php
}
else {
?>

<div class="container">


    <h2>Bien en cours d'enregistrement</h2>
    <table class="table">
        <thead class="" style="color:#fff;background-color:#343a40;border-color:#454d55">
        <tr>
            <th style="text-align: center">Numéro de mandat</th>
            <th style="text-align: center">Nom du client</th>
            <th style="text-align: center">Prix du bien</th>
            <th style="text-align: center">Type de bien</th>
            <th style="text-align: center">Email du client</th>
            <th style="text-align: center">Outils</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($informations as $information){ ?>
            <form method="post" action="?route=property&action=propertyUpdate">
            <tr style="text-align: center;">
                <td><?php echo $information->getMandate()->getMandateName() ?></td>
                <td><?php echo $information->getOwner()->getLastname() ?></td>
                <td><?php echo $information->getMandate()->getPropertyPrice() ?></td>
                <td><?php echo $information->getProperty()->getTypeProperty()->getLibelle() ?></td>
                <td><?php echo $information->getOwner()->getMail() ?></td>
                <input type="hidden" value="<?php echo($information->getMandate()->getId()); ?>" name="idMandate">
                <input type="hidden" value="<?php echo($information->getProperty()->getTypeProperty()->getId()) ?>" name="typeProperty_id">
                <td><input type="submit" class="btn btn-info" value="Continuer"> - <button class="btn - btn-danger">Archiver</button></td>
            </tr>
            </form>
        <?php } ?>
        </tbody>
    </table>

</div>
<?php } ?>
</body>
</html>
