<?php include 'template/header.php'; ?>
<body>
<script>
    function modifier() {

        document.getElementById("btnModifier").style.display = "none";
        document.getElementById("btnEnregister").style.display = "block";
        document.getElementById("btnAnnuler").style.display = "block";

        document.getElementById("adresseVille").disabled = false;
        document.getElementById("codePostal").disabled = false;
        document.getElementById("tel").disabled = false;
        document.getElementById("mail").disabled = false;

    }

    function annuler(){
        document.getElementById("btnModifier").style.display = "block";
        document.getElementById("btnEnregister").style.display = "none";
        document.getElementById("btnAnnuler").style.display = "none";
    }

</script>

<div class="container"  style="margin-top: 6%">
    <div class="media">
        <div class="media-left">
            <img src="./images/logo.png" class="media-object" style="width:300px">
        </div>
        <div class="media-body">
            <h3 class="media-heading"><?php echo ($myAccount->getFirstname());?> <?php echo ($myAccount->getLastname());?> - <?php echo ($_SESSION['typeUser']->getLibelle());?></h3>
            <br>
            <form method="post" action="?route=login&action=updateAccount">
                <input type="hidden" name="idConsultant" value="<?php echo($_SESSION['id']) ?>">
                <div class="col-sm-6">
                    <div class="row">
                        <label style="margin-top: 6px">Secteur d'intervention : </label>
                        <input type="text" name="adresseVille" id="adresseVille" value="<?php echo ($myAccount->getCityAddress());?>" disabled style="float: right; width: 220px" maxlength="100">
                    </div>
                    <br>
                    <div class="row">
                        <label style="margin-top: 6px">Code Postal : </label>
                        <input type="text" name="codePostal" id="codePostal" value="<?php echo ($myAccount->getPostalCode());?>" disabled style="float: right; width: 220px" maxlength="20">
                    </div>
                    <br>
                    <div class="row">
                        <label style="margin-top: 6px">Numéro de téléphone : </label>
                        <input type="text" name="tel" id="tel" value="<?php echo ($myAccount->getPhone());?>" disabled style="float: right; width: 220px" maxlength="20">
                    </div>
                    <br>
                    <div class="row">
                        <label style="margin-top: 6px">Adresse e-mail : </label>
                        <input type="text" id="mail" value="<?php echo ($myAccount->getMail());?>" disabled style="float: right; width: 220px" maxlength="100">
                        <br><br>
                    </div>
                    <div class="btn">
                        <button type="button" class="btn btn-primary" value="Modifier" style="display: block" onclick="modifier()" id="btnModifier">Modifier</button>
                        <div class="btn-group">
                            <input type="submit" class="btn btn-primary" value="Enregistrer" style="display: none" id="btnEnregister">
                            <button type="button" class="btn btn-danger" value="Annuler" style="display: none" id="btnAnnuler" onclick="window.location.reload()">Annuler</button>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>

