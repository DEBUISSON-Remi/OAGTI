<?php ?>

    <input type="hidden" name="typeProperty_id" value="1">
    <div id="construction">
        <h3>Date de construction :</h3>
        <input type="date" name="constructionDate" id="constructionDate" placeholder="Date de construction">
    </div>
    <div>
        <h3>Commentaires :</h3>
        <input type="text" name="comment" placeholder="Décriver le bien en quelques lignes :" style="width: 800px" maxlength="255">
    </div>
    <br>
    <div>
        <h3>Photos :</h3>
    </div>
    <br>
    <br>
    <div>
        <h3>Surface :</h3>
            <input type="number" name="propertySurface" id="propertySurface" placeholder="Surface du bien en m2" style="-moz-appearance: textfield;" maxlength="5"> -
            <input type="number" name="propertyGround" id="propertyGround" placeholder="Surface du terrain en m2 s'il y en a" style="-moz-appearance: textfield;" maxlength="5">
        </div>
        <br>
        <div>
            <h3>Adresse :</h3>
            <input type="text" name="addressStreetProperty" placeholder="Rue" maxlength="200"> -
            <input type="text" name="addressCityProperty" placeholder="Ville" maxlength="50"> -
            <input type="text" name="postalCodeProperty" placeholder="Code Postal" maxlength="10"> -
            <input type="text" name="locality" placeholder="Lieu-dit" maxlength="50"> -
            <input type="number" name="buildingNumber" id="buildingNumber" placeholder="Détails de situation (n° bâtiment, n° appartement, autre)" style="-moz-appearance: textfield;" maxlength="4">
        </div>
    <br>
    <div>
        <h3>Prix FAI en € :</h3>
        <input type="number" name="ISPPrice" id="ISPPrice" placeholder="Calculé à partir des informations fourni dans le contrat mandataire" style="-moz-appearance: textfield;">
    </div>
    <br>
    <div>
        <h3>Honoraires de l'agence en € :</h3>
        <input type="number" name="agencyFee" id="agencyFee" placeholder="Fonction du pourcentage pratiqué par globAgence" style="-moz-appearance: textfield;">
    </div>
    <br>
    <div>
        <h3>Rémunération du consultant : </h3>
        <input type="text" name="commitionRate" value="<?php echo $consultant->getCommissionRate();?> %" disabled>
    </div>
    <br>

