
<div>
    <h3>Charges :</h3>
    <div class="">
        <input type="number" id="taxeFonciere" name="fonciere" placeholder="Fonciere" style="-moz-appearance: textfield;" maxlength="11"> -
        <input type="number" id="taxeHabitation" name="livingExpenses" placeholder="Habitation" style="-moz-appearance: textfield;" maxlength="11"> -
        <input type="number" id="charges" name="expenses" placeholder="Charges" style="-moz-appearance: textfield;" maxlength="11">
    </div>
    <br>
    <div>
        <label>Assainissement :</label>
        <select name="sanitation_id" size="1">
            <option value="" selected>Séléctionnez...</option>
            <?php foreach ($sanitations as $sanitation){
                echo'<option value="'.$sanitation->getId().'">'.$sanitation->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select> -
        <input type="text" name="newSanitation" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">

    </div>
    <br>
    <div>
        <h3>Chauffage :</h3>
        <label>Mode de chauffage :</label>
        <select name="heatingMethod_id" size="1">
            <option value="" selected>Séléctionnez...</option>
            <?php foreach ($heatingMethods as $heatingMethod){
                echo'<option value="'.$heatingMethod->getId().'">'.$heatingMethod->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select> -
        <input type="text" name="newHeatingMethod" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
        <br>
        <br>
        <label>Energie :</label>
        <select name="energy_id" size="1">
            <option value="" selected>Séléctionnez...</option>
            <?php foreach ($energys as $energy){
                echo'<option value="'.$energy->getId().'">'.$energy->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select> -
        <input type="text" name="newEnergy" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
    </div>
    <br>
    <div>
        <h3>Eau chaude :</h3>
        <label>Energie :</label>
        <select name="hotWater_id" size="1">
            <option value="" selected>Séléctionnez...</option>
            <?php foreach ($hotWaters as $hotWater){
                echo'<option value="'.$hotWater->getId().'">'.$hotWater->getLibelle().'</option>';
            } ?>
            <option value="">Aucun de ces choix</option>
        </select> -
        <input type="text" name="newHotWater" placeholder="Autre..." style="-moz-appearance: textfield;" maxlength="50">
    </div>
    <br>
</div>







