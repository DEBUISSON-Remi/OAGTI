<?php ?>


        <input type="hidden" value="2" name="typeProperty_id">
        <h3>Commentaires sur le bien :</h3>
        <input type="text" name="comment" placeholder="Décriver en quelque lignes le biens" style="width: 350px" maxlength="255">
    <br>
    <div>
        <h3>Photos (10 max)</h3>
        <br>
        <br>
        <div>
            <h3>Surface de terrain :</h3>
            <input type="number" name="propertyGround" id="propertyGround" placeholder="Insérez la surface du terrain en m²" style="width: 250px;  -moz-appearance: textfield;" maxlength="5">
            <input type="hidden" name="propertySurface" value="0" >
        </div>

        <div >
            <h3>Adresse complète :</h3>
            <input type="text" name="addressCityProperty" placeholder="Entrez votre ville" maxlength="200"> -
            <input type="text" name="addressStreetProperty" placeholder="Entrez votre rue" maxlength="50"> -
            <input type="text" name="postalCodeProperty" placeholder="Entrez votre code postal" maxlength="10">
            <input type="text" name="locality" placeholder="Entrez votre lieu-dit" maxlength="50">
        </div>
        <div>

            <input type="hidden" name="ISPPrice" id="ISPPrice" value="0">
        </div>
        <div>

            <input type="hidden" name="agencyFee" value="0">
        </div>
        <div >
            <h3>Rénumération Consultant :</h3>
            <input type="text" name="commisionRate" value="<?php echo $consultant->getCommissionRate();?> %" disabled>
        </div>


        <input type="hidden" value="0" name="nbRoom">
        <input type="hidden" value="0000-00-00" name="constructionDate">
        <input type="hidden" value="0" name="buildingNumber">
        <input type="hidden" value="0" name="fonciere">
        <input type="hidden" value="0" name="livingExpenses">
        <input type="hidden" value="0" name="expenses">
        <input type="hidden" value="<?php echo $sanitations->getId(); ?>" name="sanitation_id">
        <input type="hidden" value="<?php echo $heatingMethods->getId(); ?>" name="heatingMethod_id">
        <input type="hidden" value="<?php echo $energys->getId(); ?>" name="energy_id">
        <input type="hidden" value="<?php echo $hotWaters->getId(); ?>" name="hotWater_id">
