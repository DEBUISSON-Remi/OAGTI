<?php include('../page/template/header.php') ?>
<script>
    function checkInformation() {
        if (document.getElementById("prixBien").value === '') {
            document.getElementById("prixBien").value = 0;
        }

        if (document.getElementById("nbRoom").value === '') {
            document.getElementById("nbRoom").value = 0;
        }

        if (document.getElementById("propertySurface").value === '') {
            document.getElementById("propertySurface").value = 0;
        }
        if (document.getElementById("propertyGround").value === '') {
            document.getElementById("propertyGround").value = 0;
        }
        if (document.getElementById("buildingNumber").value === '') {
            document.getElementById("buildingNumber").value = 0;
        }

        if (document.getElementById("ISPPrice").value === '') {
            document.getElementById("ISPPrice").value = 0;
        }

        if (document.getElementById("agencyFee").value === '') {
            document.getElementById("agencyFee").value = 0;
        }

        if (document.getElementById("taxeFonciere").value === '') {
            document.getElementById("taxeFonciere").value = 0;
        }

        if (document.getElementById("taxeHabitation").value === '') {
            document.getElementById("taxeHabitation").value = 0;
        }

        if (document.getElementById("charges").value === '') {
            document.getElementById("charges").value = 0;
        }
    }

    function validateKeyPressed(){

    }
</script>
<form method="post" action="?route=property&action=currentHouseRegisters">
    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#mandat">Mandat</a></li>
        <li class=""><a data-toggle="tab" href="#proprietaire">Informations sur le proprietaire</a></li>
        <li><a data-toggle="tab" href="#information">Informations sur le bien</a></li>
        <li><a data-toggle="tab" href="#rooms">Informations sur les pièces</a></li>
        <li><a data-toggle="tab" href="#information-complement">Informations complémentaires sur la maison</a></li>
        <li><input type="submit" value="Enregistrer" onclick="checkInformation()" class="btn btn-primary"></li>
        <li><button type="button" class="btn btn-danger">Publier</button></li>
    </ul>


    <div class="tab-content">
        <div id="mandat" class="tab-pane fade in active" style="margin-left: 1%">
            <?php include('../page/template/page_mandate.php'); ?>
        </div>
        <div id="proprietaire" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/template/page_owner.php'); ?>
        </div>
        <div id="information" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/page_informationHouse.php'); ?>
        </div>
        <div id="rooms" class="tab-pane fade" style="margin-left: 1%">
            <?php include('../page/template/page_room.php'); ?>
        </div>
        <div id="information-complement" class="tab-pane fade" style="margin-left: 1%">
            <?php include ('../page/page_additionalHouseInformation.php'); ?>
        </div>
    </div>

</form>

</body>
</html>
