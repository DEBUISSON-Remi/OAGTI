<?php
include 'template/header.php';
?>

<body>
<tbody>
<div  style="margin-left: 1%">
    <h1><?php echo $titrePage ?></h1>
</div>
<div class="container">
    <input class="form-control" id="myInput" type="text" placeholder="Recherchez un client...">
</div>
<br>
<table class="table table-bordered">
    <thead>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Siége Social</th>
        <th>Dénomination Social</th>
        <th>Ville</th>
        <th>Adresse rue</th>
        <th>Code Postale</th>
        <th>Téléphone</th>
        <th>Mail</th>
        <th>Genre</th>
        <th>Raison Sociale</th>
        <th>Facebook</th>
        <th>Twitter</th>
    </tr>
    </thead>
    <tbody id="myTable">
    <?php
    foreach ($owners as $owner){
    ?>
    <form method="post" action="?route=directory&action=viewPropertyByOwner"><input type="hidden" name="idOwner" value="<?php echo $owner->getId() ?>">
        <?php
        echo '<tr>';
        echo '<td><p style="display: none">'.$owner->getLastname().'</p><input type="submit" style="color: brown; border: none; background-color: white" value="'.$owner->getLastname().'"</td>';
        echo '<td>'.$owner->getFirstname().'</td>';
        echo '<td>'.$owner->getSocialHeadquarters().'</td>';
        echo '<td>'.$owner->getSocialDenomination().'</td>';
        echo '<td>'.$owner->getAddressCity().'</td>';
        echo '<td>'.$owner->getAddressStreet().'</td>';
        echo '<td>'.$owner->getPostalCode().'</td>';
        echo '<td>'.$owner->getPhone().'</td>';
        echo '<td>'.$owner->getMail().'</td>';
        echo '<td>'.$owner->getGender().'</td>';
        echo '<td>'.$owner->getSocialReson().'</td>';
        echo '<td>'.$owner->getFacebook().'</td>';
        echo '<td>'.$owner->getTwitter().'</td>';
        echo '</tr></form>';
        }
        ?>
</table>
</tbody>
<script>
    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>
</body>

</html>
