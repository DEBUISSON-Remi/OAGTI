<?php include('../page/template/header.php') ?>
<body>
<script>
    function checkInformationGround() {
        if (document.getElementById("prixBien").value === '') {
            document.getElementById("prixBien").value = 0;
        }

        if (document.getElementById("propertyGround").value === '') {
            document.getElementById("propertyGround").value = 0;
        }

        if (document.getElementById("agencyFee").value === '') {
            document.getElementById("agencyFee").value = 0;
        }

    }
</script>
<form method="post" action="?route=property&action=currentGroundRegister">
<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#mandat">Mandat</a></li>
    <li class=""><a data-toggle="tab" href="#proprietaire">Informations sur le propriétaire</a></li>
    <li><a data-toggle="tab" href="#information">Informations sur le terrain</a></li>
    <li><input type="submit" value="Enregistrer" onclick="checkInformationGround()" class="btn btn-primary"></li>
    <li><button type="button" class="btn btn-danger">Publier</button></li>

</ul>

<div class="tab-content">
    <div id="mandat" class="tab-pane fade in active" style="margin-left: 1%">
        <?php include('../page/template/page_mandate.php'); ?>
    </div>
    <div id="proprietaire" class="tab-pane fade" style="margin-left: 1%">
        <?php include('../page/template/page_owner.php'); ?>
    </div>
    <div id="information" class="tab-pane fade" style="margin-left: 1%">
        <?php include ('../page/page_informationGround.php'); ?>
    </div>
</div>

</form>
</body>
</html>