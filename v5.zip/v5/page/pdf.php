<?php

$address = [];

if($information->getOwner()->getAddressStreet() != ''){
    $address = [$information->getOwner()->getAddressStreet(), $information->getOwner()->getAddressCity(), $information->getOwner()->getPostalCode()];
}
else{
    $address = [$information->getOwner()->getSocialDenomination(), $information->getOwner()->getSocialHeadquarters(), $information->getOwner()->getSocialReson()];
}

$montantConsultant = $information->getMandate()->getPropertyPrice() * ($information->getConsultant()->getCommissionRate() / 100);

$pdf = new FPDF();
$pdf->AddPage();

//Header
$pdf->SetFont('Arial','BU',18);
$pdf->Image('../www/images/logo.png',0,0,60,60);
$pdf->Cell(0,20,$information->getTypeMandate()->getLibelle(),0,0,'C');

//Corps
//numeros de mandat
$pdf->ln(50);
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,0,'Numéros d\'inscription au registre des mandats : '.$information->getMandate()->getMandateName(),0,0,'L');

//Premier paragraphe
$pdf->SetFont('Arial','',8);
$pdf->ln(10);
$pdf->Cell(0,0,'ENTRE LES SOUSSIGNÉS :',0,0,'L');
$pdf->ln(5);
$pdf->Cell(0,0,$information->getOwner()->getLastname().' '.$information->getOwner()->getFirstname().' demeurant à '.$address[0].', '.$address[1].' '.$address[2]);
$pdf->ln(8);
$pdf->Cell(0,0,'ci-après dénommé "le mandant" ');
$pdf->ln(8);
$pdf->Cell(0,0,'d\'une part, ');
$pdf->ln(8);
$pdf->Cell(0,0,'et ');
$pdf->ln(5);
$pdf->MultiCell(0,5,$information->getConsultant()->getLastname().' '.$information->getConsultant()->getFirstname().' ci-après dénommé "le mandataire"; garanti financièrement par Nom du garant financier,');
$pdf->ln(8);
$pdf->Cell(0,0,'d\'autre part, ');
$pdf->ln(8);
$pdf->Cell(0,0,'IL A ÉTÉ CONVENU ET ARRÊTÉ CE QUI SUIT :');
$pdf->SetFont('Arial','B',8);
$pdf->ln(8);
$pdf->Cell(0,0,'Objet et durée du contrat');
$pdf->SetFont('Arial','',8);
$pdf->ln(7);
$pdf->MultiCell(0,6,'Par la présente, donne à '.$information->getConsultant()->getLastname().' '.$information->getConsultant()->getFirstname().' du mandataire mandat de vendre les biens et droits immobiliers ci-dessous désignés. Ce mandat de vente est consenti pour une durée de 3 mois.
Le mandant déclare qu\'il confie tous les pouvoirs au mandataire pour l\'exécution de sa mission.
Le mandataire pourra notamment :
   -> utiliser les moyens publicitaires pour la vente des dits biens
   -> faire visiter lesdits biens à tous acquéreurs potentiels');
$pdf->SetFont('Arial','B',8);
$pdf->ln(7);
$pdf->Cell(0,0,'Désignation des biens et droits immobiliers');
$pdf->SetFont('Arial','',8);
$pdf->ln(7);
$pdf->Cell(0,0,'Le biens à vendre, objets du présent mandat est : '.$information->getTypeProperty()->getLibelle().' situé à '.$information->getProperty()->getAddressStreet().', '.$information->getProperty()->getPostalCode().' '.$information->getProperty()->getAddressCity());
$pdf->ln(7);
$pdf->Cell(0,0,'Le mandant déclare que les biens seront, le jour de la signature de l\'acte authentique de vente, libres de toute location, occupation ou réquisition.');
$pdf->SetFont('Arial','B',8);
$pdf->ln(7);
$pdf->Cell(0,0,'Prix de vente');
$pdf->SetFont('Arial','',8);
$pdf->ln(7);
$pdf->Cell(0,0,'Le mandataire devra vendre les biens et droits immobiliers ci-dessus désignés au prix de '.$information->getMandate()->getPropertyPrice().', payable au comptant.');
$pdf->SetFont('Arial','B',8);
$pdf->ln(7);
$pdf->Cell(0,0,'Rémunération');
$pdf->SetFont('Arial','',8);
$pdf->ln(7);
$pdf->Cell(0,0,'Si la vente se réalise, la rémunération du mandataire sera de '.$montantConsultant.' euros toutes taxes comprises, soit Pourcentage de '.$information->getConsultant()->getCommissionRate().'% du prix de vente.');
$pdf->ln(9);
$pdf->Cell(0,0,'Fait à '.$information->getConsultant()->getCityAddress().' , le '.date('d/m/yy').'.');
$pdf->ln(7);
$pdf->Cell(0,0,'En deux exemplaires, dont un est remis à chacune des parties qui le reconnait.');
$pdf->ln(8);
$pdf->Cell(0,0,'Le mandant ');
$pdf->Cell(0,0,'Le mandataire ',0,0,'R');
$pdf->ln(5);
$pdf->Cell(0,0,'(signature précédé de la mention manuscrite "lu et approuvé, ');
$pdf->Cell(0,0,'(signature précédé de la mention manuscrite "lu et approuvé,',0,0,'R');
$pdf->ln(5);
$pdf->Cell(0,0,'bon pour mandat")');
$pdf->Cell(0,0,'bon pour acceptation du mandat")',0,0,'R');
$pdf->Output();
?>