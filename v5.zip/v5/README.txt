Glob Agence - Thunder Storm - Groupe A

*Installation :
BDD : se connecter sur phpmyadmin 
login : userweb 
mdp : pweb
créer une nouvelle base de donnée oagti_v3 puis y importer le scripte SQL oagti_v3

*Installation application : 
mettre la v4 dans un dossier nommer oagti 
se placer dans le repertoire www de l'application dans la console et écrire la commande : "valet link oagti-v5" 
vérifier si le lien s'est bien créer avec la commande "valet links"
lancer le navigateur et écrire "oagti-v5.test" dans l'url
a partir de la vous pourrez vous connecter avec les identifiants et les mots de passes juste en dessous.

*Fonctionnalitées disponibles :
-Page de connexion
-Annuaire disponible
-Page profil
-Modifier ses informations dans "mon compte"
-Déconnexion disponible
-Possibilité d'enregistrer n'importe quel type de biens
-Possibilité de consulter les biens en cours d'enregistrement et de les continuer
-Mise à a jours d'un enregistrement en cours
-Possibilité de voir via annuaire les propriétés des clients
-Possibilité de voir via annuaire les enregistrements des consultants
-Implémentation des rooms dans l'enregistrement d'un bien
-première version de l'accueil
-création du PDF pour le mandat
-sélection du client renseigne ses informations dans l'inscription d'un bien

->correction de bugs mineurs



*Fabriqué avec :
PHP Storm

*Versions :
v5

*Auteurs :
Killian PICCERELLE
Antoine MARTINEAU
Anthony NICOL
Jordan VILLEMAINE
Valentin BELLOUARD
Samy ALEXANDRE
Rémi DEBUISSON