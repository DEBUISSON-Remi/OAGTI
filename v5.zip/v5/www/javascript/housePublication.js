function publishButton(){
    if (document.getElementById("prixBien").value === '') {
        if (document.getElementById("lastnameOwner").value === ''){
            if (document.getElementById("firstnameOwner").value === ''){
                if (document.getElementById("phoneOwner").value === ''){
                    if (document.getElementById("mailOwner").value === ''){
                        if (document.getElementById("constructionDate").value === ''){
                            if (document.getElementById("comment").value === ''){
                                if (document.getElementById("propertySurface").value === ''){
                                    if (document.getElementById("propertyGround").value === ''){
                                        if (document.getElementById("addressStreetProperty").value === ''){
                                            if (document.getElementById("addressCityProperty").value === ''){
                                                if (document.getElementById("postalCodeProperty").value === ''){
                                                    if (document.getElementById("locality").value === ''){
                                                        if (document.getElementById("buildingNumber").value === ''){
                                                            if (document.getElementById("taxeFonciere").value === ''){
                                                                if (document.getElementById("taxeHabitation").value === ''){
                                                                    if (document.getElementById("charges").value === ''){
                                                                        if (document.getElementById("sanitation_id").value === ''){
                                                                            if (document.getElementById("heatingMethod_id").value === ''){
                                                                                if (document.getElementById("energy_id").value === ''){
                                                                                    if (document.getElementById("hotWater_id").value === ''){
                                                                                        if (document.getElementById("particulier").checked == true){
                                                                                            if(document.getElementById("addressCityOwner").value === "" || document.getElementById("addressStreetOwner").value === "" || document.getElementById("postalCodeOwner").value === ""){
                                                                                                document.getElementById("buttonPublish").disabled = false;
                                                                                            }
                                                                                            else if(document.getElementById("socialHeadquarters").value === "" || document.getElementById("socialReson").value === "" || document.getElementById("socialDenomination").value === ""){
                                                                                                document.getElementById("buttonPublish").disabled = false;
                                                                                            }
                                                                                            else{
                                                                                                document.getElementById("buttonPublish").disabled = true;
                                                                                            }
                                                                                        }
                                                                                        else{
                                                                                            document.getElementById("buttonPublish").disabled = true;
                                                                                        }
                                                                                    }
                                                                                    else{
                                                                                        document.getElementById("buttonPublish").disabled = true;
                                                                                    }
                                                                                }
                                                                                else{
                                                                                    document.getElementById("buttonPublish").disabled = true;
                                                                                }
                                                                            }
                                                                            else{
                                                                                document.getElementById("buttonPublish").disabled = true;
                                                                            }
                                                                        }
                                                                        else{
                                                                            document.getElementById("buttonPublish").disabled = true;
                                                                        }
                                                                    }
                                                                    else{
                                                                        document.getElementById("buttonPublish").disabled = true;
                                                                    }
                                                                }
                                                                else{
                                                                    document.getElementById("buttonPublish").disabled = true;
                                                                }
                                                            }
                                                            else{
                                                                document.getElementById("buttonPublish").disabled = true;
                                                            }
                                                        }
                                                        else{
                                                            document.getElementById("buttonPublish").disabled = true;
                                                        }
                                                    }
                                                    else{
                                                        document.getElementById("buttonPublish").disabled = true;
                                                    }
                                                }
                                                else{
                                                    document.getElementById("buttonPublish").disabled = true;
                                                }
                                            }
                                            else{
                                                document.getElementById("buttonPublish").disabled = true;
                                            }
                                        }
                                        else{
                                            document.getElementById("buttonPublish").disabled = true;
                                        }
                                    }
                                    else{
                                        document.getElementById("buttonPublish").disabled = true;
                                    }
                                }
                                else{
                                    document.getElementById("buttonPublish").disabled = true;
                                }
                            }
                            else{
                                document.getElementById("buttonPublish").disabled = true;
                            }
                        }
                        else{
                            document.getElementById("buttonPublish").disabled = true;
                        }
                    }
                    else{
                        document.getElementById("buttonPublish").disabled = true;
                    }
                }
                else{
                    document.getElementById("buttonPublish").disabled = true;
                }
            }
            else{
                document.getElementById("buttonPublish").disabled = true;
            }
        }
        else{
            document.getElementById("buttonPublish").disabled = true;
        }
    }
    else{
        document.getElementById("buttonPublish").disabled = true;
    }

}