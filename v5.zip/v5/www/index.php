<?php
include('../include.php');

session_start();
$_SESSION['etat']=-1;

// On récupère le paramètre "route" de l'URL
if(isset($_GET['route'])) {
    $route = $_GET['route'];
}else{
    $route = 'default';
}

// On récupère le paramètre "action" de l'URL
if(isset($_GET['action'])) {
    $action = $_GET['action'];
}else{
    $action='default';
}

if (isset($_POST['mail'])){
    $consultant=LoginController::loginCheck($_POST['mail']);
    if ($consultant != null){
        $_SESSION['etat']=1;
        $_SESSION['name']=$consultant->getFirstname();
        $_SESSION['surname']=$consultant->getLastname();
        $_SESSION['typeUser']=$consultant->getTypeUser();
        $_SESSION['id']=$consultant->getId();
        $route = 'dashboard';
    }
    else {
        $_SESSION['etat']=0;
        $route = 'default';
    }
}


// On sélectionne le controlleur en fonction de la route
switch ($route) {
	case 'dashboard' :
        DashboardController::switchAction($action);
	    break;
    case 'property':
        PropretyController::switchAction($action);
        break;
    case 'login':
        LoginController::switchAction($action);
        break;
    case 'directory':
        DirectoryController::switchAction($action);
        break;
    case 'transaction':
        TransactionController::switchAction($action);
        break;
	default : // A défaut par sécurité, on génère une erreur
        LoginController::switchAction($action);
	break;
}



