<?php
//config
include('Config.php');

//DAO
include('../DAO/Connexion.php');
include('../DAO/ConsultantDAO.php');
include('../DAO/ConnexionDAO.php');
include('../DAO/DirectoryDAO.php');
include('../DAO/TypeUserDAO.php');
include('../DAO/PropertyDAO.php');
include('../DAO/EnergyDAO.php');
include('../DAO/ExpensesDAO.php');
include('../DAO/HeatingMethodDAO.php');
include('../DAO/HotWaterDAO.php');
include('../DAO/SanitationDAO.php');
include('../DAO/OwnerDAO.php');
include('../DAO/TypePropertyDAO.php');
include('../DAO/MandateDAO.php');
include('../DAO/SignDAO.php');
include('../DAO/StatutMandateDAO.php');
include('../DAO/RoomDAO.php');


//Controle
include('../controle/DashboardController.php');
include('../controle/PropretyController.php');
include('../controle/LoginController.php');
include('../controle/TransactionController.php');
include('../controle/DirectoryController.php');

//Models
include('../Models/Consultant.php');
include('../Models/Owner.php');
include('../Models/Mandate.php');
include('../Models/StatutMandate.php');
include('../Models/StatutProperty.php');
include('../Models/TypeMandate.php');
include('../Models/TypeUser.php');
include('../Models/Property.php');
include('../Models/TypeProperty.php');
include('../Models/Sanitation.php');
include('../Models/HeatingMethod.php');
include('../Models/Energy.php');
include('../Models/HotWater.php');
include('../Models/Sign.php');
include('../Models/Expenses.php');
include('../Models/PropertyInformation.php');
include('../Models/Room.php');
include ('fpdf/fpdf.php');
